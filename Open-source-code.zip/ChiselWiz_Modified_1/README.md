# ChiselWiz - Modified Source Code

## Changes Made
- **Speed slider max increased from 20x to 100x** — open F menu while holding chisel, bottom slider controls speed
- Source code cleaned from decompiler artifacts (ILSpy)
- All files properly split into individual .cs files per class

## How to Build

### 1. Set your Vintage Story path
Edit `ChiselWiz/ChiselWiz.csproj` and update `<GamePath>`:
```xml
<GamePath>C:\Program Files\Vintagestory</GamePath>
```
Or pass it via CLI: `dotnet build -p:GamePath="C:\Games\Vintagestory"`

### 2. Make sure SkiaSharp.QrCode project is in place
The `.csproj` references `../SkiaSharp.QrCode/SkiaSharp.QrCode.csproj`.
If you have the `SkiaSharp.QrCode.dll`, you can replace the `<ProjectReference>` with:
```xml
<Reference Include="SkiaSharp.QrCode">
  <HintPath>path\to\SkiaSharp.QrCode.dll</HintPath>
</Reference>
```

### 3. Build
Open `Solution.sln` in Visual Studio 2022 and press **Build → Build Solution** (Ctrl+Shift+B).

Or from command line:
```
dotnet build Solution.sln
```

### 4. Install the mod
Copy the built `ChiselWiz.dll` to your VS mods folder:
`%AppData%\VintagestoryData\Mods\`

## Speed Slider Location
Press **F** while holding a chisel → look at the bottom of the dialog for **"Chiselling Speed"** slider.
- Default: 1x
- Maximum: **100x** (was 20x in original)

## Dependencies (from game folder)
- VintagestoryAPI.dll
- VintagestoryLib.dll
- Mods/VSSurvivalMod.dll
- Mods/VSEssentials.dll
- Lib/0Harmony.dll
- Lib/cairo-sharp.dll
- Lib/Newtonsoft.Json.dll
- Lib/SkiaSharp.dll
