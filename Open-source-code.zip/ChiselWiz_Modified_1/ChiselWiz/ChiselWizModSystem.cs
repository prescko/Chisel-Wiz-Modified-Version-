﻿using System;
using ChiselWiz.Gui.Dialogs;
using ChiselWiz.Patches;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Catalogues;
using ChiselWiz.Systems.Chiselling;
using ChiselWiz.Systems.Images;
using HarmonyLib;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.Client.NoObf;
using Vintagestory.GameContent;

namespace ChiselWiz;

public class ChiselWizModSystem : ModSystem
{
	public class ChiselWizSpeedConfig
	{
		public int ChiselSpeed { get; set; } = 1;
	}

	private const string SpeedConfigFileName = "ChiselWiz.SpeedSlider.json";

	private Harmony harmony;

	public ICoreClientAPI capi;

	public ChiselOperator chiseller;

	private ChiselWizSpeedConfig speedConfig = new ChiselWizSpeedConfig();

	private ChiselToolModeManager toolModeManager;

	private GuiDesignCatalogue catalogueGui;

	private GuiImageToolDialogBase imageToolGui;

	private GuiQRCodeToolDialog qrToolGui;

	private ImageDesignLoader imageDesignLoader;

	public CatalogueCollection catalogues;

	public ChiselWizCatalogue PrimaryCatalogue { get; private set; }

	public override void StartClientSide(ICoreClientAPI api)
	{

		capi = api;
		harmony = new Harmony("com.flamescape.chiselwiz");
		harmony.PatchAll();
		chiseller = new ChiselOperator(capi);
		LoadSpeedConfig();
		chiseller.ChiselSpeed = speedConfig.ChiselSpeed;
		toolModeManager = new ChiselToolModeManager(capi, chiseller);
		imageDesignLoader = new ImageDesignLoader(capi, new AssetLocation("chiselwiz", "config/palettes.json"));
		catalogues = new CatalogueCollection();
		PrimaryCatalogue = new ChiselWizCatalogue(capi, "chiselwiz-catalogue.json");
		PrimaryCatalogue.TryLoad();
		catalogues.Add(PrimaryCatalogue);
		ChiselToolsPortfolioCatalogue chiselToolsPortfolioCatalogue = ChiselToolsPortfolioCatalogue.TryLoadFrom(capi, "chiselportfolio");
		if (chiselToolsPortfolioCatalogue != null)
		{
			catalogues.Add(chiselToolsPortfolioCatalogue);
		}
		catalogueGui = new GuiDesignCatalogue(capi, catalogues, chiseller);
		imageToolGui = new GuiImageToolDialog(capi, chiseller, toolModeManager, imageDesignLoader);
		qrToolGui = new GuiQRCodeToolDialog(capi, chiseller, toolModeManager, imageDesignLoader);
		GuiReplacementPatches.SetAlternativeGui(typeof(GuiDialogToolMode), (GuiDialog)(object)new GuiCWToolMode(capi, chiseller, toolModeManager), delegate
		{
			IClientPlayer player = capi.World.Player;
			object obj;
			if (player == null)
			{
				obj = null;
			}
			else
			{
				IPlayerInventoryManager inventoryManager = ((IPlayer)player).InventoryManager;
				obj = ((inventoryManager != null) ? inventoryManager.ActiveHotbarSlot : null);
			}
			ItemStack itemstack = ((ItemSlot)obj).Itemstack;
			CollectibleObject val = ((itemstack != null) ? itemstack.Collectible : null);
			return val != null && val is ItemChisel;
		}, delegate(GuiDialog altGui)
		{
			BlockEntityChisel beChisel = null;
			IClientPlayer player = capi.World.Player;
			object obj;
			if (player == null)
			{
				obj = null;
			}
			else
			{
				IPlayerInventoryManager inventoryManager = ((IPlayer)player).InventoryManager;
				obj = ((inventoryManager != null) ? inventoryManager.ActiveHotbarSlot : null);
			}
			ItemSlot val = (ItemSlot)obj;
			ItemStack itemstack = val.Itemstack;
			CollectibleObject val2 = ((itemstack != null) ? itemstack.Collectible : null);
			if (val2 == null)
			{
				return false;
			}
			ItemChisel val3 = (ItemChisel)(object)((val2 is ItemChisel) ? val2 : null);
			if (val3 == null)
			{
				return false;
			}
			BlockSelection currentBlockSelection = ((IPlayer)capi.World.Player).CurrentBlockSelection;
			BlockSelection val4 = ((currentBlockSelection != null) ? currentBlockSelection.Clone() : null);
			if (val4 != null)
			{
				beChisel = ((IWorldAccessor)capi.World).BlockAccessor.GetBlockEntity<BlockEntityChisel>(val4.Position);
			}
			if (altGui is GuiCWToolMode guiCWToolMode)
			{
				guiCWToolMode.SetFocus(val3, beChisel, val4, val);
			}
			return true;
		}, delegate
		{
		});
		RegisterHotKeys();
		RegisterCommands();
	}

	private void LoadSpeedConfig()
	{
		try
		{
			speedConfig = capi.LoadModConfig<ChiselWizSpeedConfig>(SpeedConfigFileName) ?? new ChiselWizSpeedConfig();
		}
		catch (Exception ex)
		{
			((ICoreAPI)capi).Logger.Warning("ChiselWiz: Failed to load speed slider config, using default speed. " + ex.Message);
			speedConfig = new ChiselWizSpeedConfig();
		}
		speedConfig.ChiselSpeed = Math.Clamp(speedConfig.ChiselSpeed, 1, 100);
		SaveSpeedConfig();
	}

	public void SetChiselSpeed(int speed)
	{
		int clampedSpeed = Math.Clamp(speed, 1, 100);
		chiseller.ChiselSpeed = clampedSpeed;
		if (speedConfig.ChiselSpeed == clampedSpeed)
		{
			return;
		}
		speedConfig.ChiselSpeed = clampedSpeed;
		SaveSpeedConfig();
	}

	private void SaveSpeedConfig()
	{
		try
		{
			capi.StoreModConfig(speedConfig, SpeedConfigFileName);
		}
		catch (Exception ex)
		{
			((ICoreAPI)capi).Logger.Warning("ChiselWiz: Failed to save speed slider config. " + ex.Message);
		}
	}

	private void RegisterHotKeys()
	{
		capi.Input.RegisterHotKey("chiselwiz:hotkey-copy", Lang.Get("chiselwiz:hotkey-copy", Array.Empty<object>()), (GlKeys)85, (HotkeyType)4, false, true, true);
		capi.Input.RegisterHotKey("chiselwiz:hotkey-paste", Lang.Get("chiselwiz:hotkey-paste", Array.Empty<object>()), (GlKeys)104, (HotkeyType)4, false, true, true);
		capi.Input.RegisterHotKey("chiselwiz:hotkey-undo", Lang.Get("chiselwiz:hotkey-undo", Array.Empty<object>()), (GlKeys)108, (HotkeyType)4, false, true, true);
		capi.Input.SetHotKeyHandler("chiselwiz:hotkey-copy", (ActionConsumable<KeyCombination>)CopyBlockHotkeyHandler);
		capi.Input.SetHotKeyHandler("chiselwiz:hotkey-paste", (ActionConsumable<KeyCombination>)PasteBlockHotkeyHandler);
		capi.Input.SetHotKeyHandler("chiselwiz:hotkey-undo", (ActionConsumable<KeyCombination>)UndoHotkeyHandler);
	}

	private void RegisterCommands()
	{

		_ = ((ICoreAPI)capi).ChatCommands.Parsers;
		((ICoreAPI)capi).ChatCommands.Create("cw").BeginSubCommand("reload").HandleWith((OnCommandDelegate)delegate
		{
			try
			{
				if (!PrimaryCatalogue.TryLoad())
				{
					throw new VSException(Lang.Get("chiselwiz:Failed to reload catalogue", Array.Empty<object>()));
				}
				return TextCommandResult.Success(Lang.Get("chiselwiz:Catalogue reloaded", Array.Empty<object>()), (object)null);
			}
			catch (Exception ex)
			{
				return TextCommandResult.Error(ex.Message, "");
			}
		})
			.EndSubCommand()
			.BeginSubCommand("tex")
			.HandleWith((OnCommandDelegate)delegate
			{
				try
				{
					imageDesignLoader.LoadPalettes(forceReload: true);
					return TextCommandResult.Success(Lang.Get("chiselwiz:Output block colours", Array.Empty<object>()), (object)null);
				}
				catch (Exception ex)
				{
					return TextCommandResult.Error(ex.Message, "");
				}
			})
			.EndSubCommand();
	}

	public override void Dispose()
	{
		Harmony obj = harmony;
		if (obj != null)
		{
			obj.UnpatchAll("com.flamescape.chiselwiz");
		}
		BlockEntityChiselPatch.Dispose();
		InventoryPatch.Dispose();
		base.Dispose();
	}

	public bool CopyBlockHotkeyHandler(KeyCombination _)
	{
		try
		{
			BlockBlueprint blueprint = new BlockBlueprint(chiseller.FocusedBEMicroblock);
			chiseller.SetClipboardBlueprint(blueprint);
		}
		catch (VSException ex)
		{
			ex.DisplayError(capi);
		}
		catch (Exception ex2)
		{
			capi.ShowChatMessage("[Error] " + ex2.Message);
			((ICoreAPI)capi).Logger.Error(ex2);
		}
		return true;
	}

	public bool PasteBlockHotkeyHandler(KeyCombination _)
	{
		try
		{
			chiseller.Paste();
		}
		catch (VSException ex)
		{
			ex.DisplayError(capi);
		}
		catch (Exception ex2)
		{
			capi.ShowChatMessage("[Error] " + ex2.Message);
			((ICoreAPI)capi).Logger.Error(ex2);
		}
		return true;
	}

	public bool UndoHotkeyHandler(KeyCombination _)
	{
		try
		{
			chiseller.Undo();
		}
		catch (VSException ex)
		{
			ex.DisplayError(capi);
		}
		catch (Exception ex2)
		{
			capi.ShowChatMessage("[Error] " + ex2.Message);
			((ICoreAPI)capi).Logger.Error(ex2);
		}
		return true;
	}

	public void ToggleCatalogueGui()
	{
		if (((GuiDialog)catalogueGui).IsOpened())
		{
			((GuiDialog)catalogueGui).TryClose();
		}
		else
		{
			((GuiDialog)catalogueGui).TryOpen();
		}
	}

	public void ToggleCatalogueGui(bool open)
	{
		if (open)
		{
			((GuiDialog)catalogueGui).TryOpen();
		}
		else
		{
			((GuiDialog)catalogueGui).TryClose();
		}
	}

	public void ToggleImageToolGui()
	{
		if (((GuiDialog)imageToolGui).IsOpened())
		{
			((GuiDialog)imageToolGui).TryClose();
		}
		else
		{
			((GuiDialog)imageToolGui).TryOpen();
		}
	}

	public void ToggleImageToolGui(bool open)
	{
		if (open)
		{
			((GuiDialog)imageToolGui).TryOpen();
		}
		else
		{
			((GuiDialog)imageToolGui).TryClose();
		}
	}

	public void ToggleQRToolGui()
	{
		if (((GuiDialog)qrToolGui).IsOpened())
		{
			((GuiDialog)qrToolGui).TryClose();
		}
		else
		{
			((GuiDialog)qrToolGui).TryOpen();
		}
	}

	public void ToggleQRToolGui(bool open)
	{
		if (open)
		{
			((GuiDialog)qrToolGui).TryOpen();
		}
		else
		{
			((GuiDialog)qrToolGui).TryClose();
		}
	}
}




