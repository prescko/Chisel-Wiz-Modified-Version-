﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class PushPullMode : CWChiselMode
{
	public override int MaxStrength => 15;

	public PushPullMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = false
		};
		int distance = CurrentStrength;
		if (isBreak)
		{
			distance = -distance;
		}
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			bp.PushVoxels(distance, facing);
			return bp;
		}, beChisel, options);
		return false;
	}
}




