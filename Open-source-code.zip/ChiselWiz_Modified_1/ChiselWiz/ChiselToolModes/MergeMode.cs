﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class MergeMode : CWChiselMode
{
	public MergeMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		BlockBlueprint clipboardBp = chiseller.ClipboardBlueprint?.Clone();
		if (clipboardBp == null)
		{
			return false;
		}
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = true
		};
		ChiselOperator.ChiselJob job = chiseller.Apply(delegate(BlockBlueprint bp)
		{
			if (clipboardBp == null)
			{
				return bp;
			}
			bp.MergeDesign(clipboardBp, addMissingVoxels: true, replaceOverlappingVoxels: false, removeExtraVoxels: false);
			return bp;
		}, beChisel, options);
		job.OnComplete = delegate
		{
			if (job.OperationCount > 0)
			{
				chiseller.TadaaFx(((BlockEntity)beChisel).Pos);
			}
		};
		return true;
	}
}




