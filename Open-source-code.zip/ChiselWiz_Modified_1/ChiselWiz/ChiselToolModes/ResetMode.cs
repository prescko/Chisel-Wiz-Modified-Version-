﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class ResetMode : CWChiselMode
{
	public ResetMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = false,
			saveUndo = true,
			forceAggressiveClear = true
		};
		ChiselOperator.ChiselJob job = chiseller.Apply(delegate(BlockBlueprint bp)
		{
			bp.Reset(currentMaterialIndex);
			bp.Name = "";
			return bp;
		}, beChisel, options);
		job.OnComplete = delegate
		{
			if (job.OperationCount > 0)
			{
				chiseller.TadaaFx(((BlockEntity)beChisel).Pos);
			}
		};
		return false;
	}
}




