﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class PushPullWrapMode : CWChiselMode
{
	public override int MaxStrength => 15;

	public PushPullWrapMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		int distance = CurrentStrength;
		if (isBreak)
		{
			distance = -distance;
		}
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = false
		};
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			bp.PushVoxelsWrapping(distance, facing);
			return bp;
		}, beChisel, options);
		return false;
	}
}




