﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Client;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;
using VSSurvivalMod.Systems.ChiselModes;

namespace ChiselWiz.ChiselToolModes;

public class CWChiselMode : ChiselMode
{
	protected ChiselOperator chiseller;

	public int CurrentStrength = 1;

	public bool UseMaterialsInNearbyInventories;

	public virtual int MaxStrength => 1;

	protected Cuboidf[] SelectionBoxCube => (Cuboidf[])(object)new Cuboidf[1]
	{
		new Cuboidf(0f, 0f, 0f, 1f, 1f, 1f)
	};

	protected Cuboidf[] SelectionBoxesAllFaces
	{
		get
		{

			float num = 0.0625f;
			return (Cuboidf[])(object)new Cuboidf[6]
			{
				new Cuboidf(0f, 0f, 0f, num, 1f, 1f),
				new Cuboidf(0f, 0f, 0f, 1f, num, 1f),
				new Cuboidf(0f, 0f, 0f, 1f, 1f, num),
				new Cuboidf(1f - num, 0f, 0f, 1f, 1f, 1f),
				new Cuboidf(0f, 1f - num, 0f, 1f, 1f, 1f),
				new Cuboidf(0f, 0f, 1f - num, 1f, 1f, 1f)
			};
		}
	}

	protected Cuboidf[] SelectionBoxesHorizontalFaces
	{
		get
		{

			float num = 0.0625f;
			return (Cuboidf[])(object)new Cuboidf[4]
			{
				new Cuboidf(0f, 0f, 0f, num, 1f, 1f),
				new Cuboidf(0f, 0f, 0f, 1f, 1f, num),
				new Cuboidf(1f - num, 0f, 0f, 1f, 1f, 1f),
				new Cuboidf(0f, 0f, 1f - num, 1f, 1f, 1f)
			};
		}
	}

	protected Cuboidf[] SelectionBoxesVerticalFaces
	{
		get
		{

			float num = 0.0625f;
			return (Cuboidf[])(object)new Cuboidf[2]
			{
				new Cuboidf(0f, 0f, 0f, 1f, num, 1f),
				new Cuboidf(0f, 1f - num, 0f, 1f, 1f, 1f)
			};
		}
	}

	public static void OrientBlueprintUDH(BlockBlueprint bp, BlockFacing playerFace, BlockFacing blockFace)
	{
		BlockFacing val = playerFace;
		if (blockFace == BlockFacing.UP || blockFace == BlockFacing.DOWN)
		{
			int num = ((blockFace == BlockFacing.DOWN) ? 1 : 3);
			for (int i = 0; i < num; i++)
			{
				bp.XAxisRot();
			}
		}
		else
		{
			val = blockFace.Opposite;
		}
		int num2 = 0;
		switch (val.Index)
		{
		case 0:
			num2 = 0;
			break;
		case 1:
			num2 = 1;
			break;
		case 2:
			num2 = 2;
			break;
		case 3:
			num2 = 3;
			break;
		}
		for (int j = 0; j < num2; j++)
		{
			bp.YAxisRot();
		}
	}

	public CWChiselMode(ChiselOperator chiseller)
	{
		this.chiseller = chiseller;
	}

	public override DrawSkillIconDelegate DrawAction(ICoreClientAPI capi)
	{
		return null;
	}

	public virtual Cuboidf[] GenerateSelectionBoxes(BlockEntityChisel beChisel)
	{
		return null;
	}
}




