﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class AddShapeMode : CWChiselMode
{
	public AddShapeMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = true
		};
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			BlockBlueprint clipboardBlueprint = chiseller.ClipboardBlueprint;
			if (clipboardBlueprint == null)
			{
				return bp;
			}
			bp.BoolOp(clipboardBlueprint, BoolOpEnum.Add, currentMaterialIndex);
			return bp;
		}, beChisel, options);
		return true;
	}
}




