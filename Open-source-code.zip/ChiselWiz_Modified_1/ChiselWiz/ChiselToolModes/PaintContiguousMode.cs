﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class PaintContiguousMode : CWChiselMode
{
	public PaintContiguousMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		int index = ((BlockEntityMicroBlock)beChisel).BlockIds[currentMaterialIndex];
		Block val = ((BlockEntity)beChisel).Api.World.Blocks[index];
		AssetLocation newMaterialCode = ((RegistryObject)val).Code;
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = true
		};
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			bp.PaintContiguous(voxelPos, newMaterialCode);
			return bp;
		}, beChisel, options);
		return false;
	}
}




