﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class InvertMode : CWChiselMode
{
	public InvertMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override Cuboidf[] GenerateSelectionBoxes(BlockEntityChisel beChisel)
	{
		return base.SelectionBoxCube;
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = false
		};
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			bp.Invert();
			return bp;
		}, beChisel, options);
		return false;
	}
}




