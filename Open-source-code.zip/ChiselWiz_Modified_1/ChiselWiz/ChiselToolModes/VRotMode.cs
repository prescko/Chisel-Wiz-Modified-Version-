﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes;

internal class VRotMode : CWChiselMode
{
	public override int MaxStrength => 2;

	public VRotMode(ChiselOperator chiseller)
		: base(chiseller)
	{
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing facing, bool isBreak, byte currentMaterialIndex)
	{

		bool flag = isBreak;
		int turns = (flag ? CurrentStrength : (4 - CurrentStrength));
		facing = Block.SuggestedHVOrientation(byPlayer, new BlockSelection
		{
			Position = ((BlockEntity)beChisel).Pos.Copy(),
			HitPosition = new Vec3d((double)voxelPos.X / 16.0, (double)voxelPos.Y / 16.0, (double)voxelPos.Z / 16.0)
		})[0].Opposite;
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = false
		};
		chiseller.Apply(delegate(BlockBlueprint bp)
		{
			for (int i = 0; i < turns; i++)
			{
				bp.VRot(facing);
			}
			return bp;
		}, beChisel, options);
		return false;
	}
}




