﻿using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.ChiselToolModes.ImageTools;

internal class ImageMergeExtrudedShapeMode : CWChiselMode
{
	private bool replace;

	public override int MaxStrength => 16;

	public override Cuboidf[] GenerateSelectionBoxes(BlockEntityChisel beChisel)
	{
		return base.SelectionBoxCube;
	}

	public ImageMergeExtrudedShapeMode(ChiselOperator chiseller, bool replace)
		: base(chiseller)
	{
		this.replace = replace;
	}

	public override bool Apply(BlockEntityChisel beChisel, IPlayer byPlayer, Vec3i voxelPos, BlockFacing blockFace, bool isBreak, byte currentMaterialIndex)
	{
		BlockFacing playerFacing = BlockFacing.HorizontalFromYaw(((Entity)byPlayer.Entity).Pos.Yaw);
		BlockBlueprint bp = chiseller.ClipboardBlueprint?.Clone();
		if (bp == null)
		{
			return false;
		}
		int extrudeSize = CurrentStrength;
		ChiselOperator.ChiselOptions options = new ChiselOperator.ChiselOptions
		{
			addMissingMaterials = true,
			useMaterialsInNearbyInventories = UseMaterialsInNearbyInventories
		};
		ChiselOperator.ChiselJob job = chiseller.Apply(delegate(BlockBlueprint srcBp)
		{
			for (int i = 1; i < extrudeSize; i++)
			{
				bp.CopyLayer(0, i);
			}
			CWChiselMode.OrientBlueprintUDH(bp, playerFacing, blockFace);
			BlockBlueprint blockBlueprint = srcBp.Clone();
			blockBlueprint.MergeDesign(bp, addMissingVoxels: true, replace, removeExtraVoxels: false);
			blockBlueprint.Name = bp.Name;
			blockBlueprint.SetNameOnPaste = bp.SetNameOnPaste;
			return blockBlueprint;
		}, beChisel, options);
		job.OnComplete = delegate
		{
			if (job.OperationCount > 0)
			{
				chiseller.TadaaFx(((BlockEntity)beChisel).Pos);
			}
		};
		return true;
	}
}




