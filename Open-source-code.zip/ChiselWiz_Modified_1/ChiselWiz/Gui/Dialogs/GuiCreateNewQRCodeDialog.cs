﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Images;
using ChiselWiz.Systems.Images.Colouring;
using ChiselWiz.Systems.Images.Designs;
using SkiaSharp;
using SkiaSharp.QrCode;
using SkiaSharp.QrCode.Image;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Dialogs;

public class GuiCreateNewQRCodeDialog : GuiDialog
{
	private readonly ImageDesignLoader imageDesignLoader;

	private readonly GuiImageToolDialogBase guiImageTool;

	private ImageDesign design;

	private GuiElementCWImage thumbPreviewElement;

	private Progress<double> rebuildProgress;

	private string url = "https://";

	private int scale = 1;

	private long updatePreviewDebounceTimer;

	private CancellationTokenSource ctsUpdatePreviewImage;

	private List<ErrorCorrectionOption> errorCorrectionOptions;

	private ErrorCorrectionOption selectedErrorCorrectionLevel;

	public override string ToggleKeyCombinationCode => null;

	public override bool PrefersUngrabbedMouse => false;

	public override EnumDialogType DialogType => (EnumDialogType)0;

	public GuiCreateNewQRCodeDialog(ICoreClientAPI capi, ImageDesignLoader imageDesignLoader, GuiImageToolDialogBase guiImageTool)
		: base(capi)
	{
		this.imageDesignLoader = imageDesignLoader;
		this.guiImageTool = guiImageTool;
		rebuildProgress = new Progress<double>(UpdateProgressBar);
		int num = 4;
		List<ErrorCorrectionOption> list = new List<ErrorCorrectionOption>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<ErrorCorrectionOption> span = CollectionsMarshal.AsSpan(list);
		int num2 = 0;
		span[num2] = new ErrorCorrectionOption
		{
			Key = "l",
			Name = "~7% data recovery (Level L)",
			Enum = ECCLevel.L
		};
		num2++;
		span[num2] = new ErrorCorrectionOption
		{
			Key = "m",
			Name = "~15% data recovery (Level M)",
			Enum = ECCLevel.M
		};
		num2++;
		span[num2] = new ErrorCorrectionOption
		{
			Key = "q",
			Name = "~25% data recovery (Level Q)",
			Enum = ECCLevel.Q
		};
		num2++;
		span[num2] = new ErrorCorrectionOption
		{
			Key = "h",
			Name = "~30% data recovery (Level H)",
			Enum = ECCLevel.H
		};
		errorCorrectionOptions = list;
	}

	public override void Dispose()
	{
		base.Dispose();
		design?.Dispose();
	}

	public override bool TryOpen()
	{
		Compose();
		UpdatePreviewImageAsync();
		return base.TryOpen();
	}

	public override bool TryClose()
	{
		CancelPendingPreviewImageUpdate();
		return base.TryClose();
	}

	private void Compose()
	{

		((GuiDialog)this).ClearComposers();
		CairoFont font = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2);
		CairoFont val = CairoFont.WhiteSmallishText();
		CairoFont val2 = CairoFont.WhiteSmallText();
		CairoFont val3 = val2.Clone().WithColor(ColorUtil.Hex2Doubles("#55cc55"));
		ElementBounds val4 = ElementBounds.Fixed((EnumDialogArea)6, 0.0, 0.0, 800.0, GuiStyle.TitleBarHeight + 345.0);
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val5 = ElementBounds.Fixed(10.0, GuiStyle.TitleBarHeight + 10.0, 325.0, 325.0).WithParent(val4);
		ElementBounds val6 = val5.ForkChildOffseted(4.0, 4.0, -8.0, -8.0);
		ElementBounds bounds = val6.CopyOffsetedSibling(0.0, val6.fixedHeight / 2.0 - 25.0, 0.0, 0.0).WithFixedHeight(50.0);
		ElementBounds val7 = val5.RightCopy(10.0, 0.0, 0.0, 0.0).WithFixedSize(800.0 - val5.fixedWidth - 30.0, 26.0);
		ElementBounds val8 = val7.BelowCopy(0.0, 0.0, 0.0, 10.0);
		ElementBounds val9 = val8.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedHeight(30.0);
		ElementBounds val10 = val9.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight(26.0);
		ElementBounds val11 = val10.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedSize(val7.fixedWidth, 30.0);
		ElementBounds val12 = val11.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds val13 = val12.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds bounds2 = val13.BelowCopy(60.0, 15.0, -120.0, 0.0).WithFixedHeight(35.0);
		GuiComposer val14 = Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("chiselwiz:qccreator", val4), fill, true, 5.0, 0.75f), Lang.Get("chiselwiz:Create QR Code", Array.Empty<object>()), (Action)delegate
		{
			((GuiDialog)this).TryClose();
		}, (CairoFont)null, (ElementBounds)null, (string)null).BeginChildElements();
		GuiElementInsetHelper.AddInset(val14, val5.FlatCopy(), 4, 0.85f);
		thumbPreviewElement = new GuiElementCWImage(base.capi, val6);
		val14.AddInteractiveElement((GuiElement)(object)thumbPreviewElement, "thumbPreview");
		GuiElementProgressBar guiElementProgressBar = new GuiElementProgressBar(base.capi, bounds, Lang.Get("chiselwiz:Processing...", Array.Empty<object>()), 9)
		{
			Visible = false
		};
		val14.AddInteractiveElement((GuiElement)(object)guiElementProgressBar, "progressBar");
		GuiElementDynamicTextHelper.AddDynamicText(val14, Lang.Get("chiselwiz:URL or Text", Array.Empty<object>()), val, val7, (string)null);
		GuiElementTextInput val15 = new GuiElementTextInput(base.capi, val8, (Action<string>)OnUrlChanged, val2);
		val14.AddInteractiveElement((GuiElement)(object)val15, "urlInput");
		((GuiElementEditableTextBase)val15).SetValue(url, true);
		GuiElementDynamicTextHelper.AddDynamicText(val14, Lang.Get("chiselwiz:Error Correction Level", Array.Empty<object>()), val, val9, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddDropDown(val14, errorCorrectionOptions.Select((ErrorCorrectionOption o) => o.Key).ToArray(), errorCorrectionOptions.Select((ErrorCorrectionOption o) => o.Name).ToArray(), 0, (SelectionChangedDelegate)delegate(string key, bool multi)
		{
			selectedErrorCorrectionLevel = errorCorrectionOptions.Find((ErrorCorrectionOption o) => o.Key == key);
			DebouncedUpdatePreviewImage();
		}, val10, "errorCorrectionLevel");
		GuiElementDynamicTextHelper.AddDynamicText(val14, Lang.Get("chiselwiz:QR Code Scale", Array.Empty<object>()), val, val11, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddSlider(val14, (ActionConsumable<int>)OnScaleChanged, val12, "scaleSlider");
		GuiElementDynamicTextHelper.AddDynamicText(val14, "", val3, val13, "scaleTipText");
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/import.svg"), Lang.Get("chiselwiz:Import QR Code", Array.Empty<object>()), font, new ActionConsumable(OnClickCreate), bounds2, (EnumButtonStyle)2);
		val14.AddInteractiveElement((GuiElement)(object)guiElementIconButton, "createBtn");
		val14.EndChildElements();
		((GuiDialog)this).SingleComposer = val14.Compose(true);
		InitScaleSliderValues();
		if (selectedErrorCorrectionLevel != null)
		{
			Vintagestory.API.Client.GuiComposerHelpers.GetDropDown(((GuiDialog)this).SingleComposer, "errorCorrectionLevel").SetSelectedValue(new string[1] { selectedErrorCorrectionLevel.Key });
		}
	}

	private void OnUrlChanged(string newUrl)
	{
		url = newUrl;
		DebouncedUpdatePreviewImage();
	}

	private bool OnScaleChanged(int newScale)
	{
		scale = newScale;
		UpdateSliderHint();
		DebouncedUpdatePreviewImage();
		return true;
	}

	private bool OnClickCreate()
	{
		try
		{
			CancelPendingPreviewImageUpdate();
			if (design == null)
			{
				throw new VSException("QR Code data is not generated.");
			}
			guiImageTool.SetImageDesign(design.Copy());
			((GuiDialog)guiImageTool).TryOpen();
			((GuiDialog)this).TryClose();
		}
		catch (VSException ex)
		{
			ex.DisplayError(base.capi);
		}
		catch (Exception ex2)
		{
			((ICoreAPI)base.capi).Logger.Error(ex2);
		}
		return true;
	}

	private void InitScaleSliderValues()
	{
		Vintagestory.API.Client.GuiComposerHelpers.GetSlider(((GuiDialog)this).SingleComposer, "scaleSlider").SetValues(scale, 1, 4, 1, "");
		UpdateSliderHint();
	}

	private void UpdateSliderHint()
	{
		GuiElementDynamicText dynamicText = GuiElementDynamicTextHelper.GetDynamicText(((GuiDialog)this).SingleComposer, "scaleTipText");
		if (design != null)
		{
			int value = (int)Math.Ceiling((double)design.Width / 16.0);
			int value2 = (int)Math.Ceiling((double)design.Height / 16.0);
			string text = $"{value} Г— {value2} blocks / {design.Width} Г— {design.Height} voxels";
			dynamicText.SetNewText(text, false, false, false);
		}
		else
		{
			dynamicText.SetNewText("", false, false, false);
		}
	}

	private void DebouncedUpdatePreviewImage()
	{
		CancelPendingPreviewImageUpdate();
		updatePreviewDebounceTimer = ((IEventAPI)base.capi.Event).RegisterCallback((Action<float>)delegate
		{
			UpdatePreviewImageAsync();
		}, 250);
	}

	private void CancelPendingPreviewImageUpdate()
	{
		UpdateProgressBar(0.0);
		ctsUpdatePreviewImage?.Cancel();
		if (updatePreviewDebounceTimer != -1)
		{
			((IEventAPI)base.capi.Event).UnregisterCallback(updatePreviewDebounceTimer);
			updatePreviewDebounceTimer = -1L;
		}
	}

	private async void UpdatePreviewImageAsync()
	{
		CancelPendingPreviewImageUpdate();
		if (string.IsNullOrWhiteSpace(url))
		{
			design?.Dispose();
			design = null;
			thumbPreviewElement?.SetBitmap(null);
			SetCreateButtonEnabled(enabled: false);
			return;
		}
		CancellationTokenSource cts = new CancellationTokenSource();
		try
		{
			ctsUpdatePreviewImage = cts;
			CancellationToken cancellationToken = cts.Token;
			SetCreateButtonEnabled(enabled: false);
			ImageDesign newDesign = await Task.Run(delegate
			{

				ECCLevel eccLevel = ECCLevel.L;
				if (selectedErrorCorrectionLevel != null)
				{
					eccLevel = selectedErrorCorrectionLevel.Enum;
				}
				QRCodeData qRCodeData = QRCodeGenerator.CreateQrCode(url, eccLevel);
				int num = qRCodeData.Size * scale;
				SKSurface val = SKSurface.Create(new SKImageInfo(num, num));
				try
				{
					QRCodeRenderer.Render(val.Canvas, SKRect.Create((float)num, (float)num), qRCodeData, (SKColor?)new SKColor((byte)0, (byte)0, (byte)0), (SKColor?)new SKColor(byte.MaxValue, byte.MaxValue, byte.MaxValue), (IconData?)null, (ModuleShape?)null, 1f, (GradientOptions?)null);
					SKImage val2 = val.Snapshot();
					try
					{
						SKBitmap val3 = SKBitmap.Decode(val2.Encode((SKEncodedImageFormat)4, 100).ToArray());
						try
						{
							ImageDesign imageDesign = imageDesignLoader.CreateDesign(val3, val3.Width, val3.Height, EnumPaletteReductionMethod.BlackWhite);
							imageDesign.Name = url;
							imageDesign.ComputePaletteColourMapping(rebuildProgress, cancellationToken);
							imageDesign.RedrawPreviewBitmap();
							return imageDesign;
						}
						finally
						{
							((IDisposable)val3)?.Dispose();
						}
					}
					finally
					{
						((IDisposable)val2)?.Dispose();
					}
				}
				finally
				{
					((IDisposable)val)?.Dispose();
				}
			}, cancellationToken);
			((IEventAPI)base.capi.Event).EnqueueMainThreadTask((Action)delegate
			{
				design?.Dispose();
				design = newDesign;
				if (design?.PreviewBitmap != null)
				{
					thumbPreviewElement?.SetBitmap(design.PreviewBitmap);
				}
				SetCreateButtonEnabled(design != null);
				UpdateProgressBar(0.0);
				UpdateSliderHint();
			}, "setcwqrcodepreview");
		}
		catch (OperationCanceledException)
		{
		}
		finally
		{
			cts?.Dispose();
			if (ctsUpdatePreviewImage == cts)
			{
				ctsUpdatePreviewImage = null;
			}
		}
	}

	private void SetCreateButtonEnabled(bool enabled)
	{
		GuiComposer singleComposer = ((GuiDialog)this).SingleComposer;
		GuiElementIconButton guiElementIconButton = (GuiElementIconButton)(object)((singleComposer != null) ? singleComposer.GetElement("createBtn") : null);
		if (guiElementIconButton != null)
		{
			((GuiElementControl)guiElementIconButton).Enabled = enabled;
		}
	}

	private void UpdateProgressBar(double val)
	{
		if (((GuiDialog)this).SingleComposer != null)
		{
			GuiElementProgressBar obj = (GuiElementProgressBar)(object)((GuiDialog)this).SingleComposer.GetElement("progressBar");
			obj.Visible = val > 0.0;
			obj.Progress = val;
		}
	}
}




