﻿using System;
using ChiselWiz.Gui.Elements;
using Vintagestory.API.Client;
using Vintagestory.API.Config;

namespace ChiselWiz.Gui.Dialogs;

public class HudProgressBar : HudElement
{
	private double progress;

	private int queuedJobsCount;

	public double Progress
	{
		get
		{
			return progress;
		}
		set
		{
			progress = Math.Clamp(value, 0.0, 1.0);
			UpdateProgressText();
		}
	}

	public int QueuedJobs
	{
		get
		{
			return queuedJobsCount;
		}
		set
		{
			queuedJobsCount = value;
			UpdateProgressText(includingQueuedText: true);
		}
	}

	public override string ToggleKeyCombinationCode => null;

	public override bool PrefersUngrabbedMouse => false;

	public HudProgressBar(ICoreClientAPI capi)
		: base(capi)
	{
		Compose();
	}

	private void Compose()
	{
		((GuiDialog)this).ClearComposers();
		ElementBounds val = ElementBounds.Fixed((EnumDialogArea)6, 0.0, -200.0, 200.0, 50.0);
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val2 = ElementBounds.Fixed(0.0, 0.0, 200.0, 40.0).WithParent(val);
		val2.FlatCopy();
		ElementBounds val3 = val2.BelowCopy(0.0, 0.0, 0.0, 0.0);
		GuiComposer val4 = capi.Gui.CreateCompo("progressbar", val).BeginChildElements(fill);
		GuiElementProgressBar guiElementProgressBar = new GuiElementProgressBar(capi, val2, "", 4);
		val4.AddInteractiveElement((GuiElement)(object)guiElementProgressBar, "progressBar");
		GuiElementDynamicTextHelper.AddDynamicText(val4, "", CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2), val3, "progressTextQueued");
		((GuiDialog)this).SingleComposer = val4.EndChildElements().Compose(true);
		UpdateProgressText(includingQueuedText: true);
	}

	private void UpdateProgressText(bool includingQueuedText = false)
	{
		if (((GuiDialog)this).SingleComposer != null)
		{
			GuiElementProgressBar obj = (GuiElementProgressBar)(object)((GuiDialog)this).SingleComposer.GetElement("progressBar");
			obj.Progress = progress;
			obj.SetText($"{progress:P0}");
			if (includingQueuedText)
			{
				string text = ((queuedJobsCount > 0) ? Lang.Get("chiselwiz:+ {0} more queued", new object[1] { queuedJobsCount }) : "");
				GuiElementDynamicTextHelper.GetDynamicText(((GuiDialog)this).SingleComposer, "progressTextQueued").SetNewText(text, false, false, true);
			}
		}
	}
}




