﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Images;
using ChiselWiz.Systems.Images.Colouring;
using ChiselWiz.Systems.Images.Designs;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;

namespace ChiselWiz.Gui.Dialogs;

public class GuiImportImageDialog : GuiDialog
{
	private static readonly int imageMaxLongestSide = 256;

	private ImageDesignLoader imageDesignLoader;

	private GuiImageToolDialogBase guiImageTool;

	private SKBitmap loadedBitmap;

	private GuiElementCWImage thumbPreviewElement;

	private Progress<double> rebuildProgress;

	private bool highPixelDensityMode;

	private string selectedFilePath;

	private SizeInfo selectedSizeOption;

	private ColourReductionOption selectedColourReductionOption;

	private List<ColourReductionOption> colourReductionOptions;

	private long updatePreviewDebounceTimer;

	private CancellationTokenSource? ctsUpdatePreviewImage;

	private static string ImagesPath => Path.Combine(GamePaths.ModConfig, "chiselwiz-images");

	public override string ToggleKeyCombinationCode => null;

	public override bool PrefersUngrabbedMouse => false;

	public override EnumDialogType DialogType => (EnumDialogType)0;

	private ImageDesign design { get; set; }

	public GuiImportImageDialog(ICoreClientAPI capi, ImageDesignLoader imageDesignLoader, GuiImageToolDialogBase guiImageTool)
		: base(capi)
	{
		this.imageDesignLoader = imageDesignLoader;
		this.guiImageTool = guiImageTool;
		rebuildProgress = new Progress<double>(delegate(double val)
		{
			UpdateProgressBar(val);
		});
	}

	private void SetupColourReductionOptions()
	{

		Palettes palettes = imageDesignLoader.LoadPalettes();
		colourReductionOptions = new List<ColourReductionOption>();
		if (!highPixelDensityMode)
		{
			colourReductionOptions.Add(new ColourReductionOption
			{
				Key = "none",
				Name = Lang.Get("chiselwiz:None (manual block assignment)", Array.Empty<object>()),
				Enum = EnumPaletteReductionMethod.None,
				AllowReduction = false,
				AutoMatch = false
			});
		}
		foreach (Palette item in palettes)
		{
			if (!item.HideFromMenu)
			{
				bool flag = (int)((IPlayer)base.capi.World.Player).WorldData.CurrentGameMode == 2;
				if ((!item.RequiresCreativeMode || flag) && (!highPixelDensityMode || item.ValidForHighPixelDensity) && (highPixelDensityMode || item.ValidForLowPixelDensity))
				{
					colourReductionOptions.Add(new ColourReductionOption
					{
						Key = "palette:" + item.Key,
						Name = Lang.Get("chiselwiz:{0} ({1} materials)", new object[2]
						{
							item.Name,
							item.Entries.Length
						}),
						Enum = EnumPaletteReductionMethod.None,
						AllowReduction = true,
						AutoMatch = true,
						MasterPalette = item
					});
				}
			}
		}
		if (!highPixelDensityMode)
		{
			colourReductionOptions.Add(new ColourReductionOption
			{
				Key = "bw",
				Name = Lang.Get("chiselwiz:Black & White", Array.Empty<object>()),
				Enum = EnumPaletteReductionMethod.BlackWhite,
				AllowReduction = false,
				AutoMatch = true
			});
		}
		ReselectActiveColourReductionOption();
	}

	private void ReselectActiveColourReductionOption()
	{
		GuiComposer singleComposer = ((GuiDialog)this).SingleComposer;
		GuiElementDropDown val = ((singleComposer != null) ? Vintagestory.API.Client.GuiComposerHelpers.GetDropDown(singleComposer, "colourOptionSelector") : null);
		if (selectedColourReductionOption != null && val != null)
		{
			int num = colourReductionOptions.FindIndex((ColourReductionOption opt) => opt.Key == selectedColourReductionOption.Key);
			if (num == -1)
			{
				num = 0;
			}
			selectedColourReductionOption = colourReductionOptions[num];
			val.SetList(colourReductionOptions.Select((ColourReductionOption qo) => qo.Key).ToArray(), colourReductionOptions.Select((ColourReductionOption qo) => qo.Name).ToArray());
			val.SetSelectedIndex(num);
			val.listMenu.HoveredIndex = num;
		}
	}

	public override void Dispose()
	{
		base.Dispose();
		SKBitmap obj = loadedBitmap;
		if (obj != null)
		{
			((SKNativeObject)obj).Dispose();
		}
	}

	public override bool TryOpen()
	{
		Compose();
		return base.TryOpen();
	}

	public override bool TryClose()
	{
		CancelPendingPreviewImageUpdate();
		return base.TryClose();
	}

	private void Compose()
	{

		((GuiDialog)this).ClearComposers();
		SetupColourReductionOptions();
		int num = 800;
		CairoFont font = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2);
		CairoFont val = CairoFont.WhiteSmallishText();
		CairoFont val2 = CairoFont.WhiteSmallText();
		CairoFont val3 = val2.Clone().WithColor(ColorUtil.Hex2Doubles("#55cc55"));
		CairoFont font2 = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2).WithColor(ColorUtil.Hex2Doubles("#ff0000ff"));
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val4 = ElementBounds.Fixed((EnumDialogArea)6, 0.0, 0.0, (double)num, GuiStyle.TitleBarHeight + 345.0);
		ElementBounds val5 = ElementBounds.Fixed(10.0, GuiStyle.TitleBarHeight + 10.0, 325.0, 325.0).WithParent(val4);
		ElementBounds val6 = val5.ForkChildOffseted(4.0, 4.0, -8.0, -8.0);
		ElementBounds val7 = val6.CopyOffsetedSibling(0.0, val6.fixedHeight / 2.0 - 25.0, 0.0, 0.0).WithFixedHeight(50.0);
		ElementBounds bounds = val7.FlatCopy();
		ElementBounds val8 = val5.RightCopy(10.0, 0.0, 0.0, 0.0).WithFixedSize((double)num - val5.fixedWidth - 30.0, 26.0);
		ElementBounds val9 = val8.BelowCopy(0.0, 0.0, -180.0, 0.0).WithFixedHeight(35.0);
		ElementBounds val10 = val9.RightCopy(10.0, 0.0, 0.0, 0.0).WithFixedWidth(170.0);
		ElementBounds val11 = val9.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedSize(val8.fixedWidth, 30.0);
		ElementBounds val12 = val11.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds val13 = val12.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds val14 = val13.BelowCopy(0.0, 5.0, 0.0, 0.0);
		ElementBounds val15 = val14.CopyOffsetedSibling(35.0, 5.0, -35.0, 0.0);
		ElementBounds val16 = val14.FlatCopy().WithFixedWidth(30.0);
		ElementBounds val17 = val14.BelowCopy(0.0, 10.0, 0.0, 0.0);
		ElementBounds val18 = val17.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds bounds2 = val18.BelowCopy(60.0, 15.0, -120.0, 0.0).WithFixedHeight(35.0);
		GuiComposer val19 = Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("chiselwiz:imageimporter", val4), fill, true, 5.0, 0.75f), Lang.Get("chiselwiz:Import Image", Array.Empty<object>()), (Action)delegate
		{
			((GuiDialog)this).TryClose();
		}, (CairoFont)null, (ElementBounds)null, (string)null).BeginChildElements();
		GuiElementInsetHelper.AddInset(val19, val5.FlatCopy(), 4, 0.85f);
		thumbPreviewElement = new GuiElementCWImage(base.capi, val6);
		val19.AddInteractiveElement((GuiElement)(object)thumbPreviewElement, "thumbPreview");
		GuiElementProgressBar guiElementProgressBar = new GuiElementProgressBar(base.capi, val7, Lang.Get("chiselwiz:Processing...", Array.Empty<object>()), 9);
		guiElementProgressBar.Visible = false;
		val19.AddInteractiveElement((GuiElement)(object)guiElementProgressBar, "progressBar");
		GuiElementCWDynamicText guiElementCWDynamicText = new GuiElementCWDynamicText(base.capi, Lang.Get("chiselwiz:Error: Bad Image", Array.Empty<object>()), font2, bounds);
		val19.AddInteractiveElement((GuiElement)(object)guiElementCWDynamicText, "imageErrorText");
		ICoreClientAPI capi = base.capi;
		AssetLocation val20 = new AssetLocation("chiselwiz", "textures/icons/open.svg");
		string text = Lang.Get("chiselwiz:Open Folder", Array.Empty<object>());
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(capi, val20, text, font, (ActionConsumable)delegate { NetUtil.OpenUrlInBrowser(ImagesPath); return true; }, val10, (EnumButtonStyle)3);
		val19.AddInteractiveElement((GuiElement)(object)guiElementIconButton, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val19, Lang.Get("Place image files into this \"chiselwiz-images\" folder to make them available to be imported.", Array.Empty<object>()), val2, 350, val10, (string)null);
		GuiElementDynamicTextHelper.AddDynamicText(val19, Lang.Get("chiselwiz:Select Image File", Array.Empty<object>()), val, val8, (string)null);
		GuiElementCWDropDown guiElementCWDropDown = new GuiElementCWDropDown(base.capi, new string[1] { "" }, new string[1] { "" }, -1, (SelectionChangedDelegate)delegate(string text2, bool idx)
		{
			if (text2 != "")
			{
				selectedFilePath = text2;
				TryLoadImage(text2);
			}
		}, val9, val2, multiSelect: false);
		guiElementCWDropDown.OnListOpened = delegate
		{
			UpdateFileList();
		};
		val19.AddInteractiveElement((GuiElement)(object)guiElementCWDropDown, "fileSelector");
		GuiElementDynamicTextHelper.AddDynamicText(val19, Lang.Get("chiselwiz:Resize Image", Array.Empty<object>()), val, val11, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddSlider(val19, (ActionConsumable<int>)delegate(int maxLength)
		{
			if (selectedSizeOption == null || loadedBitmap == null)
			{
				return true;
			}
			selectedSizeOption = CalcResize(loadedBitmap.Width, loadedBitmap.Height, maxLength);
			UpdateSliderHint();
			DebouncedUpdatePreviewImage();
			return true;
		}, val12, "resizeSlider");
		GuiElementDynamicTextHelper.AddDynamicText(val19, "", val3, val13, "resizeTipText");
		Vintagestory.API.Client.GuiComposerHelpers.AddSwitch(val19, (Action<bool>)delegate(bool flag)
		{
			highPixelDensityMode = flag;
			SetupColourReductionOptions();
			UpdateSliderHint();
			DebouncedUpdatePreviewImage();
		}, val16, "highdpiSwitch", 30.0, 4.0);
		GuiElementDynamicTextHelper.AddDynamicText(val19, Lang.Get("chiselwiz:High Pixel Density Mode", Array.Empty<object>()), val2, val15, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val19, Lang.Get("chiselwiz:High density tip", Array.Empty<object>()), val2, 450, val14, (string)null);
		GuiElementDynamicTextHelper.AddDynamicText(val19, Lang.Get("chiselwiz:Select Block Palette", Array.Empty<object>()), val, val17, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddDropDown(val19, colourReductionOptions.Select((ColourReductionOption qo) => qo.Key).ToArray(), colourReductionOptions.Select((ColourReductionOption qo) => qo.Name).ToArray(), 0, (SelectionChangedDelegate)delegate(string text2, bool selected)
		{
			selectedColourReductionOption = colourReductionOptions.Find((ColourReductionOption qo) => qo.Key == text2);
			DebouncedUpdatePreviewImage();
		}, val18, "colourOptionSelector");
		GuiElementIconButton guiElementIconButton2 = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/import.svg"), Lang.Get("chiselwiz:Import Image", Array.Empty<object>()), font, new ActionConsumable(OnClickImport), bounds2, (EnumButtonStyle)2);
		val19.AddInteractiveElement((GuiElement)(object)guiElementIconButton2, "importBtn");
		val19.EndChildElements();
		((GuiDialog)this).SingleComposer = val19.Compose(true);
		if (design?.PreviewBitmap != null)
		{
			thumbPreviewElement?.SetBitmap(design.PreviewBitmap);
		}
		InitResizeSliderValues(resetSlider: false);
		if (selectedColourReductionOption == null)
		{
			selectedColourReductionOption = colourReductionOptions[0];
		}
		Vintagestory.API.Client.GuiComposerHelpers.GetSwitch(((GuiDialog)this).SingleComposer, "highdpiSwitch").SetValue(highPixelDensityMode);
		ReselectActiveColourReductionOption();
		UpdateFileList();
		if (selectedFilePath != null)
		{
			((GuiElementDropDown)guiElementCWDropDown).SetSelectedValue(new string[1] { selectedFilePath });
		}
	}

	private void EnsurePathExists(string path)
	{
		if (!Directory.Exists(path))
		{
			Directory.CreateDirectory(path);
		}
	}

	private void UpdateFileList()
	{
		GuiComposer singleComposer = ((GuiDialog)this).SingleComposer;
		GuiElementCWDropDown guiElementCWDropDown = (GuiElementCWDropDown)(object)((singleComposer != null) ? singleComposer.GetElement("fileSelector") : null);
		if (guiElementCWDropDown == null)
		{
			return;
		}
		string[] imageFileList = GetImageFileList();
		if (imageFileList.Length != 0)
		{
			string[] array = imageFileList.Select((string path) => Path.GetFileName(path)).ToArray();
			((GuiElementDropDown)guiElementCWDropDown).SetList(imageFileList, array);
		}
		else
		{
			((GuiElementDropDown)guiElementCWDropDown).SetList(new string[1] { "" }, new string[1] { "- " + Lang.Get("chiselwiz:Folder is empty", Array.Empty<object>()) + " -" });
			((GuiElementDropDown)guiElementCWDropDown).SetSelectedIndex(0);
		}
	}

	private string[] GetImageFileList()
	{
		EnsurePathExists(ImagesPath);
		return Directory.GetFiles(ImagesPath);
	}

	private void TryLoadImage(string path, bool resetSlider = true)
	{
		SKBitmap obj = loadedBitmap;
		if (obj != null)
		{
			((SKNativeObject)obj).Dispose();
		}
		loadedBitmap = null;
		GuiElementCWDynamicText guiElementCWDynamicText = (GuiElementCWDynamicText)(object)((GuiDialog)this).SingleComposer.GetElement("imageErrorText");
		try
		{
			guiElementCWDynamicText.Visible = false;
			loadedBitmap = ImageDesignLoader.LoadBitmap(path);
			InitResizeSliderValues(resetSlider);
			UpdatePreviewImageAsync();
		}
		catch (Exception ex)
		{
			thumbPreviewElement.SetBitmap(null);
			guiElementCWDynamicText.Visible = true;
			design = null;
			InitResizeSliderValues(resetSlider: true);
			SetImportButtonEnabled(enabled: false);
			((ICoreAPI)base.capi).Logger.Warning("Error: " + ex.Message);
		}
	}

	private void InitResizeSliderValues(bool resetSlider)
	{
		GuiElementSlider slider = Vintagestory.API.Client.GuiComposerHelpers.GetSlider(((GuiDialog)this).SingleComposer, "resizeSlider");
		if (loadedBitmap == null)
		{
			slider.SetValues(0, 0, 1, 1, "");
			UpdateSliderHint();
			return;
		}
		int num = Math.Min(imageMaxLongestSide, Math.Max(loadedBitmap.Width, loadedBitmap.Height));
		if (resetSlider)
		{
			selectedSizeOption = CalcResize(loadedBitmap.Width, loadedBitmap.Height, num);
		}
		int longestSide = selectedSizeOption.LongestSide;
		int num2 = 1;
		if (num2 == longestSide)
		{
			num2 = 0;
		}
		slider.SetValues(longestSide, num2, num, 1, "");
		UpdateSliderHint();
	}

	private SizeInfo CalcResize(int width, int height, int maxLength)
	{
		int num;
		int num2;
		if (width > height)
		{
			num = maxLength;
			num2 = (int)Math.Round((float)height * ((float)maxLength / (float)width));
		}
		else
		{
			num2 = maxLength;
			num = (int)Math.Round((float)width * ((float)maxLength / (float)height));
		}
		if (num <= 0)
		{
			num = 1;
		}
		if (num2 <= 0)
		{
			num2 = 1;
		}
		return new SizeInfo
		{
			Width = num,
			Height = num2,
			LongestSide = Math.Max(num, num2),
			ShortestSide = Math.Min(num, num2)
		};
	}

	private void UpdateSliderHint()
	{
		GuiElementDynamicText dynamicText = GuiElementDynamicTextHelper.GetDynamicText(((GuiDialog)this).SingleComposer, "resizeTipText");
		if (selectedSizeOption == null || loadedBitmap == null)
		{
			dynamicText.SetNewText("", false, false, false);
			return;
		}
		int value = (int)Math.Ceiling((double)selectedSizeOption.Width / 16.0);
		int value2 = (int)Math.Ceiling((double)selectedSizeOption.Height / 16.0);
		int num = selectedSizeOption.Width;
		int num2 = selectedSizeOption.Height;
		if (highPixelDensityMode)
		{
			num *= 2;
			num2 *= 2;
		}
		string text = $"{value} Г— {value2} blocks / {selectedSizeOption.Width} Г— {selectedSizeOption.Height} voxels / {num} Г— {num2} pixels";
		Math.Max(loadedBitmap.Width, loadedBitmap.Height);
		dynamicText.SetNewText(text, false, false, false);
	}

	private bool OnClickImport()
	{
		try
		{
			CancelPendingPreviewImageUpdate();
			if (design == null)
			{
				throw new VSException("Missing image file or parameters");
			}
			guiImageTool.SetImageDesign(design.Copy());
			((GuiDialog)guiImageTool).TryOpen();
			((GuiDialog)this).TryClose();
		}
		catch (VSException ex)
		{
			ex.DisplayError(base.capi);
		}
		catch (Exception ex2)
		{
			((ICoreAPI)base.capi).Logger.Error(ex2);
		}
		return true;
	}

	private int RoundUpNext32(int num)
	{
		return (int)Math.Ceiling((double)num / 32.0) * 32;
	}

	private void SetImportButtonEnabled(bool enabled)
	{
		GuiElementIconButton guiElementIconButton = (GuiElementIconButton)(object)((GuiDialog)this).SingleComposer.GetElement("importBtn");
		if (guiElementIconButton != null)
		{
			((GuiElementControl)guiElementIconButton).Enabled = enabled;
		}
	}

	private async void UpdatePreviewImageAsync()
	{
		CancelPendingPreviewImageUpdate();
		if (loadedBitmap == null || selectedSizeOption == null || selectedColourReductionOption == null)
		{
			return;
		}
		CancellationTokenSource cts = new CancellationTokenSource();
		try
		{
			ctsUpdatePreviewImage = cts;
			CancellationToken cancellationToken = cts.Token;
			SetImportButtonEnabled(enabled: false);
			ImageDesign newDesign = await Task.Run(delegate
			{
				ImageDesign imageDesign = imageDesignLoader.CreateDesign(loadedBitmap, selectedSizeOption.Width, selectedSizeOption.Height, selectedColourReductionOption.Enum, selectedColourReductionOption.MasterPalette, highPixelDensityMode);
				imageDesign.ComputePaletteColourMapping(rebuildProgress, cancellationToken);
				imageDesign.RedrawPreviewBitmap();
				return imageDesign;
			}, cancellationToken);
			((IEventAPI)base.capi.Event).EnqueueMainThreadTask((Action)delegate
			{
				design?.Dispose();
				design = newDesign;
				if (design?.PreviewBitmap != null)
				{
					thumbPreviewElement?.SetBitmap(design.PreviewBitmap);
				}
				SetImportButtonEnabled(enabled: true);
				UpdateProgressBar(0.0);
			}, "setcwimageimportpreview");
		}
		catch (OperationCanceledException)
		{
		}
		finally
		{
			cts?.Dispose();
			if (ctsUpdatePreviewImage == cts)
			{
				ctsUpdatePreviewImage = null;
			}
		}
	}

	private void UpdateProgressBar(double val)
	{
		if (((GuiDialog)this).SingleComposer != null)
		{
			GuiElementProgressBar obj = (GuiElementProgressBar)(object)((GuiDialog)this).SingleComposer.GetElement("progressBar");
			obj.Visible = val > 0.0;
			obj.Progress = val;
		}
	}

	private void CancelPendingPreviewImageUpdate()
	{
		UpdateProgressBar(0.0);
		ctsUpdatePreviewImage?.Cancel();
		if (updatePreviewDebounceTimer != -1)
		{
			((IEventAPI)base.capi.Event).UnregisterCallback(updatePreviewDebounceTimer);
			updatePreviewDebounceTimer = -1L;
		}
	}

	private void DebouncedUpdatePreviewImage()
	{
		CancelPendingPreviewImageUpdate();
		updatePreviewDebounceTimer = ((IEventAPI)base.capi.Event).RegisterCallback((Action<float>)delegate
		{
			UpdatePreviewImageAsync();
		}, 100);
	}
}




