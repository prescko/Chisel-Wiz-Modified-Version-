﻿using Vintagestory.API.Common;

namespace ChiselWiz.Gui.Dialogs;

internal class DesignMaterial
{
	public int Index;

	public Block Block;

	public bool IsMissing;

	public ItemStack Stack;
}




