﻿using System;
using ChiselWiz.Systems.Chiselling;
using ChiselWiz.Systems.Images;
using Vintagestory.API.Client;
using Vintagestory.API.Config;

namespace ChiselWiz.Gui.Dialogs;

public class GuiQRCodeToolDialog : GuiImageToolDialogBase
{
	private GuiCreateNewQRCodeDialog qrGui;

	protected override string compName => "chiselwiz:qrtool";

	protected override string titleText => Lang.Get("chiselwiz:QR Code Tool", Array.Empty<object>());

	protected override string generateButtonTextString => Lang.Get("chiselwiz:New QR Code", Array.Empty<object>());

	protected override bool HasPaletteReductionOption => false;

	protected override bool HasChiselModeOption => false;

	protected override bool HasMaterialsList => true;

	protected override double MaterialsListHeight => 80.0;

	public GuiQRCodeToolDialog(ICoreClientAPI capi, ChiselOperator chiseller, ChiselToolModeManager toolModeManager, ImageDesignLoader imageDesignLoader)
		: base(capi, chiseller, toolModeManager, imageDesignLoader)
	{
		qrGui = new GuiCreateNewQRCodeDialog(capi, imageDesignLoader, this);
	}

	protected override bool OnClickGenerate()
	{
		((GuiDialog)qrGui).TryOpen();
		((GuiDialog)this).TryClose();
		return true;
	}

	public override bool TryOpen()
	{
		if (imageDesign == null)
		{
			return ((GuiDialog)qrGui).TryOpen();
		}
		return base.TryOpen();
	}
}




