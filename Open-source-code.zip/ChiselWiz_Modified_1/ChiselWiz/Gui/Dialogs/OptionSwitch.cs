﻿using System;
using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Dialogs;

internal class OptionSwitch
{
	public Func<bool> GetInitialValue;

	public string Label;

	public Action<bool> OnChange;

	public GuiElementSwitch SwitchElement;

	public int Depth;
}




