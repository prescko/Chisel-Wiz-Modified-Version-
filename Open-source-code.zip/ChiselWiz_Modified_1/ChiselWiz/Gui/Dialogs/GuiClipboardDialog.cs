﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Blueprints;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.Client.NoObf;
using Vintagestory.GameContent;

namespace ChiselWiz.Gui.Dialogs;

public class GuiClipboardDialog : GuiDialog
{
	private class MaterialRow : IVirtualListRow<DesignMaterial>
	{
		private ICoreClientAPI capi;

		private GuiElementCWInset inset;

		private GuiElementCWItemStack itemSlotElement;

		private GuiElementDynamicText txtName;

		private GuiElementDynamicText txtCode;

		public int RowHeight => 48;

		public ElementBounds Bounds { get; set; }

		public DesignMaterial Data { get; private set; }

		public void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<DesignMaterial>>> actions)
		{

			capi = composer.Api;
			inset = new GuiElementCWInset(capi, Bounds, delegate
			{
				actions["onClick"](this);
			});
			composer.AddInteractiveElement((GuiElement)(object)inset, (string)null);
			ElementBounds val = ElementBounds.Fixed(0.0, 0.0, Bounds.fixedHeight, Bounds.fixedHeight).WithParent(Bounds);
			itemSlotElement = new GuiElementCWItemStack(capi, val);
			composer.AddInteractiveElement((GuiElement)(object)itemSlotElement, (string)null);
			CairoFont val2 = CairoFont.WhiteSmallishText().WithFontSize(17f);
			CairoFont val3 = CairoFont.WhiteSmallText().WithFontSize(13f).WithColor(ColorUtil.Hex2Doubles("#aaaaaa"));
			ElementBounds val4 = ElementBounds.Fixed(0.0, 7.0, Bounds.fixedWidth - Bounds.fixedHeight, 20.0).FixedRightOf(val, 5.0).WithParent(Bounds);
			txtName = new GuiElementDynamicText(capi, "", val2, val4);
			composer.AddInteractiveElement((GuiElement)(object)txtName, (string)null);
			ElementBounds val5 = val4.BelowCopy(0.0, -2.0, 0.0, -4.0);
			txtCode = new GuiElementDynamicText(capi, "", val3, val5);
			composer.AddInteractiveElement((GuiElement)(object)txtCode, (string)null);
		}

		public void SetData(DesignMaterial data)
		{
			Data = data;
			itemSlotElement.SetSourceItemstack(data.Stack);
			string text = data.Stack.Collectible.GetHeldItemName(data.Stack);
			if (data.IsMissing)
			{
				text = "[Missing Material]";
			}
			txtName.SetNewText(text, false, false, false);
			txtCode.SetNewText(((RegistryObject)data.Block).Code.ToString(), false, false, false);
		}

		public void Dispose()
		{
			GuiElementCWInset guiElementCWInset = inset;
			if (guiElementCWInset != null)
			{
				((GuiElement)guiElementCWInset).Dispose();
			}
			GuiElementCWItemStack guiElementCWItemStack = itemSlotElement;
			if (guiElementCWItemStack != null)
			{
				((GuiElement)guiElementCWItemStack).Dispose();
			}
			GuiElementDynamicText obj = txtName;
			if (obj != null)
			{
				((GuiElement)obj).Dispose();
			}
			GuiElementDynamicText obj2 = txtCode;
			if (obj2 != null)
			{
				((GuiElement)obj2).Dispose();
			}
		}

		public void Hide()
		{
			Bounds.fixedY = -RowHeight;
			Bounds.CalcWorldBounds();
		}

		public void SetSelected(bool selected)
		{
			if (inset != null)
			{
				inset.Selected = selected;
			}
		}
	}

	private BlockBlueprint blueprint;

	private EnumBlockRenderMode previewRenderMode;

	private ItemStack lastChiselBlockForMaterialCycle;

	private int materialCycleIndex;

	private int lastMaterialCycleIdx;

	private List<string> materialCycleCodes;

	private GuiElementCWItemStack blockPreviewElement;

	private EnumDialogType dialogType = (EnumDialogType)1;

	private VirtualListScroller<DesignMaterial, MaterialRow> materialList;

	public override string ToggleKeyCombinationCode => null;

	public override bool PrefersUngrabbedMouse => false;

	public override EnumDialogType DialogType => dialogType;

	public void SetDialogType(EnumDialogType type)
	{

		dialogType = type;
	}

	public void SetBlueprint(BlockBlueprint blueprint, EnumBlockRenderMode previewRenderMode = EnumBlockRenderMode.SpinningCube)
	{
		this.blueprint = blueprint;
		this.previewRenderMode = previewRenderMode;
		Compose();
	}

	public GuiClipboardDialog(ICoreClientAPI capi)
		: base(capi)
	{

		try
		{
			GuiDialog? obj = ((List<GuiDialog>)typeof(ClientMain).GetField("LoadedGuis", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(capi.World)).Find((GuiDialog gui) => gui is GuiDialogInventory);
			obj.OnOpened += delegate
			{

				dialogType = (EnumDialogType)0;
				Compose();
			};
			obj.OnClosed += delegate
			{

				dialogType = (EnumDialogType)1;
				Compose();
			};
			ClientSettings.Inst.AddWatcher<float>("guiScale", delegate
			{
				Compose();
			});
		}
		catch (Exception ex)
		{
			((ICoreAPI)capi).Logger.Error(ex);
		}
	}

	public void Compose()
	{

		try
		{
			if (blueprint != null)
			{
				((GuiDialog)this).ClearComposers();
				if ((int)((GuiDialog)this).DialogType == 1)
				{
					ComposeHUD();
				}
				else
				{
					ComposeDialog();
				}
			}
		}
		catch (Exception ex)
		{
			((ICoreAPI)base.capi).Logger.Error(ex);
		}
	}

	private void ComposeDialog()
	{

		CairoFont font = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2);
		CairoFont val = CairoFont.WhiteSmallishText();
		CairoFont val2 = CairoFont.WhiteSmallText();
		DummyBlockEntityChisel dummyBlockEntityChisel = blueprint.ToDummyBlockEntityChisel(base.capi);
		string name = ((BlockEntityMicroBlock)dummyBlockEntityChisel).GetPlacedBlockName();
		int num = 255;
		ElementBounds val3 = ElementBounds.Fixed((EnumDialogArea)10, 0.0, 0.0, 500.0, GuiStyle.TitleBarHeight + (double)num + 15.0).WithFixedAlignmentOffset(-100.0, 0.0);
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val4 = ElementBounds.Fixed(0.0, GuiStyle.TitleBarHeight, val3.fixedWidth, 35.0).WithParent(val3);
		ElementBounds obj = ElementBounds.Fixed(5.0, 0.0, 190.0, 190.0).WithParent(val3).FixedUnder(val4, 0.0);
		ElementBounds val5 = obj.ForkChild();
		ElementBounds bounds = val5.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight(40.0);
		ElementBounds val6 = obj.RightCopy(10.0, 0.0, 0.0, 0.0).WithFixedSize(val3.fixedWidth - val5.fixedWidth - 20.0, 230.0);
		blockPreviewElement = new GuiElementCWItemStack(base.capi, val5);
		blockPreviewElement.Rotate = true;
		if (blueprint != null)
		{
			blockPreviewElement.SetSourceItemstack(blueprint.ToDummyItemStack(base.capi));
			blockPreviewElement.RenderMode = previewRenderMode;
		}
		GuiComposer composer = Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("chiselwiz:clipboarddialog", val3), fill, true, 5.0, 0.75f), Lang.Get("chiselwiz:Chisel Wiz Clipboard", Array.Empty<object>()), (Action)delegate
		{
			((GuiDialog)this).TryClose();
		}, (CairoFont)null, (ElementBounds)null, (string)null).BeginChildElements();
		GuiElementDynamicText val7 = new GuiElementDynamicText(base.capi, name, val, val4.ForkChildOffseted(6.0, 6.0, -12.0, -12.0));
		composer.AddInteractiveElement((GuiElement)(object)val7, (string)null);
		composer.AddInteractiveElement((GuiElement)(object)blockPreviewElement, (string)null);
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/save.svg"), Lang.Get("chiselwiz:Save Design", Array.Empty<object>()), font, (ActionConsumable)delegate
		{

			TextAreaConfig val8 = new TextAreaConfig
			{
				FontSize = 18f,
				MaxWidth = 500
			};
			((GuiDialog)new GuiDialogTextInput(Lang.Get("chiselwiz:Save design to catalogue", Array.Empty<object>()), name, base.capi, val8)
			{
				OnCloseCancel = delegate
				{
				},
				OnSave = delegate(string text)
				{
					GuiElementIconButton guiElementIconButton2 = (GuiElementIconButton)(object)composer.GetElement("button-savedesign");
					if (guiElementIconButton2 != null)
					{
						((GuiElementControl)guiElementIconButton2).Enabled = false;
					}
					((ICoreAPI)base.capi).ModLoader.GetModSystem<ChiselWizModSystem>(true).PrimaryCatalogue.AddDesign(text, blueprint);
				}
			}).TryOpen();
			return true;
		}, bounds, (EnumButtonStyle)3);
		composer.AddInteractiveElement((GuiElement)(object)guiElementIconButton, "button-savedesign");
		materialList = new VirtualListScroller<DesignMaterial, MaterialRow>(base.capi, composer, val6);
		materialList.AddCallback("onClick", delegate(IVirtualListRow<DesignMaterial> row)
		{
			OnClickMaterial(row as MaterialRow);
		});
		materialList.Compose();
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, Lang.Get("chiselwiz:Drop materials here to replace the materials in the design.", Array.Empty<object>()), val2, 200, val6.CopyOffsetedSibling(0.0, 0.0, -20.0, 0.0), (string)null);
		((GuiDialog)this).SingleComposer = composer.EndChildElements().Compose(false);
		List<DesignMaterial> items = blueprint.MaterialCodes.Select((string code, int idx) => GetMaterial(code, idx)).ToList();
		materialList.SetItems(items);
	}

	private DesignMaterial GetMaterial(string code, int index, DesignMaterial data = null)
	{

		Block block = ((IWorldAccessor)base.capi.World).GetBlock(new AssetLocation(code));
		bool isMissing = false;
		if (block == null)
		{
			block = ((IWorldAccessor)base.capi.World).GetBlock(new AssetLocation("game:air"));
			isMissing = true;
		}
		ItemStack stack = new ItemStack(block, 1);
		if (data == null)
		{
			return new DesignMaterial
			{
				Index = index,
				Block = block,
				IsMissing = isMissing,
				Stack = stack
			};
		}
		data.Block = block;
		data.IsMissing = isMissing;
		data.Stack = stack;
		return data;
	}

	private void OnClickMaterial(MaterialRow row)
	{
		IClientPlayer player = base.capi.World.Player;
		ItemSlot mouseItemSlot = ((IPlayer)player).InventoryManager.MouseItemSlot;
		int index = row.Data.Index;
		if (index < 0)
		{
			return;
		}
		if (mouseItemSlot.Empty)
		{
			lastChiselBlockForMaterialCycle = null;
			return;
		}
		ItemStack itemstack = mouseItemSlot.Itemstack;
		if (((itemstack != null) ? itemstack.Block : null) is BlockChisel)
		{
			BlockBlueprint blockBlueprint = BlockBlueprint.FromItemStack(base.capi, mouseItemSlot.Itemstack);
			if (lastChiselBlockForMaterialCycle == null || !lastChiselBlockForMaterialCycle.Equals((IWorldAccessor)(object)base.capi.World, mouseItemSlot.Itemstack, GlobalConstants.IgnoredStackAttributes))
			{
				lastChiselBlockForMaterialCycle = mouseItemSlot.Itemstack.Clone();
				materialCycleIndex = 0;
				Dictionary<byte, int> dictionary = new Dictionary<byte, int>();
				for (int i = 0; i < 16; i++)
				{
					for (int j = 0; j < 16; j++)
					{
						for (int k = 0; k < 16; k++)
						{
							if (blockBlueprint.Voxels[i, j, k])
							{
								byte key = blockBlueprint.Materials[i, j, k];
								dictionary.TryGetValue(key, out var value);
								dictionary[key] = value + 1;
							}
						}
					}
				}
				List<byte> first = (from kvp in dictionary
					orderby kvp.Value descending
					select kvp.Key).ToList();
				List<byte> second = (from num in Enumerable.Range(0, blockBlueprint.MaterialCodes.Count)
					select (byte)num).ToList();
				List<byte> list = first.Union(second).ToList();
				HashSet<string> hashSet = new HashSet<string>();
				materialCycleCodes = new List<string>();
				foreach (byte item2 in list)
				{
					if (item2 < blockBlueprint.MaterialCodes.Count)
					{
						string item = blockBlueprint.MaterialCodes[item2];
						if (hashSet.Add(item))
						{
							materialCycleCodes.Add(item);
						}
					}
				}
			}
			if (materialCycleCodes != null && materialCycleCodes.Count > 0)
			{
				if (row.Data.Index != lastMaterialCycleIdx)
				{
					lastMaterialCycleIdx = row.Data.Index;
					materialCycleIndex = 0;
				}
				string text = materialCycleCodes[materialCycleIndex];
				if (text == ((RegistryObject)row.Data.Block).Code.ToString())
				{
					materialCycleIndex = (materialCycleIndex + 1) % materialCycleCodes.Count;
					text = materialCycleCodes[materialCycleIndex];
				}
				blueprint.MaterialCodes[index] = text;
				materialCycleIndex = (materialCycleIndex + 1) % materialCycleCodes.Count;
				GetMaterial(text, row.Data.Index, row.Data);
				row.SetData(row.Data);
				blockPreviewElement.SetSourceItemstack(blueprint.ToDummyItemStack(base.capi));
			}
			return;
		}
		ItemStack itemstack2 = mouseItemSlot.Itemstack;
		if (((itemstack2 != null) ? itemstack2.Block : null) != null)
		{
			if (ItemChisel.IsValidChiselingMaterial((ICoreAPI)(object)base.capi, (BlockPos)null, mouseItemSlot.Itemstack.Block, (IPlayer)(object)player))
			{
				Block block = mouseItemSlot.Itemstack.Block;
				blueprint.MaterialCodes[index] = ((RegistryObject)block).Code.ToString();
				lastChiselBlockForMaterialCycle = null;
				GetMaterial(((RegistryObject)block).Code.ToString(), row.Data.Index, row.Data);
				row.SetData(row.Data);
				blockPreviewElement.SetSourceItemstack(blueprint.ToDummyItemStack(base.capi));
			}
			else
			{
				base.capi.TriggerIngameError((object)this, "badmaterial", Lang.Get("chiselwiz:Can't use this material for chiselling", Array.Empty<object>()));
			}
		}
	}

	private void ComposeHUD()
	{
		ElementBounds val = ElementBounds.Fixed((EnumDialogArea)10, 0.0, 0.0, 150.0, 150.0 + GuiStyle.TitleBarHeight).WithFixedAlignmentOffset(-100.0, 0.0);
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val2 = ElementBounds.Fixed(0.0, GuiStyle.TitleBarHeight, 150.0, 150.0).WithParent(val);
		ElementBounds bounds = val2.ForkChild();
		blockPreviewElement = new GuiElementCWItemStack(base.capi, bounds);
		blockPreviewElement.Rotate = true;
		if (blueprint != null)
		{
			blockPreviewElement.SetSourceItemstack(blueprint.ToDummyItemStack(base.capi));
			blockPreviewElement.RenderMode = previewRenderMode;
		}
		GuiComposer val3 = GuiElementInsetHelper.AddInset(Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("chiselwiz:clipboarddialog", val), fill, true, 5.0, 0.75f), Lang.Get("chiselwiz:Clipboard", Array.Empty<object>()), (Action)delegate
		{
			((GuiDialog)this).TryClose();
		}, (CairoFont)null, (ElementBounds)null, (string)null).BeginChildElements(), val2.FlatCopy(), 4, 0.85f).AddInteractiveElement((GuiElement)(object)blockPreviewElement, (string)null).EndChildElements();
		((GuiDialog)this).SingleComposer = val3.Compose(false);
	}
}




