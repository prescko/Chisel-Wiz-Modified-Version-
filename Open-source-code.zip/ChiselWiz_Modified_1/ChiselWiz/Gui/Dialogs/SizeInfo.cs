﻿namespace ChiselWiz.Gui.Dialogs;

internal class SizeInfo
{
	public int Width;

	public int Height;

	public int LongestSide;

	public int ShortestSide;
}




