﻿using System;
using ChiselWiz.Systems.Chiselling;
using ChiselWiz.Systems.Images;
using Vintagestory.API.Client;
using Vintagestory.API.Config;

namespace ChiselWiz.Gui.Dialogs;

public class GuiImageToolDialog : GuiImageToolDialogBase
{
	private GuiImportImageDialog importGui;

	protected override string compName => "chiselwiz:imagedesigntool";

	protected override string titleText => Lang.Get("chiselwiz:Image Design Tool", Array.Empty<object>());

	protected override string generateButtonTextString => Lang.Get("chiselwiz:New Image Design", Array.Empty<object>());

	protected override bool HasPaletteReductionOption => true;

	public GuiImageToolDialog(ICoreClientAPI capi, ChiselOperator chiseller, ChiselToolModeManager toolModeManager, ImageDesignLoader imageDesignLoader)
		: base(capi, chiseller, toolModeManager, imageDesignLoader)
	{
		importGui = new GuiImportImageDialog(capi, imageDesignLoader, this);
	}

	protected override bool OnClickGenerate()
	{
		((GuiDialog)importGui).TryOpen();
		((GuiDialog)this).TryClose();
		return true;
	}

	public override bool TryOpen()
	{
		if (imageDesign == null)
		{
			return ((GuiDialog)importGui).TryOpen();
		}
		return base.TryOpen();
	}
}




