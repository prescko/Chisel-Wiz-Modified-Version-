﻿using System;
using System.Collections.Generic;
using System.Globalization;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems.Catalogues;
using Vintagestory.API.Client;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Dialogs;

internal class CatalogueRow : IVirtualListRow<CatalogueDesign>
{
	private ICoreClientAPI capi;

	public GuiElementCWInset InsetElement;

	public GuiElementCWItemStack BlockIconElement;

	public GuiElementDynamicText TextNameElement;

	public GuiElementDynamicText TextDateAddedElement;

	public GuiElementDynamicText TextDateAgoElement;

	public int RowHeight => 50;

	public CatalogueDesign Data { get; private set; }

	public ElementBounds Bounds { get; set; }

	public void Hide()
	{
		InsetElement.Unhighlight();
		InsetElement.Selected = false;
		Bounds.fixedY = -RowHeight;
		Bounds.CalcWorldBounds();
	}

	public void SetData(CatalogueDesign data)
	{
		Data = data;
		string text = data.DateAdded.ToString("g", CultureInfo.CurrentCulture);
		string relativeTime = GetRelativeTime(data.DateAdded);
		TextNameElement.SetNewText(data.Name, false, false, false);
		TextDateAddedElement.SetNewTextAsync(text, false, false);
		TextDateAgoElement.SetNewTextAsync(relativeTime, false, false);
		BlockIconElement.SetSourceItemstack(data.Blueprint.ToDummyItemStack(capi));
	}

	public void Dispose()
	{
		GuiElementCWInset insetElement = InsetElement;
		if (insetElement != null)
		{
			((GuiElement)insetElement).Dispose();
		}
		GuiElementCWItemStack blockIconElement = BlockIconElement;
		if (blockIconElement != null)
		{
			((GuiElement)blockIconElement).Dispose();
		}
		GuiElementDynamicText textNameElement = TextNameElement;
		if (textNameElement != null)
		{
			((GuiElement)textNameElement).Dispose();
		}
		GuiElementDynamicText textDateAddedElement = TextDateAddedElement;
		if (textDateAddedElement != null)
		{
			((GuiElement)textDateAddedElement).Dispose();
		}
		GuiElementDynamicText textDateAgoElement = TextDateAgoElement;
		if (textDateAgoElement != null)
		{
			((GuiElement)textDateAgoElement).Dispose();
		}
	}

	public void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<CatalogueDesign>>> actions)
	{

		capi = composer.Api;
		ElementBounds val = Bounds.ForkChild();
		CatalogueColumn[] columns = GuiDesignCatalogue.columns;
		CairoFont val2 = CairoFont.WhiteSmallishText().WithFontSize(18f);
		CairoFont val3 = CairoFont.WhiteSmallishText().WithFontSize(16f).WithColor(ColorUtil.Hex2Doubles("#aaaaaa"));
		InsetElement = new GuiElementCWInset(capi, Bounds, delegate
		{
			actions["onClick"](this);
		}, delegate
		{
			actions.TryGetValue("onMouseMove", out var value);
			value?.Invoke(this);
		}, delegate
		{
			actions.TryGetValue("onMouseOut", out var value);
			value?.Invoke(this);
		});
		int num = 0;
		CatalogueColumn catalogueColumn = columns[num++];
		ElementBounds val4 = ElementBounds.FixedSize((double)catalogueColumn.Width, (double)RowHeight).WithParent(val);
		BlockIconElement = new GuiElementCWItemStack(capi, val4);
		catalogueColumn = columns[num++];
		val4 = val4.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth((double)catalogueColumn.Width);
		ElementBounds val5 = val4.FlatCopy().WithFixedHeight(40.0).WithFixedOffset(5.0, 5.0);
		val5.fixedWidth -= 10.0;
		TextNameElement = new GuiElementDynamicText(capi, "", val2, val5.ForkChild());
		catalogueColumn = columns[num++];
		val4 = val4.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth((double)catalogueColumn.Width);
		ElementBounds val6 = val4.FlatCopy().WithFixedHeight(20.0).WithFixedOffset(5.0, 5.0);
		val6.fixedWidth -= 10.0;
		ElementBounds val7 = val6.BelowCopy(0.0, 0.0, 0.0, 0.0);
		TextDateAddedElement = new GuiElementDynamicText(capi, "", val3, val6.ForkChild());
		TextDateAgoElement = new GuiElementDynamicText(capi, "", val2, val7.ForkChild());
		composer.AddInteractiveElement((GuiElement)(object)InsetElement, (string)null).AddInteractiveElement((GuiElement)(object)BlockIconElement, (string)null).AddInteractiveElement((GuiElement)(object)TextNameElement, (string)null)
			.AddInteractiveElement((GuiElement)(object)TextDateAddedElement, (string)null)
			.AddInteractiveElement((GuiElement)(object)TextDateAgoElement, (string)null);
	}

	public void SetSelected(bool selected)
	{
		if (InsetElement != null)
		{
			InsetElement.Selected = selected;
		}
	}

	private static string GetRelativeTime(DateTime past)
	{
		TimeSpan timeSpan = DateTime.Now - past;
		if (timeSpan.TotalSeconds < 60.0)
		{
			return Lang.Get("chiselwiz:time-justnow", Array.Empty<object>());
		}
		if (timeSpan.TotalMinutes < 60.0)
		{
			int num = (int)timeSpan.TotalMinutes;
			if (num != 1)
			{
				return Lang.Get("chiselwiz:time-minutesago", new object[1] { num });
			}
			return Lang.Get("chiselwiz:time-1minuteago", Array.Empty<object>());
		}
		if (timeSpan.TotalHours < 24.0)
		{
			int num2 = (int)timeSpan.TotalHours;
			if (num2 != 1)
			{
				return Lang.Get("chiselwiz:time-hoursago", new object[1] { num2 });
			}
			return Lang.Get("chiselwiz:time-1hourago", Array.Empty<object>());
		}
		int num3 = (int)timeSpan.TotalDays;
		if (num3 != 1)
		{
			return Lang.Get("chiselwiz:time-daysago", new object[1] { num3 });
		}
		return Lang.Get("chiselwiz:time-1dayago", Array.Empty<object>());
	}
}




