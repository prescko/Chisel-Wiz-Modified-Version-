﻿namespace ChiselWiz.Gui.Dialogs;

public enum ColumnSortDir
{
	None,
	Up,
	Down
}




