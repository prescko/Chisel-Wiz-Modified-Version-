﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using ChiselWiz.ChiselToolModes;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace ChiselWiz.Gui.Dialogs;

internal class GuiCWToolMode : GuiDialog
{
	private ItemChisel itemChisel;

	private ItemSlot itemChiselSlot;

	private BlockEntityChisel beChisel;

	private BlockSelection blockSele;

	private ChiselOperator chiseller;

	private ChiselWizModSystem modSystem;

	private ChiselToolModeManager toolModeManager;

	private List<SkillItem> skillItems;

	private SkillItem addMaterialSkillItem;

	private SkillItem[] CWToolModes;

	private Dictionary<string, OptionSwitch> options;

	private int hoverModeIdx;

	private int hoverMaterialIdx;

	public override string ToggleKeyCombinationCode => null;

	public GuiCWToolMode(ICoreClientAPI capi, ChiselOperator chiseller, ChiselToolModeManager toolModeManager)
		: base(capi)
	{

		this.chiseller = chiseller;
		modSystem = ((ICoreAPI)capi).ModLoader.GetModSystem<ChiselWizModSystem>(true);
		this.toolModeManager = toolModeManager;
		int cwColour = ColorUtil.ToRgba(255, 117, 184, 248);
		options = new Dictionary<string, OptionSwitch>
		{
			{
				"requireMats",
				new OptionSwitch
				{
					OnChange = SetOptionRequireMats,
					Label = Lang.Get("chiselwiz:Require matching materials before chiselling", Array.Empty<object>()),
					GetInitialValue = () => chiseller.OptionRequireMatchingMaterials
				}
			},
			{
				"autoAddMats",
				new OptionSwitch
				{
					OnChange = SetOptionAutoAddMats,
					Label = Lang.Get("chiselwiz:Auto-add missing materials from inventory", Array.Empty<object>()),
					GetInitialValue = () => chiseller.OptionAutoAddMissingMaterials,
					Depth = 1
				}
			},
			{
				"matchOrientation",
				new OptionSwitch
				{
					OnChange = SetOptionMatchOrientation,
					Label = Lang.Get("chiselwiz:Materials must match exact orientation", Array.Empty<object>()),
					GetInitialValue = () => chiseller.OptionMaterialsMustMatchExactOrientation,
					Depth = 1
				}
			}
		};
		CWToolModes = ObjectCacheUtil.GetOrCreate<SkillItem[]>((ICoreAPI)(object)capi, "chiselwiz:chiselToolModes", (CreateCachableObjectDelegate<SkillItem[]>)(() => new List<SkillItem>
		{
			new SkillItem
			{
				Code = new AssetLocation("vflip"),
				Name = Lang.Get("chiselwiz:verticalflip", Array.Empty<object>()),
				Data = new VFlipMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/vflip.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("vrot"),
				Name = Lang.Get("chiselwiz:verticalrotate", Array.Empty<object>()),
				Data = new VRotMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/vrot.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("invert"),
				Name = Lang.Get("chiselwiz:invert", Array.Empty<object>()),
				Data = new InvertMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/invert.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("mirror-h"),
				Name = Lang.Get("chiselwiz:mirror-h", Array.Empty<object>()),
				Data = new MirrorHMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/mirror-h.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("mirror-v"),
				Name = Lang.Get("chiselwiz:mirror-v", Array.Empty<object>()),
				Data = new MirrorVMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/mirror-v.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("pushpull"),
				Name = Lang.Get("chiselwiz:pushpull", Array.Empty<object>()),
				Data = new PushPullMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/pushpull.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("pushpullwrap"),
				Name = Lang.Get("chiselwiz:pushpullwrap", Array.Empty<object>()),
				Data = new PushPullWrapMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/pushpullwrap.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("shave"),
				Name = Lang.Get("chiselwiz:shave", Array.Empty<object>()),
				Data = new ShaveMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/shave.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("merge"),
				Name = Lang.Get("chiselwiz:merge", Array.Empty<object>()),
				Data = new MergeMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/merge.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("mergereplace"),
				Name = Lang.Get("chiselwiz:mergereplace", Array.Empty<object>()),
				Data = new MergeReplaceMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/mergereplace.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("addshape"),
				Name = Lang.Get("chiselwiz:addshape", Array.Empty<object>()),
				Data = new AddShapeMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/addshape.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("subtractshape"),
				Name = Lang.Get("chiselwiz:subtractshape", Array.Empty<object>()),
				Data = new SubtractShapeMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/subtractshape.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("reset"),
				Name = Lang.Get("chiselwiz:reset", Array.Empty<object>()),
				Data = new ResetMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/reset.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("paint-contiguous"),
				Name = Lang.Get("chiselwiz:paintcontiguous", Array.Empty<object>()),
				Data = new PaintContiguousMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/paint-contiguous.svg"), 50, 50, 10, (int?)cwColour)
			},
			new SkillItem
			{
				Code = new AssetLocation("paint"),
				Name = Lang.Get("chiselwiz:paint", Array.Empty<object>()),
				Data = new PaintMode(chiseller),
				Texture = capi.Gui.LoadSvgWithPadding(new AssetLocation("chiselwiz", "textures/icons/paint.svg"), 50, 50, 10, (int?)cwColour)
			}
		}.ToArray()));
		addMaterialSkillItem = new SkillItem
		{
			Name = Lang.Get("chiselwiz:addmaterial", Array.Empty<object>()),
			Code = new AssetLocation("addmat")
		};
		addMaterialSkillItem.WithIcon(capi, "plus");
	}

	private int GetItemChiselCurrentMaterialId()
	{
		return itemChiselSlot.Itemstack.Attributes.GetInt("materialId", 0);
	}

	private byte GetCurrentMaterialIdx()
	{
		if (beChisel == null)
		{
			return 0;
		}
		return (byte)typeof(BlockEntityChisel).GetField("nowmaterialIndex", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(beChisel);
	}

	private bool TrySetActiveMaterialIdx(int idx)
	{
		try
		{
			if (idx >= ((BlockEntityMicroBlock)beChisel).BlockIds.Length)
			{
				return false;
			}
			int num = ((BlockEntityMicroBlock)beChisel).BlockIds[idx];
			beChisel.SetNowMaterialId(num);
			itemChiselSlot.Itemstack.Attributes.SetInt("materialId", num);
			chiseller.SetChiselMaterialIdx(beChisel, idx);
			return true;
		}
		catch (VSException ex)
		{
			ex.DisplayError(base.capi);
		}
		catch (Exception ex2)
		{
			((ICoreAPI)base.capi).Logger.Error(ex2);
		}
		return false;
	}

	private bool TrySetActiveMaterial(Block material)
	{
		int num = Array.IndexOf(((BlockEntityMicroBlock)beChisel).BlockIds, material.BlockId);
		if (num == -1)
		{
			return false;
		}
		return TrySetActiveMaterialIdx(num);
	}

	public void SetFocus(ItemChisel itemChisel, BlockEntityChisel beChisel, BlockSelection blockSele, ItemSlot itemChiselSlot)
	{
		this.itemChisel = itemChisel;
		this.itemChiselSlot = itemChiselSlot;
		this.beChisel = beChisel;
		this.blockSele = blockSele;
		skillItems = new List<SkillItem>();
		skillItems.AddRange(itemChisel.ToolModes);
		skillItems.AddRange(CWToolModes);
		ComposeDialog();
	}

	public override void OnGuiOpened()
	{
		try
		{
			ComposeDialog();
		}
		catch (Exception ex)
		{
			((ICoreAPI)base.capi).Logger.Error(ex);
		}
	}

	private ElementBounds ComposeToolModeSection(GuiComposer composer, ElementBounds sectionStartBounds, CairoFont font, CairoFont fontSmall)
	{
		int num = (int)sectionStartBounds.fixedWidth;
		int num2 = 50;
		int num3 = num / num2;
		int num4 = (skillItems.Count + num3 - 1) / num3;
		int num5 = num2 * num4;
		ElementBounds val = sectionStartBounds.FlatCopy().WithFixedHeight(30.0);
		ElementBounds val2 = val.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight((double)num5);
		ElementBounds val3 = sectionStartBounds.FlatCopy().WithFixedHeight(10.0);
		val3.fixedHeight += val2.fixedHeight + val.fixedHeight;
		ElementBounds val4 = val2.FlatCopy();
		GuiElementInsetHelper.AddInset(GuiElementDynamicTextHelper.AddDynamicText(composer, Lang.Get("chiselwiz:Select Chisel Mode", Array.Empty<object>()), font, val, (string)null), val2, 4, 0.85f).BeginChildElements();
		for (int i = 0; i < skillItems.Count; i++)
		{
			int toolModeIdx = i;
			int num6 = i % num3;
			int num7 = i / num3;
			ElementBounds bounds = ElementBounds.Fixed((double)(num6 * num2), (double)(num7 * num2), (double)num2, (double)num2);
			SkillItem skillItem = skillItems[i];
			GuiElementCWSkillItemGrid skillItemGrid = new GuiElementCWSkillItemGrid(base.capi, skillItem, bounds);
			((GuiElementSkillItemGrid)skillItemGrid).OnSlotClick = delegate
			{
				if (skillItem.Data is CWChiselMode cWChiselMode2)
				{
					cWChiselMode2.CurrentStrength = skillItemGrid.CurrentNum;
					toolModeManager.SetCWToolMode(toolModeIdx, skillItem);
				}
				else
				{
					toolModeManager.TrySetToolMode(toolModeIdx, skillItem, beChisel);
				}
				((GuiDialog)this).TryClose();
			};
			skillItemGrid.Highlighted = (toolModeManager.IsCWSkillModeActive ? (toolModeManager.ActiveCWSkillMode == skillItem.Data) : (toolModeManager.ActiveSkillMode == skillItem.Data));
			if (skillItem.Data is CWChiselMode cWChiselMode)
			{
				skillItemGrid.MaxNum = cWChiselMode.MaxStrength;
				skillItemGrid.CurrentNum = cWChiselMode.CurrentStrength;
			}
			((GuiElementSkillItemGrid)skillItemGrid).OnSlotOver = delegate
			{
				if (hoverModeIdx != toolModeIdx)
				{
					hoverModeIdx = toolModeIdx;
					Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(((GuiDialog)this).SingleComposer, "hoverToolText").SetNewText(skillItem.Name);
				}
			};
			skillItemGrid.OnNumChange = delegate(int newNum)
			{
				if (skillItem.Data is CWChiselMode cWChiselMode2)
				{
					cWChiselMode2.CurrentStrength = newNum;
				}
			};
			composer.AddInteractiveElement((GuiElement)(object)skillItemGrid, (string)null);
		}
		val2.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedHeight(30.0);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, "", fontSmall, 500, val4, "hoverToolText");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(composer, "hoverToolText").SetAutoWidth(true);
		composer.EndChildElements();
		return val3;
	}

	private ElementBounds ComposeOptionsSection(GuiComposer composer, ElementBounds sectionStartBounds, CairoFont font, CairoFont fontSmall)
	{

		_ = sectionStartBounds.fixedWidth;
		ElementBounds val = sectionStartBounds.FlatCopy().WithFixedHeight(30.0);
		ElementBounds val2 = val.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight((double)(options.Values.Count * 35 + 5));
		ElementBounds val3 = sectionStartBounds.FlatCopy().WithFixedHeight(10.0);
		val3.fixedHeight += val2.fixedHeight + val.fixedHeight;
		GuiElementInsetHelper.AddInset(GuiElementDynamicTextHelper.AddDynamicText(composer, Lang.Get("chiselwiz:Paste/Merge Material Handling Options", Array.Empty<object>()), font, val, (string)null), val2, 1, 1f);
		ElementBounds val4 = ElementBounds.Fixed(0.0, 0.0, 30.0, 30.0).WithParent(val2).WithFixedOffset(5.0, 5.0);
		double num = val2.fixedWidth - val4.fixedWidth - 15.0;
		foreach (KeyValuePair<string, OptionSwitch> option in options)
		{
			option.Deconstruct(out var _, out var value);
			OptionSwitch optionSwitch = value;
			ElementBounds val5 = val4.FlatCopy().WithFixedOffset((double)(optionSwitch.Depth * 20), 0.0);
			GuiElementDynamicTextHelper.AddDynamicText(composer, optionSwitch.Label, fontSmall, val5.RightCopy(5.0, 5.0, 0.0, -10.0).WithFixedWidth(num), (string)null);
			optionSwitch.SwitchElement = new GuiElementSwitch(base.capi, optionSwitch.OnChange, val5.FlatCopy(), val5.fixedHeight, 4.0);
			composer.AddInteractiveElement((GuiElement)(object)optionSwitch.SwitchElement, (string)null);
			optionSwitch.SwitchElement.SetValue(optionSwitch.GetInitialValue());
			val4 = val4.BelowCopy(0.0, 5.0, 0.0, 0.0);
		}
		return val3;
	}

	private void SetOptionRequireMats(bool val)
	{
		chiseller.OptionRequireMatchingMaterials = val;
		options["requireMats"].SwitchElement.SetValue(val);
		if (!val)
		{
			SetOptionAutoAddMats(val: false);
			SetOptionMatchOrientation(val: false);
		}
	}

	private void SetOptionAutoAddMats(bool val)
	{
		chiseller.OptionAutoAddMissingMaterials = val;
		options["autoAddMats"].SwitchElement.SetValue(val);
		if (val)
		{
			SetOptionRequireMats(val: true);
		}
	}

	private void SetOptionMatchOrientation(bool val)
	{
		chiseller.OptionMaterialsMustMatchExactOrientation = val;
		options["matchOrientation"].SwitchElement.SetValue(val);
		if (val)
		{
			SetOptionRequireMats(val: true);
		}
	}

	private ElementBounds ComposeMaterialsSection(GuiComposer composer, ElementBounds sectionStartBounds, CairoFont font, CairoFont fontSmall)
	{

		int num = (int)sectionStartBounds.fixedWidth;
		List<Block> list = ((BlockEntityMicroBlock)beChisel).BlockIds.Select((int blockId) => ((IWorldAccessor)base.capi.World).Blocks[blockId]).ToList();
		int num2 = 50;
		int num3 = list.Count + 1;
		int num4 = num / num2;
		int num5 = (num3 + num4 - 1) / num4;
		int num6 = num2 * num5;
		ElementBounds val = sectionStartBounds.FlatCopy().WithFixedHeight(30.0);
		ElementBounds val2 = val.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight((double)num6);
		ElementBounds val3 = val2.FlatCopy();
		ElementBounds val4 = sectionStartBounds.FlatCopy().WithFixedHeight(10.0);
		val4.fixedHeight += val2.fixedHeight + val.fixedHeight;
		GuiElementInsetHelper.AddInset(GuiElementDynamicTextHelper.AddDynamicText(composer, Lang.Get("chiselwiz:Material Selection", Array.Empty<object>()), font, val, (string)null), val2, 4, 0.85f).BeginChildElements();
		for (int num7 = 0; num7 < list.Count; num7++)
		{
			Block val5 = list[num7];
			int materialIdx = num7;
			int num8 = num7 % num4;
			int num9 = num7 / num4;
			DummySlot dummySlot = new DummySlot();
			ItemStack val6 = new ItemStack(val5, 1);
			((ItemSlot)dummySlot).Itemstack = val6;
			ElementBounds skillItemBounds = ElementBounds.Fixed((double)(num8 * num2), (double)(num9 * num2), (double)num2, (double)num2);
			SkillItem skillItem = new SkillItem
			{
				Code = ((RegistryObject)val5).Code,
				Name = ((CollectibleObject)val5).GetHeldItemName(val6),
				RenderHandler = (RenderSkillItemDelegate)delegate
				{
					int num12 = 24;
					base.capi.Render.PushScissor(skillItemBounds, true);
					base.capi.Render.RenderItemstackToGui((ItemSlot)(object)dummySlot, skillItemBounds.renderX + GuiElement.scaled((double)num12), skillItemBounds.renderY + GuiElement.scaled((double)num12), 75.0, (float)GuiElement.scaled(30.0), -1, true, false, false);
					base.capi.Render.PopScissor();
				}
			};
			GuiElementCWSkillItemGrid guiElementCWSkillItemGrid = new GuiElementCWSkillItemGrid(base.capi, skillItem, skillItemBounds);
			((GuiElementSkillItemGrid)guiElementCWSkillItemGrid).OnSlotClick = delegate
			{
				ItemSlot mouseItemSlot = ((IPlayer)base.capi.World.Player).InventoryManager.MouseItemSlot;
				if (mouseItemSlot.Empty)
				{
					TrySetActiveMaterialIdx(materialIdx);
					((GuiDialog)this).TryClose();
				}
				else if (mouseItemSlot.Itemstack.Block != null)
				{
					chiseller.SetChiselToolMode(beChisel, -1, forceSet: true);
					ComposeDialog();
				}
			};
			((GuiElementSkillItemGrid)guiElementCWSkillItemGrid).OnSlotOver = delegate
			{
				if (hoverMaterialIdx != materialIdx)
				{
					hoverMaterialIdx = materialIdx;
					Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(((GuiDialog)this).SingleComposer, "hoverMaterialText").SetNewText($"{skillItem.Name}\n<font color=\"#999999\">{skillItem.Code}</font>");
				}
			};
			guiElementCWSkillItemGrid.Highlighted = GetItemChiselCurrentMaterialId() == val5.BlockId;
			composer.AddInteractiveElement((GuiElement)(object)guiElementCWSkillItemGrid, (string)null);
		}
		int lastMaterialIdx = num3 - 1;
		int num10 = lastMaterialIdx % num4;
		int num11 = lastMaterialIdx / num4;
		ElementBounds bounds = ElementBounds.Fixed((double)(num10 * num2), (double)(num11 * num2), (double)num2, (double)num2);
		GuiElementCWSkillItemGrid guiElementCWSkillItemGrid2 = new GuiElementCWSkillItemGrid(base.capi, addMaterialSkillItem, bounds);
		((GuiElementSkillItemGrid)guiElementCWSkillItemGrid2).OnSlotClick = delegate
		{
			try
			{
				ItemSlot mouseItemSlot = ((IPlayer)base.capi.World.Player).InventoryManager.MouseItemSlot;
				if (mouseItemSlot.Empty)
				{
					base.capi.TriggerIngameError((object)this, "nomaterialinmouse", Lang.Get("chiselwiz:To add materials, you must pick up a block and drop it here", Array.Empty<object>()));
				}
				else if (mouseItemSlot.Itemstack.Block != null)
				{
					chiseller.SetChiselToolMode(beChisel, -1, forceSet: true);
					ComposeDialog();
				}
			}
			catch (VSException ex)
			{
				ex.DisplayError(base.capi);
			}
			catch (Exception ex2)
			{
				((ICoreAPI)base.capi).Logger.Error(ex2);
			}
		};
		((GuiElementSkillItemGrid)guiElementCWSkillItemGrid2).OnSlotOver = delegate
		{
			if (hoverMaterialIdx != lastMaterialIdx)
			{
				hoverMaterialIdx = lastMaterialIdx;
				Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(((GuiDialog)this).SingleComposer, "hoverMaterialText").SetNewText(addMaterialSkillItem.Name);
			}
		};
		composer.AddInteractiveElement((GuiElement)(object)guiElementCWSkillItemGrid2, (string)null);
		val2.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedHeight(30.0);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, "", fontSmall, 500, val3, "hoverMaterialText");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(composer, "hoverMaterialText").SetAutoWidth(true);
		composer.EndChildElements();
		return val4;
	}

	private void ComposeDialog()
	{

		((GuiDialog)this).ClearComposers();
		hoverMaterialIdx = -1;
		hoverModeIdx = -1;
		int num = 500;
		ElementBounds val = ElementBounds.Fixed((EnumDialogArea)6, 0.0, 0.0, (double)(num + 20), 0.0).WithFixedAlignmentOffset(0.0, 0.0);
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds sectionStartBounds = val.ForkContainingChild(10.0, 10.0, 10.0, 10.0).WithAlignment((EnumDialogArea)1);
		CairoFont val2 = CairoFont.WhiteSmallishText();
		CairoFont val3 = val2.Clone().WithFontSize(16f);
		GuiComposer val4 = Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("cwtoolmode", val), fill, false, 5.0, 0.75f).BeginChildElements();
		ElementBounds val5 = val.RightCopy(10.0, 0.0, 0.0, 0.0).WithParent(val).ForkChild()
			.WithFixedSize(43.0, 43.0)
			.WithFixedPadding(5.0)
			.WithFixedMargin(0.0);
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/catalogue.svg"), null, null, (ActionConsumable)delegate
		{
			modSystem.ToggleCatalogueGui();
			((GuiDialog)this).TryClose();
			return true;
		}, val5, (EnumButtonStyle)2);
		val4.AddInteractiveElement((GuiElement)(object)guiElementIconButton, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val4, Lang.Get("chiselwiz:Open Design Catalogue", Array.Empty<object>()), val3, 500, val5, "catalogueButtonHoverText");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(val4, "catalogueButtonHoverText").SetAutoWidth(true);
		val5 = val5.BelowCopy(0.0, 10.0, 0.0, 0.0);
		GuiElementIconButton guiElementIconButton2 = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/imagedesigner.svg"), null, null, (ActionConsumable)delegate
		{
			modSystem.ToggleImageToolGui();
			((GuiDialog)this).TryClose();
			return true;
		}, val5, (EnumButtonStyle)2);
		val4.AddInteractiveElement((GuiElement)(object)guiElementIconButton2, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val4, Lang.Get("chiselwiz:Image Design Tool", Array.Empty<object>()), val3, 500, val5, "imageDesignButtonHoverText");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(val4, "imageDesignButtonHoverText").SetAutoWidth(true);
		val5 = val5.BelowCopy(0.0, 10.0, 0.0, 0.0);
		GuiElementIconButton guiElementIconButton3 = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/qr.svg"), null, null, (ActionConsumable)delegate
		{
			modSystem.ToggleQRToolGui();
			((GuiDialog)this).TryClose();
			return true;
		}, val5, (EnumButtonStyle)2);
		val4.AddInteractiveElement((GuiElement)(object)guiElementIconButton3, (string)null);
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val4, Lang.Get("chiselwiz:QR Code Tool", Array.Empty<object>()), val3, 500, val5, "qrToolButtonHoverText");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(val4, "qrToolButtonHoverText").SetAutoWidth(true);
		val5 = val5.BelowCopy(0.0, 10.0, 0.0, 0.0);
		ElementBounds val6 = ComposeToolModeSection(val4, sectionStartBounds, val2, val3);
		val.fixedHeight += val6.fixedHeight;
		sectionStartBounds = val6.BelowCopy(0.0, 0.0, 0.0, 0.0);
		if (beChisel != null)
		{
			ElementBounds val7 = ComposeMaterialsSection(val4, sectionStartBounds, val2, val3);
			val.fixedHeight += val7.fixedHeight;
			sectionStartBounds = val7.BelowCopy(0.0, 0.0, 0.0, 0.0);
		}
		ElementBounds val8 = ComposeOptionsSection(val4, sectionStartBounds, val2, val3);
		val.fixedHeight += val8.fixedHeight;
		sectionStartBounds = val8.BelowCopy(0.0, 0.0, 0.0, 0.0);
		ElementBounds val9 = ComposeSpeedSection(val4, sectionStartBounds, val2, val3);
		val.fixedHeight += val9.fixedHeight;
		sectionStartBounds = val9.BelowCopy(0.0, 0.0, 0.0, 0.0);
		val.fixedHeight += 10.0;
		((GuiDialog)this).SingleComposer = val4.EndChildElements().Compose(true);
	}

	private ElementBounds ComposeSpeedSection(GuiComposer composer, ElementBounds sectionStartBounds, CairoFont font, CairoFont fontSmall)
	{
		double sectionWidth = sectionStartBounds.fixedWidth;
		ElementBounds titleBounds = sectionStartBounds.FlatCopy().WithFixedHeight(30.0);
		ElementBounds contentBounds = titleBounds.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight(50.0);
		ElementBounds sectionBounds = sectionStartBounds.FlatCopy().WithFixedHeight(10.0);
		sectionBounds.fixedHeight += contentBounds.fixedHeight + titleBounds.fixedHeight;

		string speedLabel = Lang.Get("chiselwiz:Chiselling Speed", Array.Empty<object>());
		GuiElementInsetHelper.AddInset(
			GuiElementDynamicTextHelper.AddDynamicText(composer, speedLabel, font, titleBounds, null),
			contentBounds, 1, 1f
		).BeginChildElements();

		int currentSpeed = chiseller.ChiselSpeed;
		ElementBounds sliderBounds = ElementBounds.Fixed(5.0, 8.0, sectionWidth - 10.0, 20.0).WithParent(contentBounds);
		Vintagestory.API.Client.GuiComposerHelpers.AddSlider(composer, (ActionConsumable<int>)delegate(int newVal)
		{
			chiseller.ChiselSpeed = newVal;
			return true;
		}, sliderBounds, "chiselSpeedSlider");
		Vintagestory.API.Client.GuiComposerHelpers.GetSlider(composer, "chiselSpeedSlider").SetValues(currentSpeed, 1, 100, 1, "x");

		composer.EndChildElements();
		return sectionBounds;
	}

}




