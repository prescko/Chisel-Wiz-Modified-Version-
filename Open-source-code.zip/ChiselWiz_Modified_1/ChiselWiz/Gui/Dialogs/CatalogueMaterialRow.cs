﻿using System;
using System.Collections.Generic;
using ChiselWiz.Gui.Elements;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Dialogs;

internal class CatalogueMaterialRow : IVirtualListRow<DesignMaterial>
{
	private ICoreClientAPI capi;

	public GuiElementCWItemStack BlockIconElement;

	public GuiElementDynamicText TextNameElement;

	public GuiElementDynamicText TextCodeElement;

	public int RowHeight => 38;

	public ElementBounds Bounds { get; set; }

	public DesignMaterial Data { get; private set; }

	public void Hide()
	{
		SetData(null);
		Bounds.fixedY = -RowHeight;
		Bounds.CalcWorldBounds();
	}

	public void SetData(DesignMaterial data)
	{
		Data = data;
		if (data == null)
		{
			if (TextNameElement != null)
			{
				TextNameElement.SetNewText("", false, false, false);
			}
			if (TextCodeElement != null)
			{
				TextCodeElement.SetNewText("", false, false, false);
			}
			if (BlockIconElement != null)
			{
				BlockIconElement.SetSourceItemstack(null);
			}
		}
		else
		{
			TextNameElement.SetNewText(data.Stack.Collectible.GetHeldItemName(data.Stack), false, false, false);
			TextCodeElement.SetNewText(((RegistryObject)data.Stack.Collectible).Code.ToString(), false, false, false);
			BlockIconElement.SetSourceItemstack(data.Stack);
		}
	}

	public void Dispose()
	{
		GuiElementCWItemStack blockIconElement = BlockIconElement;
		if (blockIconElement != null)
		{
			((GuiElement)blockIconElement).Dispose();
		}
		GuiElementDynamicText textNameElement = TextNameElement;
		if (textNameElement != null)
		{
			((GuiElement)textNameElement).Dispose();
		}
		GuiElementDynamicText textCodeElement = TextCodeElement;
		if (textCodeElement != null)
		{
			((GuiElement)textCodeElement).Dispose();
		}
	}

	public void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<DesignMaterial>>> actions)
	{

		capi = composer.Api;
		CairoFont val = CairoFont.WhiteSmallishText().WithFontSize(14f);
		CairoFont val2 = val.Clone().WithColor(ColorUtil.Hex2Doubles("#aaaaaa")).WithFontSize(13f);
		Bounds.fixedY = 0.0;
		ElementBounds val3 = Bounds.ForkChild().WithFixedWidth((double)RowHeight);
		ElementBounds val4 = val3.RightCopy(0.0, 5.0, 0.0, 0.0).WithFixedSize(Bounds.fixedWidth - (double)RowHeight, (double)(RowHeight / 2));
		ElementBounds val5 = val4.BelowCopy(0.0, -5.0, 0.0, 0.0);
		BlockIconElement = new GuiElementCWItemStack(capi, val3);
		BlockIconElement.RenderBackground = false;
		TextNameElement = new GuiElementDynamicText(capi, "", val, val4);
		TextCodeElement = new GuiElementDynamicText(capi, "", val2, val5);
		composer.AddInteractiveElement((GuiElement)(object)BlockIconElement, (string)null).AddInteractiveElement((GuiElement)(object)TextNameElement, (string)null).AddInteractiveElement((GuiElement)(object)TextCodeElement, (string)null);
	}

	public void SetSelected(bool selected)
	{
	}
}




