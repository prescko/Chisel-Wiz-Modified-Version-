﻿using System;
using ChiselWiz.Systems.Catalogues;

namespace ChiselWiz.Gui.Dialogs;

public class CatalogueColumn
{
	public string Name;

	public int Width;

	public bool Sortable;

	public ColumnSortDir DefaultSortDir;

	public ColumnSortDir CurrentSortDir;

	public bool DefaultActiveColumn;

	public Comparison<CatalogueDesign> Comparison;
}




