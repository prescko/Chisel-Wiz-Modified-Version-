﻿using SkiaSharp.QrCode;

namespace ChiselWiz.Gui.Dialogs;

internal class ErrorCorrectionOption
{
	public string Name;

	public string Key;

	public ECCLevel Enum;
}




