﻿using ChiselWiz.Systems.Images.Colouring;

namespace ChiselWiz.Gui.Dialogs;

internal class ColourReductionOption
{
	public string Name;

	public string Key;

	public EnumPaletteReductionMethod Enum;

	public Palette MasterPalette;

	public bool AutoMatch;

	public bool AllowReduction;
}




