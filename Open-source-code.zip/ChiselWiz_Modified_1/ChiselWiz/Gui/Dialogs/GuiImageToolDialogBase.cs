﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChiselWiz.ChiselToolModes;
using ChiselWiz.ChiselToolModes.ImageTools;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems;
using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Chiselling;
using ChiselWiz.Systems.Images;
using ChiselWiz.Systems.Images.Colouring;
using ChiselWiz.Systems.Images.Designs;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.Common;
using Vintagestory.GameContent;
using VSSurvivalMod.Systems.ChiselModes;

namespace ChiselWiz.Gui.Dialogs;

public class GuiImageToolDialogBase : GuiDialog
{
	public enum EnumChiselModeOption
	{
		MergeIntoSurface,
		PasteExtrudedShape,
		MergeExtrudedShape
	}

	private class ChiselModeOption
	{
		public string Key;

		public string Name;

		public EnumChiselModeOption Enum;

		public SkillItem ToolModeSkillItem;

		public bool CanSetThickness;
	}

	private class Tile
	{
		public int X;

		public int Y;
	}

	private class ImageDesignMaterial
	{
		public int Index;

		public Block Block;

		public ItemStack Stack;
	}

	private class ImageDesignMaterialRow : IVirtualListRow<ImageDesignMaterial>
	{
		private ICoreClientAPI capi;

		private GuiElementCWItemStack itemSlotElement;

		private GuiElementDynamicText txtName;

		private GuiElementDynamicText txtCode;

		public int RowHeight => 30;

		public ElementBounds Bounds { get; set; }

		public ImageDesignMaterial Data { get; private set; }

		public void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<ImageDesignMaterial>>> actions)
		{

			capi = composer.Api;
			ElementBounds val = Bounds.ForkChildOffseted(0.0, 0.0, 0.0 - Bounds.fixedHeight, 0.0);
			val.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth(Bounds.fixedHeight).WithFixedPadding(5.0)
				.CopyOffsetedSibling(0.0, 0.0, -10.0, -10.0);
			ElementBounds val2 = ElementBounds.Fixed(0.0, 0.0, Bounds.fixedHeight, Bounds.fixedHeight).WithParent(val);
			itemSlotElement = new GuiElementCWItemStack(capi, val2);
			itemSlotElement.RenderBackground = false;
			composer.AddInteractiveElement((GuiElement)(object)itemSlotElement, (string)null);
			val2.CopyOffsetedSibling(2.0, 2.0, -4.0, -4.0);
			CairoFont val3 = CairoFont.WhiteSmallishText().WithFontSize(14f);
			CairoFont val4 = CairoFont.WhiteSmallText().WithFontSize(13f).WithColor(ColorUtil.Hex2Doubles("#aaaaaa"));
			ElementBounds val5 = ElementBounds.Fixed(0.0, 2.0, Bounds.fixedWidth - Bounds.fixedHeight - 45.0, 20.0).FixedRightOf(val2, 5.0).WithParent(val);
			txtName = new GuiElementDynamicText(capi, "", val3, val5);
			composer.AddInteractiveElement((GuiElement)(object)txtName, (string)null);
			ElementBounds val6 = val5.BelowCopy(0.0, -8.0, 0.0, -4.0);
			txtCode = new GuiElementDynamicText(capi, "", val4, val6);
			composer.AddInteractiveElement((GuiElement)(object)txtCode, (string)null);
		}

		public void SetData(ImageDesignMaterial data)
		{
			Data = data;
			itemSlotElement.SetSourceItemstack(data.Stack);
			string heldItemName = data.Stack.Collectible.GetHeldItemName(data.Stack);
			txtName.SetNewText(heldItemName, false, false, false);
			txtCode.SetNewText(((RegistryObject)data.Block).Code.ToString(), false, false, false);
		}

		public void Dispose()
		{
			GuiElementCWItemStack guiElementCWItemStack = itemSlotElement;
			if (guiElementCWItemStack != null)
			{
				((GuiElement)guiElementCWItemStack).Dispose();
			}
			GuiElementDynamicText obj = txtName;
			if (obj != null)
			{
				((GuiElement)obj).Dispose();
			}
			GuiElementDynamicText obj2 = txtCode;
			if (obj2 != null)
			{
				((GuiElement)obj2).Dispose();
			}
		}

		public void Hide()
		{
			Bounds.fixedY = -RowHeight;
			Bounds.CalcWorldBounds();
		}

		public void SetSelected(bool selected)
		{
		}
	}

	private class RemappableImageDesignMaterial
	{
		public int Index;

		public Block Block;

		public SKColor Colour;

		public bool IsEnabled;

		public ItemStack Stack;
	}

	private class RemappableImageMaterialRow : IVirtualListRow<RemappableImageDesignMaterial>
	{
		private ICoreClientAPI capi;

		private GuiElementCWInset inset;

		private GuiElementCWItemStack itemSlotElement;

		private GuiElementSolidColour solidColourElement;

		private GuiElementDynamicText txtName;

		private GuiElementDynamicText txtCode;

		private GuiElementIconButton deleteButton;

		public int RowHeight => 40;

		public ElementBounds Bounds { get; set; }

		public RemappableImageDesignMaterial Data { get; private set; }

		public void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<RemappableImageDesignMaterial>>> actions)
		{

			capi = composer.Api;
			ElementBounds val = Bounds.ForkChildOffseted(0.0, 0.0, 0.0 - Bounds.fixedHeight, 0.0);
			ElementBounds bounds = val.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth(Bounds.fixedHeight).WithFixedPadding(5.0)
				.CopyOffsetedSibling(0.0, 0.0, -10.0, -10.0);
			inset = new GuiElementCWInset(capi, val, delegate
			{
				actions["onClick"](this);
			});
			composer.AddInteractiveElement((GuiElement)(object)inset, (string)null);
			ElementBounds val2 = ElementBounds.Fixed(0.0, 0.0, Bounds.fixedHeight, Bounds.fixedHeight).WithParent(val);
			itemSlotElement = new GuiElementCWItemStack(capi, val2);
			itemSlotElement.RenderBackground = false;
			composer.AddInteractiveElement((GuiElement)(object)itemSlotElement, (string)null);
			ElementBounds bounds2 = val2.CopyOffsetedSibling(2.0, 2.0, -4.0, -4.0);
			solidColourElement = new GuiElementSolidColour(capi, bounds2);
			composer.AddInteractiveElement((GuiElement)(object)solidColourElement, (string)null);
			CairoFont val3 = CairoFont.WhiteSmallishText().WithFontSize(16f);
			CairoFont val4 = CairoFont.WhiteSmallText().WithFontSize(13f).WithColor(ColorUtil.Hex2Doubles("#aaaaaa"));
			ElementBounds val5 = ElementBounds.Fixed(0.0, 3.0, Bounds.fixedWidth - Bounds.fixedHeight - 45.0, 20.0).FixedRightOf(val2, 5.0).WithParent(val);
			txtName = new GuiElementDynamicText(capi, "", val3, val5);
			composer.AddInteractiveElement((GuiElement)(object)txtName, (string)null);
			ElementBounds val6 = val5.BelowCopy(0.0, -2.0, 0.0, -4.0);
			txtCode = new GuiElementDynamicText(capi, "", val4, val6);
			composer.AddInteractiveElement((GuiElement)(object)txtCode, (string)null);
			deleteButton = new GuiElementIconButton(capi, new AssetLocation("chiselwiz", "textures/icons/togglevisible.svg"), null, null, (ActionConsumable)delegate
			{
				actions.TryGetValue("onToggle", out var value);
				value?.Invoke(this);
				return true;
			}, bounds, (EnumButtonStyle)2);
			deleteButton.Toggleable = true;
			composer.AddInteractiveElement((GuiElement)(object)deleteButton, (string)null);
		}

		public void SetData(RemappableImageDesignMaterial data)
		{

			Data = data;
			itemSlotElement.SetSourceItemstack(data.Stack);
			solidColourElement.SetColour(data.Colour);
			if (data.Block != null)
			{
				string heldItemName = data.Stack.Collectible.GetHeldItemName(data.Stack);
				txtName.SetNewText(heldItemName, false, false, false);
				txtCode.SetNewText(((RegistryObject)data.Block).Code.ToString(), false, false, false);
			}
			else
			{
				txtName.SetNewText("", false, false, false);
				txtCode.SetNewText("", false, false, false);
			}
			deleteButton.Toggled = data.IsEnabled;
		}

		public void Dispose()
		{
			GuiElementSolidColour guiElementSolidColour = solidColourElement;
			if (guiElementSolidColour != null)
			{
				((GuiElement)guiElementSolidColour).Dispose();
			}
			GuiElementCWInset guiElementCWInset = inset;
			if (guiElementCWInset != null)
			{
				((GuiElement)guiElementCWInset).Dispose();
			}
			GuiElementCWItemStack guiElementCWItemStack = itemSlotElement;
			if (guiElementCWItemStack != null)
			{
				((GuiElement)guiElementCWItemStack).Dispose();
			}
			GuiElementDynamicText obj = txtName;
			if (obj != null)
			{
				((GuiElement)obj).Dispose();
			}
			GuiElementDynamicText obj2 = txtCode;
			if (obj2 != null)
			{
				((GuiElement)obj2).Dispose();
			}
			GuiElementIconButton guiElementIconButton = deleteButton;
			if (guiElementIconButton != null)
			{
				((GuiElement)guiElementIconButton).Dispose();
			}
		}

		public void Hide()
		{
			Bounds.fixedY = -RowHeight;
			Bounds.CalcWorldBounds();
		}

		public void SetSelected(bool selected)
		{
			if (inset != null)
			{
				inset.Selected = selected;
			}
		}
	}

	private SkillItem defaultChiselMode = new SkillItem
	{
		Code = new AssetLocation("1size"),
		Name = Lang.Get("1x1x1", Array.Empty<object>()),
		Data = (object)new OneByChiselMode()
	};

	protected ImageDesign imageDesign;

	protected ChiselOperator chiseller;

	protected ImageDesignLoader imageDesignLoader;

	protected ChiselToolModeManager toolModeManager;

	protected Dictionary<string, GuiElementCWInset> gridInsets;

	protected GuiElementCWImage imagePreviewElement;

	private VirtualListScroller<RemappableImageDesignMaterial, RemappableImageMaterialRow> remappableMaterialList;

	private VirtualListScroller<ImageDesignMaterial, ImageDesignMaterialRow> materialShoppingList;

	private int extrusionThickness = 4;

	private bool useNearbyInventories;

	private bool setBlueprintName;

	private ChiselModeOption selectedChiselModeOption;

	private List<ChiselModeOption> chiselModeOptions;

	private Tile selectedTile;

	private BlockBlueprint selectedTileBlueprint;

	private ItemStack lastChiselBlockForMaterialCycle;

	private int materialCycleIndex;

	private int lastMaterialCycleIdx;

	private List<Block> materialCycleCodes;

	protected virtual string compName => "chiselwiz:imagedesignbase";

	protected virtual string titleText => "";

	protected virtual string generateButtonTextString => "Generate Button";

	protected virtual bool HasPaletteReductionOption => false;

	protected virtual bool HasChiselModeOption => true;

	protected virtual bool HasMaterialsList => true;

	protected virtual double MaterialsListHeight => 245.0;

	public override string ToggleKeyCombinationCode => null;

	public override bool PrefersUngrabbedMouse => false;

	public override EnumDialogType DialogType => (EnumDialogType)0;

	public GuiImageToolDialogBase(ICoreClientAPI capi, ChiselOperator chiseller, ChiselToolModeManager toolModeManager, ImageDesignLoader imageDesignLoader)
		: base(capi)
	{

		this.imageDesignLoader = imageDesignLoader;
		this.chiseller = chiseller;
		this.toolModeManager = toolModeManager;
		gridInsets = new Dictionary<string, GuiElementCWInset>();
		chiselModeOptions = new List<ChiselModeOption>
		{
			new ChiselModeOption
			{
				Enum = EnumChiselModeOption.MergeIntoSurface,
				Key = "mergeintosurface",
				Name = Lang.Get("chiselwiz:Merge Into Surface", Array.Empty<object>()),
				ToolModeSkillItem = new SkillItem
				{
					Data = new ImageMergeSurfaceMode(chiseller)
				}
			},
			new ChiselModeOption
			{
				Enum = EnumChiselModeOption.PasteExtrudedShape,
				Key = "pasteextrudedshape",
				Name = Lang.Get("chiselwiz:Paste Extruded Shape", Array.Empty<object>()),
				CanSetThickness = true,
				ToolModeSkillItem = new SkillItem
				{
					Data = new ImagePasteExtrudedShapeMode(chiseller)
				}
			},
			new ChiselModeOption
			{
				Enum = EnumChiselModeOption.MergeExtrudedShape,
				Key = "mergeextrudedshape",
				Name = Lang.Get("chiselwiz:Merge Extruded Shape", Array.Empty<object>()),
				CanSetThickness = true,
				ToolModeSkillItem = new SkillItem
				{
					Data = new ImageMergeExtrudedShapeMode(chiseller, replace: false)
				}
			},
			new ChiselModeOption
			{
				Enum = EnumChiselModeOption.MergeExtrudedShape,
				Key = "mergereplaceextrudedshape",
				Name = Lang.Get("chiselwiz:Merge (Replace) Extruded Shape", Array.Empty<object>()),
				CanSetThickness = true,
				ToolModeSkillItem = new SkillItem
				{
					Data = new ImageMergeExtrudedShapeMode(chiseller, replace: true)
				}
			}
		};
	}

	public override bool TryOpen()
	{
		selectedTile = null;
		Compose();
		return base.TryOpen();
	}

	public override bool TryClose()
	{
		if (selectedTile != null && selectedTileBlueprint == chiseller.ClipboardBlueprint)
		{
			chiseller.SetClipboardBlueprint(null);
			toolModeManager.TrySetToolMode(0, defaultChiselMode, null);
		}
		return base.TryClose();
	}

	public void SetImageDesign(ImageDesign imageDesign)
	{
		this.imageDesign?.Dispose();
		this.imageDesign = imageDesign;
		selectedTile = null;
		Compose();
	}

	protected virtual bool OnClickGenerate()
	{
		return true;
	}

	private void Compose()
	{

		((GuiDialog)this).ClearComposers();
		int num = 300;
		CairoFont font = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2);
		CairoFont.WhiteSmallishText();
		CairoFont val = CairoFont.WhiteSmallText();
		ElementBounds fill = ElementBounds.Fill;
		ElementBounds val2 = ElementBounds.Fixed((EnumDialogArea)1, 0.0, 0.0, (double)num, GuiStyle.TitleBarHeight + 360.0).WithFixedAlignmentOffset(50.0, 50.0);
		ElementBounds val3 = ElementBounds.Fixed(0.0, GuiStyle.TitleBarHeight, (double)(num - 20), 0.0).WithFixedPadding(10.0).WithParent(val2);
		val3.CalcWorldBounds();
		ElementBounds val4 = ElementBounds.Fixed(0.0, 0.0, val3.fixedWidth, 40.0).WithParent(val3);
		ElementBounds val5 = val4.BelowCopy(0.0, 10.0, 0.0, 0.0);
		val5.fixedHeight = val5.fixedWidth;
		ElementBounds bounds = val5.ForkChildOffseted(4.0, 4.0, -8.0, -8.0);
		ElementBounds val6 = val5.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedHeight(55.0);
		if (HasChiselModeOption)
		{
			val6.fixedHeight += 145.0;
		}
		val2.fixedHeight += val6.fixedHeight;
		ElementBounds val7 = val6.ForkChildOffseted(10.0, 15.0, 0.0, 0.0).WithFixedSize(30.0, 30.0);
		ElementBounds val8 = val7.RightCopy(10.0, 5.0, 0.0, 0.0).WithFixedWidth(val6.fixedWidth - 60.0);
		ElementBounds val9 = val7.BelowCopy(0.0, 15.0, 0.0, 0.0).WithFixedWidth(val6.fixedWidth - 20.0);
		ElementBounds val10 = val9.BelowCopy(0.0, -5.0, 0.0, 0.0);
		ElementBounds thicknessOptionBounds = val6.CopyOffsetedSibling(-100.0, 0.0, 200.0, 0.0);
		ElementBounds val11 = val10.BelowCopy(0.0, 15.0, 0.0, 0.0);
		ElementBounds bounds2 = val11.BelowCopy(0.0, -5.0, 0.0, 0.0);
		ElementBounds val12 = val6.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedHeight(HasMaterialsList ? MaterialsListHeight : 0.0);
		ElementBounds val13 = val12.CopyOffsetedSibling(0.0, 0.0, -60.0, 0.0);
		ElementBounds val14 = val13.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth(40.0);
		val2.fixedHeight += val12.fixedHeight;
		ElementBounds val15 = val12.BelowCopy(0.0, 10.0, 0.0, 0.0).WithFixedHeight(35.0);
		ElementBounds val16 = val15.BelowCopy(0.0, 5.0, 0.0, 0.0).WithFixedSize(30.0, 30.0);
		ElementBounds val17 = val16.RightCopy(10.0, -4.0, 0.0, 10.0).WithFixedWidth(val15.fixedWidth - val16.fixedWidth - 10.0);
		if (HasPaletteReductionOption)
		{
			val2.fixedHeight += 80.0;
		}
		GuiComposer val18 = Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo(compName, val2), fill, true, 5.0, 0.75f), titleText, (Action)delegate
		{
			((GuiDialog)this).TryClose();
		}, (CairoFont)null, (ElementBounds)null, (string)null).BeginChildElements();
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/new.svg"), generateButtonTextString, font, new ActionConsumable(OnClickGenerate), val4, (EnumButtonStyle)3);
		val18.AddInteractiveElement((GuiElement)(object)guiElementIconButton, (string)null);
		imagePreviewElement = new GuiElementCWImage(base.capi, bounds);
		if (imageDesign != null)
		{
			SetPreviewImage(imageDesign.PreviewBitmap);
		}
		GuiElementInsetHelper.AddInset(val18, val5.FlatCopy(), 4, 0.85f);
		val18.AddInteractiveElement((GuiElement)(object)imagePreviewElement, (string)null);
		if (imagePreviewElement.HasBitmap)
		{
			val18.BeginChildElements();
			ElementBounds[,] array = imagePreviewElement.GenerateGridBounds(16, val5.ForkChild());
			gridInsets.Clear();
			for (int num2 = 0; num2 < array.GetLength(0); num2++)
			{
				for (int num3 = 0; num3 < array.GetLength(1); num3++)
				{
					int tileX = num2;
					int tileY = num3;
					GuiElementCWInset guiElementCWInset = new GuiElementCWInset(base.capi, array[tileX, tileY], delegate
					{
						OnTileClick(tileX, tileY);
					});
					guiElementCWInset.DrawParams.BorderThickness = 1;
					guiElementCWInset.DrawParams.HighlightColorRGBA = new double[4] { 1.0, 1.0, 1.0, 0.2 };
					guiElementCWInset.ThrobWhenSelected = true;
					gridInsets[$"tile-{tileX}-{tileY}"] = guiElementCWInset;
					val18.AddInteractiveElement((GuiElement)(object)guiElementCWInset, (string)null);
					if (selectedTile != null && selectedTile.X == num2 && selectedTile.Y == num3)
					{
						guiElementCWInset.Selected = true;
					}
				}
			}
			val18.EndChildElements();
		}
		GuiElementInsetHelper.AddInset(val18, val6.FlatCopy(), 1, 1f);
		Vintagestory.API.Client.GuiComposerHelpers.AddSwitch(val18, (Action<bool>)delegate(bool flag)
		{
			setBlueprintName = flag;
			PrepareForChiselling(playSfx: false);
		}, val7, "nameWithTileCoordinates", 30.0, 4.0);
		GuiElementDynamicTextHelper.AddDynamicText(val18, Lang.Get("chiselwiz:Set target block's name.", Array.Empty<object>()), val, val8, (string)null);
		double originalThicknessOptionHeight = thicknessOptionBounds.fixedHeight;
		Action<bool> SetThicknessOptionVisible = delegate(bool visible)
		{
			thicknessOptionBounds.fixedHeight = (visible ? originalThicknessOptionHeight : 0.0);
			thicknessOptionBounds.CalcWorldBounds();
		};
		if (HasChiselModeOption)
		{
			GuiElementDynamicTextHelper.AddDynamicText(val18, Lang.Get("chiselwiz:Chisel Mode", Array.Empty<object>()), val, val9, (string)null);
			string[] array2 = chiselModeOptions.Select((ChiselModeOption m) => m.Key).ToArray();
			string[] array3 = chiselModeOptions.Select((ChiselModeOption m) => m.Name).ToArray();
			int num4 = 0;
			if (selectedChiselModeOption != null)
			{
				num4 = chiselModeOptions.IndexOf(selectedChiselModeOption);
			}
			Vintagestory.API.Client.GuiComposerHelpers.AddDropDown(val18, array2, array3, num4, (SelectionChangedDelegate)delegate(string code, bool selected)
			{
				selectedChiselModeOption = chiselModeOptions.Find((ChiselModeOption mode) => mode.Key == code);
				SetThicknessOptionVisible(selectedChiselModeOption.CanSetThickness);
				PrepareForChiselling(playSfx: false);
			}, val10, "chiselModeDropdown");
			GuiElementClipHelpler.BeginClip(val18, thicknessOptionBounds);
			GuiElementDynamicTextHelper.AddDynamicText(val18, Lang.Get("chiselwiz:Extrusion Thickness", Array.Empty<object>()), val, val11, (string)null);
			GuiElementCWSlider guiElementCWSlider = new GuiElementCWSlider(base.capi, delegate(int num5)
			{
				extrusionThickness = num5;
				PrepareForChiselling(playSfx: false);
				return true;
			}, bounds2);
			val18.AddInteractiveElement((GuiElement)(object)guiElementCWSlider, "thicknessSlider");
			Vintagestory.API.Client.GuiComposerHelpers.GetSlider(val18, "thicknessSlider").SetValues(extrusionThickness, 1, 16, 1, " voxels");
			GuiElementClipHelpler.EndClip(val18);
		}
		if (HasMaterialsList)
		{
			if (imageDesign is BasicImageDesign)
			{
				remappableMaterialList = new VirtualListScroller<RemappableImageDesignMaterial, RemappableImageMaterialRow>(base.capi, val18, val12);
				remappableMaterialList.AddCallback("onClick", delegate(IVirtualListRow<RemappableImageDesignMaterial> row)
				{
					OnClickMaterial(row as RemappableImageMaterialRow);
				});
				remappableMaterialList.AddCallback("onToggle", delegate(IVirtualListRow<RemappableImageDesignMaterial> row)
				{
					OnToggleMaterial(row as RemappableImageMaterialRow);
				});
				remappableMaterialList.Compose();
				Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val18, Lang.Get("chiselwiz:Drop materials here to replace the materials in the design.", Array.Empty<object>()), val, 200, val13, (string)null);
				Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(val18, Lang.Get("chiselwiz:Enable/Disable this colour in the design.", Array.Empty<object>()), val, 200, val14, (string)null);
			}
			else if (imageDesign is ComplexImageDesign)
			{
				materialShoppingList = new VirtualListScroller<ImageDesignMaterial, ImageDesignMaterialRow>(base.capi, val18, val12);
				materialShoppingList.Compose();
			}
		}
		if (HasPaletteReductionOption)
		{
			GuiElementIconButton guiElementIconButton2 = new GuiElementIconButton(base.capi, null, Lang.Get("chiselwiz:Adapt to available materials", Array.Empty<object>()), font, (ActionConsumable)delegate
			{
				FindAllBlockTypesInInventory().ContinueWith(delegate(Task<HashSet<Block>> task)
				{
					HashSet<Block> result = task.Result;
					imageDesign.CreateSubsetPaletteFromMaster(result);
					imageDesign.ComputePaletteColourMapping(null, null);
					((IEventAPI)base.capi.Event).EnqueueMainThreadTask((Action)delegate
					{
						imageDesign.RedrawPreviewBitmap();
						UpdateMaterialsList();
						SetPreviewImage(imageDesign.PreviewBitmap);
						PrepareForChiselling(playSfx: false);
					}, "updateimagepreview");
				});
				return true;
			}, val15, (EnumButtonStyle)2);
			val18.AddInteractiveElement((GuiElement)(object)guiElementIconButton2, (string)null);
			Vintagestory.API.Client.GuiComposerHelpers.AddSwitch(val18, (Action<bool>)delegate(bool flag)
			{
				useNearbyInventories = flag;
				PrepareForChiselling(playSfx: false);
			}, val16, "useNearbyInventories", 30.0, 4.0);
			GuiElementDynamicTextHelper.AddDynamicText(val18, Lang.Get("chiselwiz:Search for materials in nearby containers", Array.Empty<object>()), val, val17, (string)null);
		}
		((GuiDialog)this).SingleComposer = val18.EndChildElements().Compose(false);
		if (selectedChiselModeOption == null)
		{
			selectedChiselModeOption = chiselModeOptions[0];
		}
		Vintagestory.API.Client.GuiComposerHelpers.GetSwitch(((GuiDialog)this).SingleComposer, "nameWithTileCoordinates").SetValue(setBlueprintName);
		if (HasChiselModeOption)
		{
			Vintagestory.API.Client.GuiComposerHelpers.GetDropDown(((GuiDialog)this).SingleComposer, "chiselModeDropdown").SetSelectedIndex(chiselModeOptions.IndexOf(selectedChiselModeOption));
			SetThicknessOptionVisible(selectedChiselModeOption.CanSetThickness);
		}
		if (HasPaletteReductionOption)
		{
			Vintagestory.API.Client.GuiComposerHelpers.GetSwitch(((GuiDialog)this).SingleComposer, "useNearbyInventories").SetValue(useNearbyInventories);
		}
		UpdateMaterialsList();
	}

	private void UpdateMaterialsList()
	{
		if (imageDesign is BasicImageDesign basicImageDesign && remappableMaterialList != null)
		{
			List<RemappableImageDesignMaterial> items = basicImageDesign.IndexedDesignPalette.Where((RemappablePaletteEntry entry) => entry != null).Select((RemappablePaletteEntry remappableEntry, int idx) => GetRemappableMaterial(remappableEntry, idx)).ToList();
			remappableMaterialList.SetItems(items);
		}
		else if (imageDesign is ComplexImageDesign complexImageDesign && materialShoppingList != null)
		{
			List<ImageDesignMaterial> items2 = complexImageDesign.SubsetPalette.Entries.Where((PaletteEntry entry) => entry != null).Select((PaletteEntry entry, int idx) => GetMaterial(entry, idx)).ToList();
			materialShoppingList.SetItems(items2);
		}
	}

	private async Task<List<ItemSlot>> GetContentsOfAllNearbyInventories(int range)
	{
		List<ItemSlot> slots = new List<ItemSlot>();
		try
		{
			BlockPos asBlockPos = ((Entity)((IPlayer)base.capi.World.Player).Entity).Pos.AsBlockPos;
			OpenableContainerManager mgr = new OpenableContainerManager(base.capi);
			List<BlockEntityOpenableContainer> containers = mgr.FindAllNear(asBlockPos, range);
			List<BlockEntityOpenableContainer> unopenedContainers = containers.Where((BlockEntityOpenableContainer c) => !((BlockEntityContainer)c).Inventory.HasOpened((IPlayer)(object)base.capi.World.Player)).ToList();
			await mgr.ToggleOpen((IEnumerable<BlockEntityOpenableContainer>)unopenedContainers);
			foreach (BlockEntityOpenableContainer item in containers)
			{
				foreach (ItemSlot item2 in ((BlockEntityContainer)item).Inventory)
				{
					if (!item2.Empty)
					{
						slots.Add(item2);
					}
				}
			}
			await mgr.ToggleOpen((IEnumerable<BlockEntityOpenableContainer>)unopenedContainers);
		}
		catch (Exception ex)
		{
			((ICoreAPI)base.capi).Logger.Error(ex);
		}
		return slots;
	}

	private async Task<HashSet<Block>> FindAllBlockTypesInInventory()
	{
		HashSet<Block> blocks = new HashSet<Block>();
		IPlayerInventoryManager inventoryManager = ((IPlayer)base.capi.World.Player).InventoryManager;
		Dictionary<string, IInventory> invs = inventoryManager.Inventories;
		if (useNearbyInventories)
		{
			List<ItemSlot> list = await GetContentsOfAllNearbyInventories(5);
			foreach (ItemSlot item in list)
			{
				_ = item;
				IEnumerable<Block> enumerable = from block in list.Select(delegate(ItemSlot slot)
					{
						ItemStack itemstack = slot.Itemstack;
						return (itemstack == null) ? null : itemstack.Block;
					})
					where block != null && Palette.IsValidChiselingMaterial(base.capi, block)
					select block;
				HashsetExtensions.AddRange<Block>(blocks, enumerable);
			}
		}
		foreach (var (_, val2) in invs)
		{
			if (!(val2 is InventoryPlayerCreative) || (int)((IPlayer)base.capi.World.Player).WorldData.CurrentGameMode == 2)
			{
				IEnumerable<Block> enumerable2 = from block in ((IEnumerable<ItemSlot>)val2).Select(delegate(ItemSlot slot)
					{
						ItemStack itemstack = slot.Itemstack;
						return (itemstack == null) ? null : itemstack.Block;
					})
					where block != null && Palette.IsValidChiselingMaterial(base.capi, block)
					select block;
				HashsetExtensions.AddRange<Block>(blocks, enumerable2);
			}
		}
		return blocks;
	}

	private void DeselectAllTiles()
	{
		foreach (GuiElementCWInset value in gridInsets.Values)
		{
			value.Selected = false;
		}
		selectedTile = null;
	}

	private void OnTileClick(int tileX, int tileY)
	{
		DeselectAllTiles();
		gridInsets[$"tile-{tileX}-{tileY}"].Selected = true;
		selectedTile = new Tile
		{
			X = tileX,
			Y = tileY
		};
		PrepareForChiselling();
	}

	private void PrepareForChiselling(bool playSfx = true)
	{
		if (selectedTile != null)
		{
			selectedTileBlueprint = imageDesign.CreateBlockBlueprint(selectedTile.X, selectedTile.Y);
			if (selectedTileBlueprint != null)
			{
				List<string> list = new List<string>();
				if (imageDesign.Name != null && imageDesign.Name != "")
				{
					list.Add(imageDesign.Name);
				}
				list.Add($"[{selectedTile.X + 1}, {selectedTile.Y + 1}]");
				selectedTileBlueprint.Name = string.Join("\r\n", list);
				selectedTileBlueprint.SetNameOnPaste = setBlueprintName;
			}
			chiseller.SetClipboardBlueprint(selectedTileBlueprint, EnumBlockRenderMode.FaceForward, playSfx);
		}
		if (selectedChiselModeOption != null)
		{
			toolModeManager.SetCWToolMode(0, selectedChiselModeOption.ToolModeSkillItem);
		}
		CWChiselMode obj = selectedChiselModeOption.ToolModeSkillItem.Data as CWChiselMode;
		obj.CurrentStrength = extrusionThickness;
		obj.UseMaterialsInNearbyInventories = useNearbyInventories;
	}

	private RemappableImageDesignMaterial GetRemappableMaterial(RemappablePaletteEntry remappableEntry, int index, RemappableImageDesignMaterial data = null)
	{

		ItemStack stack = null;
		if (remappableEntry.Block != null)
		{
			stack = new ItemStack(remappableEntry.Block, 1);
		}
		if (data == null)
		{
			return new RemappableImageDesignMaterial
			{
				Index = index,
				Block = remappableEntry.Block,
				IsEnabled = remappableEntry.Enabled,
				Stack = stack,
				Colour = remappableEntry.Colour
			};
		}
		data.Block = remappableEntry.Block;
		data.IsEnabled = remappableEntry.Enabled;
		data.Stack = stack;
		data.Colour = remappableEntry.Colour;
		return data;
	}

	private ImageDesignMaterial GetMaterial(PaletteEntry entry, int index, ImageDesignMaterial data = null)
	{

		ItemStack stack = new ItemStack(entry.Block, 1);
		if (data == null)
		{
			return new ImageDesignMaterial
			{
				Index = index,
				Block = entry.Block,
				Stack = stack
			};
		}
		data.Block = entry.Block;
		data.Stack = stack;
		return data;
	}

	private void OnToggleMaterial(RemappableImageMaterialRow row)
	{
		if (imageDesign is BasicImageDesign basicImageDesign)
		{
			RemappablePaletteEntry remappablePaletteEntry = basicImageDesign.IndexedDesignPalette[row.Data.Index];
			row.Data.IsEnabled = !remappablePaletteEntry.Enabled;
			remappablePaletteEntry.Enabled = row.Data.IsEnabled;
			basicImageDesign.RedrawPreviewBitmap();
			imagePreviewElement?.SetBitmap(imageDesign.PreviewBitmap);
		}
		PrepareForChiselling(playSfx: false);
	}

	private void OnClickMaterial(RemappableImageMaterialRow row)
	{
		if (!(imageDesign is BasicImageDesign basicImageDesign))
		{
			return;
		}
		ItemSlot mouseItemSlot = ((IPlayer)base.capi.World.Player).InventoryManager.MouseItemSlot;
		int index = row.Data.Index;
		if (index < 0)
		{
			return;
		}
		if (mouseItemSlot.Empty)
		{
			lastChiselBlockForMaterialCycle = null;
			return;
		}
		ItemStack itemstack = mouseItemSlot.Itemstack;
		if (((itemstack != null) ? itemstack.Block : null) is BlockChisel)
		{
			BlockBlueprint blockBlueprint = BlockBlueprint.FromItemStack(base.capi, mouseItemSlot.Itemstack);
			if (lastChiselBlockForMaterialCycle == null || !lastChiselBlockForMaterialCycle.Equals((IWorldAccessor)(object)base.capi.World, mouseItemSlot.Itemstack, GlobalConstants.IgnoredStackAttributes))
			{
				lastChiselBlockForMaterialCycle = mouseItemSlot.Itemstack.Clone();
				materialCycleIndex = 0;
				Dictionary<byte, int> dictionary = new Dictionary<byte, int>();
				for (int i = 0; i < 16; i++)
				{
					for (int j = 0; j < 16; j++)
					{
						for (int k = 0; k < 16; k++)
						{
							if (blockBlueprint.Voxels[i, j, k])
							{
								byte key = blockBlueprint.Materials[i, j, k];
								dictionary.TryGetValue(key, out var value);
								dictionary[key] = value + 1;
							}
						}
					}
				}
				List<byte> first = (from kvp in dictionary
					orderby kvp.Value descending
					select kvp.Key).ToList();
				List<byte> second = (from num in Enumerable.Range(0, blockBlueprint.MaterialCodes.Count)
					select (byte)num).ToList();
				List<byte> list = first.Union(second).ToList();
				HashSet<string> hashSet = new HashSet<string>();
				materialCycleCodes = new List<Block>();
				foreach (byte item in list)
				{
					if (item < blockBlueprint.MaterialCodes.Count)
					{
						string text = blockBlueprint.MaterialCodes[item];
						if (hashSet.Add(text))
						{
							Block block = ((IWorldAccessor)base.capi.World).GetBlock(new AssetLocation(text));
							materialCycleCodes.Add(block);
						}
					}
				}
			}
			if (materialCycleCodes != null && materialCycleCodes.Count > 0)
			{
				if (row.Data.Index != lastMaterialCycleIdx)
				{
					lastMaterialCycleIdx = row.Data.Index;
					materialCycleIndex = 0;
				}
				Block val = materialCycleCodes[materialCycleIndex];
				if (val == row.Data.Block)
				{
					materialCycleIndex = (materialCycleIndex + 1) % materialCycleCodes.Count;
					val = materialCycleCodes[materialCycleIndex];
				}
				RemappablePaletteEntry remappablePaletteEntry = basicImageDesign.IndexedDesignPalette[index];
				remappablePaletteEntry.Block = val;
				materialCycleIndex = (materialCycleIndex + 1) % materialCycleCodes.Count;
				GetRemappableMaterial(remappablePaletteEntry, row.Data.Index, row.Data);
				row.SetData(row.Data);
				basicImageDesign.RedrawPreviewBitmap();
				imagePreviewElement.SetBitmap(basicImageDesign.PreviewBitmap);
			}
			return;
		}
		ItemStack itemstack2 = mouseItemSlot.Itemstack;
		if (((itemstack2 != null) ? itemstack2.Block : null) != null)
		{
			if (Palette.IsValidChiselingMaterial(base.capi, mouseItemSlot.Itemstack.Block))
			{
				Block block2 = mouseItemSlot.Itemstack.Block;
				RemappablePaletteEntry remappablePaletteEntry2 = basicImageDesign.IndexedDesignPalette[index];
				remappablePaletteEntry2.Block = block2;
				lastChiselBlockForMaterialCycle = null;
				GetRemappableMaterial(remappablePaletteEntry2, row.Data.Index, row.Data);
				row.SetData(row.Data);
				basicImageDesign.RedrawPreviewBitmap();
				imagePreviewElement.SetBitmap(basicImageDesign.PreviewBitmap);
			}
			else
			{
				base.capi.TriggerIngameError((object)this, "badmaterial", Lang.Get("chiselwiz:Can't use this material for chiselling", Array.Empty<object>()));
			}
		}
	}

	private void SetPreviewImage(SKBitmap bitmap)
	{
		imagePreviewElement.SetBitmap(bitmap);
	}
}




