﻿using System;
using System.Collections.Generic;
using System.Linq;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Catalogues;
using ChiselWiz.Systems.Chiselling;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace ChiselWiz.Gui.Dialogs;

public class GuiDesignCatalogue : GuiDialog
{
	private CatalogueCollection catalogues;

	private ICatalogue activeCatalogue;

	private ChiselOperator chiseller;

	public static CatalogueColumn[] columns;

	private CatalogueDesign selectedDesign;

	private float lastScrollPos;

	private string filterText;

	private CatalogueColumn sortColumn;

	private List<CatalogueDesign> searchResults;

	private VirtualListScroller<CatalogueDesign, CatalogueRow> designList;

	private List<DesignMaterial> designMaterials;

	private VirtualListScroller<DesignMaterial, CatalogueMaterialRow> materialList;

	public override string ToggleKeyCombinationCode => null;

	public GuiDesignCatalogue(ICoreClientAPI capi, CatalogueCollection catalogues, ChiselOperator chiseller)
		: base(capi)
	{
		this.catalogues = catalogues;
		activeCatalogue = catalogues[0];
		this.chiseller = chiseller;
		columns = new CatalogueColumn[3]
		{
			new CatalogueColumn
			{
				Sortable = false,
				Name = "chiselwiz:Block",
				Width = 50
			},
			new CatalogueColumn
			{
				Sortable = true,
				Name = "chiselwiz:Name",
				Width = 400,
				DefaultSortDir = ColumnSortDir.Up,
				DefaultActiveColumn = true,
				Comparison = (CatalogueDesign a, CatalogueDesign b) => a.Name.CompareTo(b.Name)
			},
			new CatalogueColumn
			{
				Sortable = true,
				Name = "chiselwiz:Date Added",
				Width = 200,
				DefaultSortDir = ColumnSortDir.Down,
				Comparison = (CatalogueDesign a, CatalogueDesign b) => a.DateAdded.CompareTo(b.DateAdded)
			}
		};
	}

	private void UpdateSearchResults()
	{
		searchResults = new List<CatalogueDesign>(activeCatalogue.Designs);
		if (filterText != null)
		{
			searchResults = searchResults.FindAll((CatalogueDesign design) => StringExtensions.CaseInsensitiveContains(design.Name, filterText, StringComparison.CurrentCultureIgnoreCase));
		}
		if (sortColumn != null)
		{
			searchResults.Sort(sortColumn.Comparison);
			if (sortColumn.CurrentSortDir == ColumnSortDir.Down)
			{
				searchResults.Reverse();
			}
		}
		GuiComposer singleComposer = ((GuiDialog)this).SingleComposer;
		GuiElementDynamicText val = ((singleComposer != null) ? GuiElementDynamicTextHelper.GetDynamicText(singleComposer, "resultcount") : null);
		if (val != null)
		{
			val.SetNewText(Lang.Get("chiselwiz:Showing {0} design(s)", new object[1] { searchResults.Count }), false, false, false);
		}
		designList.SetItems(searchResults);
	}

	public override void OnGuiOpened()
	{
		base.OnGuiOpened();
		float restoreScrollPos = lastScrollPos;
		Compose();
		if (searchResults == null || searchResults.Count == 0)
		{
			ResetFilter();
			ResetSort();
		}
		UpdateSearchResults();
		designList.UpdateView(updateScrollbar: true, restoreScrollPos);
		lastScrollPos = restoreScrollPos;
	}

	private void ResetSort()
	{
		sortColumn = null;
		CatalogueColumn[] array = columns;
		foreach (CatalogueColumn catalogueColumn in array)
		{
			if (catalogueColumn.DefaultActiveColumn)
			{
				sortColumn = catalogueColumn;
				catalogueColumn.CurrentSortDir = catalogueColumn.DefaultSortDir;
			}
			else
			{
				catalogueColumn.CurrentSortDir = ColumnSortDir.None;
			}
		}
		UpdateSortControlIcons();
		UpdateSearchResults();
	}

	private void ResetFilter()
	{
		filterText = "";
		GuiElementTextInput textInput = Vintagestory.API.Client.GuiComposerHelpers.GetTextInput(((GuiDialog)this).SingleComposer, "searchinput");
		if (textInput != null)
		{
			((GuiElementEditableTextBase)textInput).SetValue("", true);
			((GuiDialog)this).SingleComposer.FocusElement(((GuiElement)textInput).TabIndex);
		}
		UpdateSearchResults();
	}

	private void OnFilterValueChange(string filterText)
	{
		this.filterText = filterText;
		UpdateSearchResults();
	}

	private void UpdateSortControlIcons()
	{
		CatalogueColumn[] array = columns;
		foreach (CatalogueColumn catalogueColumn in array)
		{
			if (catalogueColumn.Sortable)
			{
				GuiElementIcon guiElementIcon = (GuiElementIcon)(object)((GuiDialog)this).SingleComposer.GetElement("col-" + catalogueColumn.Name + "-sorticon");
				if (catalogueColumn.CurrentSortDir == ColumnSortDir.None)
				{
					guiElementIcon.Visible = false;
					continue;
				}
				guiElementIcon.Visible = true;
				guiElementIcon.IconIdx = (int)(catalogueColumn.CurrentSortDir - 1);
			}
		}
	}

	private void ToggleSort(CatalogueColumn toggledColumn)
	{
		CatalogueColumn[] array = columns;
		foreach (CatalogueColumn catalogueColumn in array)
		{
			if (!catalogueColumn.Sortable)
			{
				continue;
			}
			if (catalogueColumn == toggledColumn)
			{
				if (catalogueColumn.CurrentSortDir == ColumnSortDir.None)
				{
					catalogueColumn.CurrentSortDir = catalogueColumn.DefaultSortDir;
				}
				else if (catalogueColumn.CurrentSortDir == ColumnSortDir.Up)
				{
					catalogueColumn.CurrentSortDir = ColumnSortDir.Down;
				}
				else
				{
					catalogueColumn.CurrentSortDir = ColumnSortDir.Up;
				}
			}
			else
			{
				catalogueColumn.CurrentSortDir = ColumnSortDir.None;
			}
		}
		sortColumn = toggledColumn;
		UpdateSortControlIcons();
		UpdateSearchResults();
	}

	private void SetPreview(CatalogueDesign design)
	{
		designList.SetDataSelected(design);
		if (design == null)
		{
			designMaterials = null;
			selectedDesign = null;
		}
		else if (design != selectedDesign)
		{
			selectedDesign = design;
			designMaterials = design.Blueprint.MaterialCodes.Select(delegate(string code)
			{

				Block block = ((IWorldAccessor)base.capi.World).GetBlock(new AssetLocation(code));
				bool isMissing = false;
				if (block == null)
				{
					block = ((IWorldAccessor)base.capi.World).GetBlock(new AssetLocation("game:air"));
					isMissing = true;
				}
				ItemStack stack = new ItemStack(block, 1);
				return new DesignMaterial
				{
					Block = block,
					IsMissing = isMissing,
					Stack = stack
				};
			}).ToList();
		}
		UpdatePreviewView();
	}

	private void UpdatePreviewView()
	{
		GuiElementCWItemStack guiElementCWItemStack = (GuiElementCWItemStack)(object)((GuiDialog)this).SingleComposer.GetElement("preview-itemstack");
		GuiElementTextButton button = Vintagestory.API.Client.GuiComposerHelpers.GetButton(((GuiDialog)this).SingleComposer, "button-copy");
		GuiElementIconButton guiElementIconButton = (GuiElementIconButton)(object)((GuiDialog)this).SingleComposer.GetElement("button-rename");
		GuiElementIconButton guiElementIconButton2 = (GuiElementIconButton)(object)((GuiDialog)this).SingleComposer.GetElement("button-delete");
		if (selectedDesign == null)
		{
			guiElementCWItemStack.SetSourceItemstack(null);
			((GuiElementControl)button).Enabled = false;
			((GuiElementControl)guiElementIconButton).Enabled = false;
			((GuiElementControl)guiElementIconButton2).Enabled = false;
		}
		else
		{
			guiElementCWItemStack.SetSourceItemstack(selectedDesign.Blueprint.ToDummyItemStack(base.capi));
			((GuiElementControl)button).Enabled = true;
			((GuiElementControl)guiElementIconButton).Enabled = activeCatalogue.CanRename;
			((GuiElementControl)guiElementIconButton2).Enabled = activeCatalogue.CanDelete;
		}
		materialList.SetItems(designMaterials);
	}

	private void OnRowClicked(CatalogueRow row)
	{
		bool selected = row.InsetElement.Selected;
		foreach (CatalogueRow displayedRow in designList.DisplayedRows)
		{
			designList.SetRowSelected(displayedRow, selected: false);
		}
		designList.SetRowSelected(row, !selected);
		SetPreview(selected ? null : row.Data);
	}

	private void ComposeSectionMain(GuiComposer composer, ElementBounds bounds)
	{

		CairoFont val = CairoFont.WhiteSmallishText().WithFontSize(18f);
		CairoFont.WhiteSmallishText().WithFontSize(16f).WithColor(ColorUtil.Hex2Doubles("#aaaaaa"));
		CairoFont val2 = CairoFont.WhiteSmallishText().WithFontSize(14f);
		double num = 30.0;
		double num2 = 20.0;
		double num3 = 30.0;
		ElementBounds val3 = bounds.ForkChild().WithFixedSize(bounds.fixedWidth, num);
		ElementBounds val4 = val3.ForkChild().WithFixedWidth(num);
		ElementBounds val5 = val4.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedPadding(0.0).WithFixedWidth(val3.fixedWidth - val4.fixedWidth - num);
		ElementBounds val6 = val5.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth(num);
		ElementBounds val7 = val5.BelowCopy(0.0, 0.0, 0.0, 0.0).WithFixedOffset(2.0, 2.0);
		ElementBounds obj = val3.BelowCopy(0.0, 30.0, 0.0, 0.0).WithFixedHeight(bounds.fixedHeight - val3.fixedHeight - 30.0);
		ElementBounds val8 = obj.ForkChild().WithFixedHeight(num3);
		ElementBounds listBounds = obj.ForkChildOffseted(0.0, num3, 0.0, 0.0 - num3);
		ElementBounds val9 = val8.ForkChildOffseted(0.0, 0.0, 0.0, 0.0);
		AssetLocation[] iconLocations = (AssetLocation[])(object)new AssetLocation[2]
		{
			new AssetLocation("chiselwiz", "textures/icons/sort-up.svg"),
			new AssetLocation("chiselwiz", "textures/icons/sort-down.svg")
		};
		double num4 = 0.0;
		for (int i = 0; i < columns.Length; i++)
		{
			CatalogueColumn column = columns[i];
			val9.fixedWidth = column.Width;
			ElementBounds val10 = val9.ForkChildOffseted(10.0, 5.0, 0.0, 0.0).WithFixedPadding(0.0).WithFixedSize(20.0, 20.0);
			ElementBounds val11 = val9.FlatCopy().WithFixedPadding(30.0, 0.0);
			val11.fixedWidth -= 60.0;
			if (i == columns.Length - 1)
			{
				val11.fixedWidth = val8.fixedWidth - num4 - 60.0 - num2;
			}
			else
			{
				num4 += (double)column.Width;
			}
			if (column.Sortable)
			{
				Vintagestory.API.Client.GuiComposerHelpers.AddButton(composer, Lang.Get(column.Name, Array.Empty<object>()), (ActionConsumable)delegate
				{
					ToggleSort(column);
					return true;
				}, val11.FlatCopy(), val2, (EnumButtonStyle)3, "sortbutton-" + column.Name);
				GuiElementIcon guiElementIcon = new GuiElementIcon(base.capi, iconLocations, val10.FlatCopy(), 5);
				composer.AddInteractiveElement((GuiElement)(object)guiElementIcon, "col-" + column.Name + "-sorticon");
				if (sortColumn == null && column.DefaultActiveColumn)
				{
					sortColumn = column;
				}
			}
			val9 = val9.RightCopy(0.0, 0.0, 0.0, 0.0);
		}
		composer.AddInteractiveElement((GuiElement)(object)new GuiElementIcon(base.capi, new AssetLocation("chiselwiz", "textures/icons/search.svg"), val4.FlatCopy(), 5), (string)null);
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/cross.svg"), null, null, (ActionConsumable)delegate
		{
			ResetFilter();
			return true;
		}, val6.FlatCopy().WithFixedPadding(5.0).WithFixedSize(num - 10.0, num - 10.0), (EnumButtonStyle)3);
		composer.AddInteractiveElement((GuiElement)(object)guiElementIconButton, "clearfilterbutton");
		Vintagestory.API.Client.GuiComposerHelpers.AddTextInput(composer, val5, (Action<string>)delegate(string txt)
		{
			OnFilterValueChange(txt);
		}, val, "searchinput");
		if (filterText != null && filterText != "")
		{
			((GuiElementEditableTextBase)Vintagestory.API.Client.GuiComposerHelpers.GetTextInput(composer, "searchinput")).SetValue(filterText, true);
		}
		GuiElementDynamicTextHelper.AddDynamicText(composer, "", val2, val7, "resultcount");
		designList = new VirtualListScroller<CatalogueDesign, CatalogueRow>(base.capi, composer, listBounds, delegate(float num5)
		{
			lastScrollPos = num5;
		});
		designList.AddCallback("onClick", delegate(IVirtualListRow<CatalogueDesign> row)
		{
			OnRowClicked(row as CatalogueRow);
		});
		designList.Compose();
	}

	private void ComposeSectionSide(GuiComposer composer, ElementBounds bounds)
	{

		CairoFont obj = CairoFont.WhiteSmallishText();
		CairoFont val = CairoFont.WhiteSmallText().WithFontSize(14f);
		CairoFont val2 = obj.Clone().WithOrientation((EnumTextOrientation)2);
		int num = 380;
		ElementBounds listBounds = ElementBounds.Fixed(0.0, 320.0, bounds.fixedWidth, (double)num).WithParent(bounds);
		materialList = new VirtualListScroller<DesignMaterial, CatalogueMaterialRow>(base.capi, composer, listBounds);
		materialList.Compose();
		ElementBounds val3 = ElementBounds.Fixed(0.0, 0.0, bounds.fixedWidth, bounds.fixedWidth).WithParent(bounds);
		GuiElementInsetHelper.AddInset(composer, val3.FlatCopy(), 4, 0.85f);
		GuiElementCWItemStack guiElementCWItemStack = new GuiElementCWItemStack(base.capi, val3.FlatCopy());
		guiElementCWItemStack.Rotate = true;
		BlockBlueprint clipboardBlueprint = chiseller.ClipboardBlueprint;
		if (clipboardBlueprint != null)
		{
			guiElementCWItemStack.SetSourceItemstack(clipboardBlueprint.ToDummyItemStack(base.capi));
		}
		composer.AddInteractiveElement((GuiElement)(object)guiElementCWItemStack, "preview-itemstack");
		ElementBounds val4 = val3.BelowCopy(0.0, 5.0, 0.0, 0.0).WithFixedHeight(40.0);
		ElementBounds val5 = val4.ForkChild().WithFixedWidth(val4.fixedWidth - val4.fixedHeight * 2.0).WithFixedPosition(0.0, 0.0);
		ElementBounds val6 = val5.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedSize(val4.fixedHeight - 10.0, val4.fixedHeight - 10.0).WithFixedPadding(5.0);
		ElementBounds val7 = val6.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedSize(val4.fixedHeight - 10.0, val4.fixedHeight - 10.0).WithFixedPadding(5.0);
		val4.CalcWorldBounds();
		GuiElementInsetHelper.AddInset(composer, val4.FlatCopy(), 4, 0.85f);
		Vintagestory.API.Client.GuiComposerHelpers.AddButton(composer, Lang.Get("chiselwiz:Copy to Clipboard", Array.Empty<object>()), (ActionConsumable)delegate
		{
			chiseller.SetClipboardBlueprint(selectedDesign?.Blueprint.Clone());
			((GuiDialog)this).TryClose();
			return true;
		}, val5, val2, (EnumButtonStyle)3, "button-copy");
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, Lang.Get("chiselwiz:Copy design to clipboard", Array.Empty<object>()), val, 500, val5.FlatCopy(), "hover-copy");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(composer, "hover-copy").SetAutoWidth(true);
		((GuiElementControl)Vintagestory.API.Client.GuiComposerHelpers.GetButton(composer, "button-copy")).Enabled = false;
		GuiElementIconButton guiElementIconButton = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/rename.svg"), null, null, (ActionConsumable)delegate
		{

			CatalogueDesign design = selectedDesign;
			TextAreaConfig val8 = new TextAreaConfig
			{
				FontSize = 18f,
				MaxWidth = 500
			};
			((GuiDialog)new GuiDialogTextInput(Lang.Get("chiselwiz:Rename design", Array.Empty<object>()), design.Name, base.capi, val8)
			{
				OnCloseCancel = delegate
				{
				},
				OnSave = delegate(string text)
				{
					activeCatalogue.RenameDesign(design, text);
					foreach (CatalogueRow displayedRow in designList.DisplayedRows)
					{
						if (displayedRow.Data == design)
						{
							displayedRow.TextNameElement.SetNewText(text, false, false, false);
							break;
						}
					}
					UpdatePreviewView();
					UpdateSearchResults();
				}
			}).TryOpen();
			return true;
		}, val6, (EnumButtonStyle)3);
		((GuiElementControl)guiElementIconButton).Enabled = false;
		composer.AddInteractiveElement((GuiElement)(object)guiElementIconButton, "button-rename");
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, Lang.Get("chiselwiz:Rename design", Array.Empty<object>()), val, 500, val6.FlatCopy(), "hover-rename");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(composer, "hover-rename").SetAutoWidth(true);
		GuiElementIconButton guiElementIconButton2 = new GuiElementIconButton(base.capi, new AssetLocation("chiselwiz", "textures/icons/trash.svg"), null, null, (ActionConsumable)delegate
		{
			if (selectedDesign != null)
			{
				activeCatalogue.DeleteDesign(selectedDesign);
				SetPreview(null);
				UpdateSearchResults();
			}
			return true;
		}, val7, (EnumButtonStyle)3);
		((GuiElementControl)guiElementIconButton2).Enabled = false;
		composer.AddInteractiveElement((GuiElement)(object)guiElementIconButton2, "button-delete");
		Vintagestory.API.Client.GuiComposerHelpers.AddHoverText(composer, Lang.Get("chiselwiz:Delete design", Array.Empty<object>()), val, 500, val7.FlatCopy(), "hover-delete");
		Vintagestory.API.Client.GuiComposerHelpers.GetHoverText(composer, "hover-delete").SetAutoWidth(true);
	}

	private void Compose()
	{
		try
		{
			((GuiDialog)this).ClearComposers();
			double num = 1000.0;
			double num2 = 700.0;
			double num3 = 10.0;
			CairoFont val = CairoFont.WhiteDetailText();
			CairoFont val2 = val.Clone().WithColor(GuiStyle.ActiveButtonTextColor);
			GuiTab[] array = catalogues.CreateGuiTabs();
			for (int i = 0; i < catalogues.Count; i++)
			{
				array[i].Active = catalogues[i] == activeCatalogue;
			}
			ElementBounds val3 = ElementBounds.Fixed((EnumDialogArea)6, 0.0, 0.0, num, 750.0);
			ElementBounds fill = ElementBounds.Fill;
			ElementBounds val4 = ElementBounds.Fixed(0.0, -24.0, num, 25.0).WithParent(val3);
			ElementBounds val5 = val3.ForkContainingChild(0.0, 15.0, 0.0, 35.0).WithFixedPadding(num3).WithAlignment((EnumDialogArea)1)
				.ForkChildOffseted(0.0, 0.0, 0.0, 0.0)
				.WithFixedPadding(0.0)
				.WithFixedWidth(num2);
			ElementBounds val6 = val5.RightCopy(10.0, 0.0, 0.0, 0.0).WithFixedWidth(num - num2 - num3 * 3.0);
			GuiComposer val7 = Vintagestory.API.Client.GuiComposerHelpers.AddDialogTitleBar(Vintagestory.API.Client.GuiComposerHelpers.AddShadedDialogBG(base.capi.Gui.CreateCompo("designcatalogue", val3), fill, true, 5.0, 0.75f), Lang.Get("chiselwiz:Design Catalogue", Array.Empty<object>()), (Action)delegate
			{
				((GuiDialog)this).TryClose();
			}, (CairoFont)null, (ElementBounds)null, (string)null);
			Vintagestory.API.Client.GuiComposerHelpers.AddHorizontalTabs(val7, array, val4, (Action<int>)delegate(int idx)
			{
				ICatalogue catalogue = catalogues[idx];
				if (catalogue != activeCatalogue)
				{
					activeCatalogue = catalogue;
					SetPreview(null);
					UpdateSearchResults();
				}
			}, val, val2, "cataloguetabs");
			Vintagestory.API.Client.GuiComposerHelpers.GetHorizontalTabs(val7, "cataloguetabs").activeElement = catalogues.IndexOf(activeCatalogue);
			val7.BeginChildElements();
			ComposeSectionMain(val7, val5);
			val6.CalcWorldBounds();
			ComposeSectionSide(val7, val6);
			((GuiDialog)this).SingleComposer = val7.EndChildElements().Compose(true);
			UpdateSortControlIcons();
			GuiElementTextInput textInput = Vintagestory.API.Client.GuiComposerHelpers.GetTextInput(((GuiDialog)this).SingleComposer, "searchinput");
			if (textInput != null)
			{
				((GuiDialog)this).SingleComposer.FocusElement(((GuiElement)textInput).TabIndex);
			}
			SetPreview(selectedDesign);
			UpdatePreviewView();
		}
		catch (Exception ex)
		{
			((ICoreAPI)base.capi).Logger.Error(ex);
		}
	}
}




