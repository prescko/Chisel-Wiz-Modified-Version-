﻿using System;
using System.Collections.Generic;
using System.Linq;
using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Elements;

public class VirtualListScroller<TData, TRow> where TRow : class, IVirtualListRow<TData>, new()
{
	private ICoreClientAPI capi;

	private GuiComposer composer;

	private List<TData> allItems;

	private Func<TRow> rowFactory;

	private GuiElementCWScrollbar scrollbar;

	private ElementBounds listBounds;

	private ElementBounds contentBounds;

	private ElementBounds clipBounds;

	private Action<float> onScroll;

	private TData selectedData;

	private Dictionary<string, Action<IVirtualListRow<TData>>> callbacks;

	private Stack<TRow> rowPool;

	public HashSet<TRow> DisplayedRows { get; private set; }

	public VirtualListScroller(ICoreClientAPI capi, GuiComposer composer, ElementBounds listBounds, Action<float> onScroll = null)
	{
		this.capi = capi;
		this.composer = composer;
		this.listBounds = listBounds;
		rowFactory = () => new TRow();
		this.onScroll = onScroll;
		rowPool = new Stack<TRow>();
		DisplayedRows = new HashSet<TRow>();
		callbacks = new Dictionary<string, Action<IVirtualListRow<TData>>>();
	}

	public void AddCallback(string key, Action<IVirtualListRow<TData>> callback)
	{
		callbacks[key] = callback;
	}

	public void Compose()
	{
		double num = 20.0;
		ElementBounds val = listBounds.CopyOffsetedSibling(0.0, 0.0, 0.0 - num, 0.0);
		ElementBounds bounds = val.RightCopy(0.0, 0.0, 0.0, 0.0).WithFixedWidth(num);
		scrollbar = new GuiElementCWScrollbar(capi, OnScroll, bounds, listBounds);
		composer.AddInteractiveElement((GuiElement)(object)scrollbar, (string)null);
		GuiElementInsetHelper.AddInset(composer, val.FlatCopy(), 4, 0.85f);
		clipBounds = val.FlatCopy();
		GuiElementClipHelpler.BeginClip(composer, clipBounds);
		contentBounds = clipBounds.ForkContainingChild(0.0, 0.0, 0.0, 0.0);
		ClearPool();
		if (rowPool.Count == 0)
		{
			TRow val2 = rowFactory();
			int num2 = (int)(contentBounds.fixedHeight / (double)val2.RowHeight) + 2;
			val2.Dispose();
			for (int i = 0; i < num2; i++)
			{
				TRow val3 = rowFactory();
				val3.Bounds = contentBounds.ForkChild().WithFixedPadding(0.0).WithFixedHeight((double)val2.RowHeight);
				val3.CreateComponents(composer, callbacks);
				rowPool.Push(val3);
			}
		}
		GuiElementClipHelpler.EndClip(composer);
	}

	public void SetDataSelected(TData data)
	{
		selectedData = data;
	}

	public void SetRowSelected(TRow row, bool selected)
	{
		selectedData = (selected ? row.Data : default(TData));
		row.SetSelected(selected);
	}

	public void SetItems(List<TData> items)
	{
		allItems = items;
		UpdateView(updateScrollbar: true);
	}

	private void OnScroll(float value)
	{
		contentBounds.fixedY = 0f - value;
		UpdateView(updateScrollbar: false);
		onScroll?.Invoke(value);
	}

	public void UpdateView(bool updateScrollbar, float restoreScrollPos = -1f)
	{
		if (allItems == null)
		{
			foreach (TRow item in rowPool)
			{
				item.Bounds.fixedY = -item.RowHeight;
				item.Bounds.CalcWorldBounds();
			}
			foreach (TRow displayedRow in DisplayedRows)
			{
				displayedRow.Hide();
				rowPool.Push(displayedRow);
			}
			DisplayedRows.Clear();
			if (updateScrollbar)
			{
				GuiElementCWScrollbar guiElementCWScrollbar = scrollbar;
				if (guiElementCWScrollbar != null)
				{
					((GuiElementScrollbar)guiElementCWScrollbar).SetHeights(1f, 1f);
				}
			}
			return;
		}
		TRow val = (rowPool.Any() ? rowPool.Peek() : (DisplayedRows.Any() ? DisplayedRows.First() : null));
		if (val == null)
		{
			return;
		}
		if (updateScrollbar)
		{
			((GuiElementScrollbar)scrollbar).SetHeights((float)clipBounds.fixedHeight, (float)(allItems.Count * val.RowHeight));
			if (restoreScrollPos >= 0f)
			{
				((GuiElementScrollbar)scrollbar).CurrentYPosition = restoreScrollPos;
				contentBounds.fixedY = 0f - restoreScrollPos;
				contentBounds.CalcWorldBounds();
			}
		}
		double num = 0.0 - contentBounds.fixedY;
		double num2 = num + contentBounds.fixedHeight;
		int num3 = Math.Clamp((int)(num / (double)val.RowHeight), 0, Math.Max(allItems.Count - 1, 0));
		int count = Math.Clamp(Math.Min(allItems.Count, (int)(num2 / (double)val.RowHeight) + 1) - num3, 0, Math.Max(allItems.Count - num3, 0));
		List<TData> range = allItems.GetRange(num3, count);
		HashSet<TData> hashSet = new HashSet<TData>(range);
		HashSet<TRow> hashSet2 = new HashSet<TRow>();
		foreach (TRow displayedRow2 in DisplayedRows)
		{
			if (displayedRow2.Data == null || !hashSet.Contains(displayedRow2.Data))
			{
				hashSet2.Add(displayedRow2);
			}
		}
		foreach (TRow item2 in hashSet2)
		{
			DisplayedRows.Remove(item2);
			item2.Hide();
			rowPool.Push(item2);
		}
		HashSet<TData> displayedItems = new HashSet<TData>(DisplayedRows.Select((TRow row) => row.Data));
		foreach (TData item3 in range.Where((TData item) => !displayedItems.Contains(item)).ToList())
		{
			if (rowPool.Count == 0)
			{
				break;
			}
			TRow val2 = rowPool.Pop();
			val2.SetData(item3);
			DisplayedRows.Add(val2);
			if (object.Equals(selectedData, val2.Data))
			{
				SetRowSelected(val2, selected: true);
			}
		}
		contentBounds.CalcWorldBounds();
		Dictionary<TData, int> dictionary = new Dictionary<TData, int>();
		for (int num4 = 0; num4 < allItems.Count; num4++)
		{
			dictionary[allItems[num4]] = num4;
		}
		foreach (TRow item4 in rowPool)
		{
			item4.Bounds.fixedY = -item4.RowHeight;
			item4.Bounds.CalcWorldBounds();
		}
		foreach (TRow displayedRow3 in DisplayedRows)
		{
			if (dictionary.TryGetValue(displayedRow3.Data, out var value))
			{
				displayedRow3.Bounds.fixedY = value * displayedRow3.RowHeight;
				displayedRow3.Bounds.CalcWorldBounds();
			}
		}
	}

	public void ClearPool()
	{
		while (rowPool.Count > 0)
		{
			rowPool.Pop().Dispose();
		}
		foreach (TRow displayedRow in DisplayedRows)
		{
			displayedRow.Dispose();
		}
		DisplayedRows.Clear();
	}
}




