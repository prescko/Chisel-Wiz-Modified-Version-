﻿using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

public class GuiElementCWSlider : GuiElementSlider
{
	private LoadedTexture backgroundInsetTexture;

	public GuiElementCWSlider(ICoreClientAPI capi, ActionConsumable<int> onNewSliderValue, ElementBounds bounds)
		: base(capi, onNewSliderValue, bounds)
	{

		backgroundInsetTexture = new LoadedTexture(capi);
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surfaceStatic)
	{

		ImageSurface val = new ImageSurface((Format)0, (int)((GuiElement)this).Bounds.InnerWidth, (int)((GuiElement)this).Bounds.InnerHeight);
		Context val2 = genContext(val);
		base.ComposeElements(val2, val);
		ContextUtils.Clear(val2);
		val2.SetSourceRGBA(0.0, 0.0, 0.0, 0.2);
		GuiElement.RoundRectangle(val2, 0.0, 0.0, ((GuiElement)this).Bounds.InnerWidth, ((GuiElement)this).Bounds.InnerHeight, 1.0);
		val2.Fill();
		((GuiElement)this).EmbossRoundRectangleElement(val2, ((GuiElement)this).Bounds, true, 1, 1);
		generateTexture(val, ref backgroundInsetTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		api.Render.Render2DTexturePremultipliedAlpha(backgroundInsetTexture.TextureId, ((GuiElement)this).Bounds, 50f, (Vec4f)null);
		base.RenderInteractiveElements(deltaTime);
	}

	public override void Dispose()
	{
		LoadedTexture obj = backgroundInsetTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
		base.Dispose();
	}
}




