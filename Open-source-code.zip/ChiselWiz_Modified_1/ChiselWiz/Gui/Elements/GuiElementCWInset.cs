﻿using System;
using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

public class GuiElementCWInset : GuiElement
{
	private Action onClick;

	private Action onMouseMove;

	private Action onMouseOut;

	private bool isOver;

	public bool Selected;

	public bool ThrobWhenSelected;

	private Vec4f throbColour = ColorUtil.WhiteArgbVec.Clone();

	private LoadedTexture normalTexture;

	private LoadedTexture hoverTexture;

	private LoadedTexture highlightTexture;

	public CWInsetDrawParams DrawParams;

	public GuiElementCWInset(ICoreClientAPI capi, ElementBounds bounds, Action onClick = null, Action onMouseMove = null, Action onMouseOut = null)
		: base(capi, bounds)
	{

		this.onClick = onClick;
		this.onMouseMove = onMouseMove;
		this.onMouseOut = onMouseOut;
		DrawParams = new CWInsetDrawParams();
		hoverTexture = new LoadedTexture(capi);
		normalTexture = new LoadedTexture(capi);
		highlightTexture = new LoadedTexture(capi);
	}

	public void Unhighlight()
	{
		isOver = false;
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surfaceStatic)
	{

		base.Bounds.CalcWorldBounds();
		ImageSurface val = new ImageSurface((Format)0, (int)base.Bounds.OuterWidth, (int)base.Bounds.OuterHeight);
		Context val2 = genContext(val);
		val2.SetSourceRGBA(DrawParams.BorderColorRGBA);
		GuiElement.Rectangle(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt);
		val2.Fill();
		((GuiElement)this).EmbossRoundRectangleElement(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt, true, DrawParams.BorderThickness, -1);
		generateTexture(val, ref normalTexture, true);
		ContextUtils.Clear(val2);
		val2.SetSourceRGBA(0.8, 0.8, 0.8, 0.05);
		GuiElement.Rectangle(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt);
		val2.Fill();
		((GuiElement)this).EmbossRoundRectangleElement(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt, true, DrawParams.BorderThickness * 2, -1);
		generateTexture(val, ref hoverTexture, true);
		ContextUtils.Clear(val2);
		val2.SetSourceRGBA(DrawParams.HighlightColorRGBA);
		GuiElement.Rectangle(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt);
		val2.Fill();
		val2.SetSourceRGBA(1.0, 1.0, 1.0, 0.2);
		GuiElement.Rectangle(val2, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt);
		val2.LineWidth = GuiElement.scaled((double)(DrawParams.BorderThickness * 2));
		val2.StrokePreserve();
		SurfaceTransformBlur.BlurFull(val, GuiElement.scaled((double)DrawParams.BorderThickness));
		generateTexture(val, ref highlightTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (Selected)
		{
			throbColour.A = 1f;
			if (ThrobWhenSelected)
			{
				throbColour.A = (float)((Math.Sin((double)((IWorldAccessor)base.api.World).ElapsedMilliseconds / 150.0) + 1.0) / 2.0);
			}
			base.api.Render.Render2DTexturePremultipliedAlpha(highlightTexture.TextureId, base.Bounds, 50f, throbColour);
		}
		if (isOver)
		{
			base.api.Render.Render2DTexturePremultipliedAlpha(hoverTexture.TextureId, base.Bounds, 50f, (Vec4f)null);
		}
		else
		{
			base.api.Render.Render2DTexturePremultipliedAlpha(normalTexture.TextureId, base.Bounds, 50f, (Vec4f)null);
		}
	}

	public override void OnMouseDownOnElement(ICoreClientAPI capi, MouseEvent args)
	{
		base.OnMouseDownOnElement(capi, args);
		if (onClick != null)
		{
			onClick();
		}
	}

	public void OnMouseMoveOnElement(ICoreClientAPI capi, MouseEvent args)
	{
		if (onMouseMove != null)
		{
			onMouseMove();
		}
	}

	public void OnMouseOutElement(ICoreClientAPI capi, MouseEvent args)
	{
		if (onMouseOut != null)
		{
			onMouseOut();
		}
	}

	public override void OnMouseMove(ICoreClientAPI capi, MouseEvent args)
	{
		bool flag = isOver;
		isOver = false;
		if (((GuiElement)this).IsPositionInside(args.X, args.Y))
		{
			isOver = true;
			OnMouseMoveOnElement(capi, args);
		}
		else if (flag && !isOver)
		{
			OnMouseOutElement(capi, args);
		}
	}

	public override void Dispose()
	{
		base.Dispose();
		LoadedTexture obj = hoverTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
		LoadedTexture obj2 = normalTexture;
		if (obj2 != null)
		{
			obj2.Dispose();
		}
		LoadedTexture obj3 = highlightTexture;
		if (obj3 != null)
		{
			obj3.Dispose();
		}
	}
}




