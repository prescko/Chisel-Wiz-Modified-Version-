﻿using System;
using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

public class GuiElementProgressBar : GuiElement
{
	private LoadedTexture barTexture;

	private LoadedTexture bgTexture;

	private ElementBounds barBounds;

	private ElementBounds insetBounds;

	private GuiElementCWInset insetElement;

	private GuiElementDynamicText textElement;

	public double Total { get; set; }

	public double Progress { get; set; }

	public bool Visible { get; set; }

	public GuiElementProgressBar(ICoreClientAPI capi, ElementBounds bounds, string text, int textYOffset = 0)
		: base(capi, bounds)
	{

		barTexture = new LoadedTexture(capi);
		bgTexture = new LoadedTexture(capi);
		int num = 5;
		int num2 = 3;
		CairoFont val = CairoFont.WhiteSmallishText().WithOrientation((EnumTextOrientation)2);
		insetBounds = bounds.CopyOffsetedSibling((double)num, (double)num, (double)(-num * 2), (double)(-num * 2));
		barBounds = insetBounds.CopyOffsetedSibling((double)num2, (double)num2, (double)(-num2 * 2), (double)(-num2 * 2));
		insetElement = new GuiElementCWInset(capi, insetBounds);
		textElement = new GuiElementDynamicText(capi, text, val, insetBounds.CopyOffsetedSibling(0.0, (double)textYOffset, 0.0, 0.0));
		Visible = true;
		Total = 1.0;
		Progress = 0.0;
	}

	public void SetText(string text, bool useAsync = false)
	{
		textElement.SetNewText(text, false, false, useAsync);
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surfaceStatic)
	{
		ComposeBackground(base.Bounds);
		ComposeBar(barBounds);
		((GuiElement)insetElement).ComposeElements(ctxStatic, surfaceStatic);
		((GuiElement)textElement).ComposeElements(ctxStatic, surfaceStatic);
	}

	private void ComposeBar(ElementBounds bounds)
	{

		bounds.CalcWorldBounds();
		ImageSurface val = new ImageSurface((Format)0, bounds.OuterWidthInt, bounds.OuterHeightInt);
		Context val2 = genContext(val);
		GuiElement.Rectangle(val2, 0.0, 0.0, (double)bounds.OuterWidthInt, (double)bounds.OuterHeightInt);
		GuiElement.fillWithPattern(base.api, val2, GuiElement.stoneTextureName, false, false, 255, 1f);
		generateTexture(val, ref barTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
	}

	private void ComposeBackground(ElementBounds bounds)
	{

		bounds.CalcWorldBounds();
		ImageSurface val = new ImageSurface((Format)0, bounds.OuterWidthInt, bounds.OuterHeightInt);
		Context val2 = genContext(val);
		double num = 5.0;
		float num2 = 1f;
		GuiElement.RoundRectangle(val2, 0.0, 0.0, bounds.OuterWidth, bounds.OuterHeight - 1.0, GuiStyle.DialogBGRadius);
		val2.SetSourceRGBA(GuiStyle.DialogStrongBgColor[0] * 1.0, GuiStyle.DialogStrongBgColor[1] * 1.0, GuiStyle.DialogStrongBgColor[2] * 1.0, GuiStyle.DialogStrongBgColor[3] * 1.0);
		val2.FillPreserve();
		val2.SetSourceRGBA(GuiStyle.DialogLightBgColor[0] * 2.1, GuiStyle.DialogStrongBgColor[1] * 2.1, GuiStyle.DialogStrongBgColor[2] * 2.1, 1.0);
		val2.LineWidth = num * 2.0;
		val2.StrokePreserve();
		double num3 = GuiElement.scaled(9.0);
		SurfaceTransformBlur.BlurPartial(val, num3, (int)(2.0 * num3 + 1.0), 0, 0, bounds.OuterWidthInt, bounds.OuterHeightInt);
		SurfacePattern pattern = GuiElement.getPattern(base.api, GuiElement.dirtTextureName, true, 64, 0.125f);
		val2.SetSource((Pattern)(object)pattern);
		val2.FillPreserve();
		val2.Operator = (Operator)2;
		double[] obj = new double[4]
		{
			0.17647058823529413,
			7.0 / 51.0,
			11.0 / 85.0,
			0.0
		};
		obj[3] = num2 * num2;
		val2.SetSourceRGBA(obj);
		val2.LineWidth = num;
		val2.Stroke();
		generateTexture(val, ref bgTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (Visible)
		{
			base.api.Render.Render2DTexturePremultipliedAlpha(bgTexture.TextureId, base.Bounds, 50f, (Vec4f)null);
			((GuiElement)insetElement).RenderInteractiveElements(deltaTime);
			double num = 0.0;
			if (Total > 0.0)
			{
				num = Math.Clamp(Progress / Total, 0.0, 1.0);
			}
			ElementBounds val = barBounds.FlatCopy().WithFixedWidth(barBounds.fixedWidth * num);
			val.CalcWorldBounds();
			base.api.Render.PushScissor(val, false);
			base.api.Render.Render2DTexturePremultipliedAlpha(barTexture.TextureId, barBounds, 50f, (Vec4f)null);
			base.api.Render.PopScissor();
			((GuiElement)textElement).RenderInteractiveElements(deltaTime);
		}
	}

	public override void Dispose()
	{
		GuiElementDynamicText obj = textElement;
		if (obj != null)
		{
			((GuiElement)obj).Dispose();
		}
		GuiElementCWInset guiElementCWInset = insetElement;
		if (guiElementCWInset != null)
		{
			((GuiElement)guiElementCWInset).Dispose();
		}
		LoadedTexture obj2 = barTexture;
		if (obj2 != null)
		{
			obj2.Dispose();
		}
		LoadedTexture obj3 = bgTexture;
		if (obj3 != null)
		{
			obj3.Dispose();
		}
		base.Dispose();
	}
}




