﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.Client.NoObf;

namespace ChiselWiz.Gui.Elements;

internal class CWBlockRenderer : IRenderer, IDisposable
{
	private ClientMain game;

	private Matrixf modelMat = new Matrixf();

	public EnumBlockRenderMode RenderMode { get; set; }

	public double RenderOrder => 9.0;

	public int RenderRange => 24;

	public CWBlockRenderer(ClientMain game)
	{

		this.game = game;
	}

	public void OnRenderFrame(float deltaTime, EnumRenderStage stage)
	{
	}

	public void RenderItemstackToGui(ItemSlot inSlot, double posX, double posY, double posZ, float size, int color, bool shading = true, bool origRotate = false)
	{
		RenderItemstackToGui(inSlot, posX, posY, posZ, size, color, 0f, shading, origRotate);
	}

	public void RenderItemstackToGui(ItemSlot inSlot, double posX, double posY, double posZ, float size, int color, float dt, bool shading = true, bool origRotate = false)
	{

		ItemStack itemstack = inSlot.Itemstack;
		ItemRenderInfo itemStackRenderInfo = GetItemStackRenderInfo(game, inSlot, (EnumItemRenderTarget)0, dt);
		if (itemStackRenderInfo.ModelRef == null)
		{
			return;
		}
		itemstack.Collectible.InGuiIdle((IWorldAccessor)(object)game, itemstack);
		ModelTransform transform = itemStackRenderInfo.Transform;
		if (transform != null)
		{
			transform = transform.Clone();
			bool flag = (int)itemstack.Class == 0;
			bool flag2 = origRotate && ((ModelTransformNoDefaults)itemStackRenderInfo.Transform).Rotate;
			modelMat.Identity();
			modelMat.Translate(posX, posY, posZ);
			modelMat.Translate((double)((ModelTransformNoDefaults)transform).Origin.X + GuiElement.scaled((double)((ModelTransformNoDefaults)transform).Translation.X), (double)((ModelTransformNoDefaults)transform).Origin.Y + GuiElement.scaled((double)((ModelTransformNoDefaults)transform).Translation.Y), (double)(((ModelTransformNoDefaults)transform).Origin.Z * size) + GuiElement.scaled((double)((ModelTransformNoDefaults)transform).Translation.Z));
			if (RenderMode == EnumBlockRenderMode.FaceForward)
			{
				size *= 1.6f;
				modelMat.Translate(0f, -1f, 0f);
				modelMat.Scale(size * (0f - ((ModelTransformNoDefaults)transform).ScaleXYZ.X), size * ((ModelTransformNoDefaults)transform).ScaleXYZ.Y, size * ((ModelTransformNoDefaults)transform).ScaleXYZ.Z);
				modelMat.RotateXDeg(((ModelTransformNoDefaults)transform).Rotation.X + (flag ? 180f : 0f) + 45f - 22f);
				modelMat.RotateYDeg(((ModelTransformNoDefaults)transform).Rotation.Y + 180f + 45f);
			}
			else
			{
				modelMat.Scale(size * (0f - ((ModelTransformNoDefaults)transform).ScaleXYZ.X), size * ((ModelTransformNoDefaults)transform).ScaleXYZ.Y, size * ((ModelTransformNoDefaults)transform).ScaleXYZ.Z);
				modelMat.RotateXDeg(((ModelTransformNoDefaults)transform).Rotation.X + (flag ? 180f : 0f));
				float num = 3000f;
				float num2 = (float)game.Platform.EllapsedMs % num / num * 360f;
				modelMat.RotateYDeg(((ModelTransformNoDefaults)transform).Rotation.Y - ((!flag) ? 1f : (-1f)) * (flag2 ? num2 : 0f));
				modelMat.RotateZDeg(((ModelTransformNoDefaults)transform).Rotation.Z);
			}
			modelMat.Translate(0f - ((ModelTransformNoDefaults)transform).Origin.X, 0f - ((ModelTransformNoDefaults)transform).Origin.Y, 0f - ((ModelTransformNoDefaults)transform).Origin.Z);
			int num3 = (int)itemstack.Collectible.GetTemperature((IWorldAccessor)(object)game, itemstack);
			ColorUtil.GetIncandescenceColorAsColor4f(num3);
			float[] array = ColorUtil.ToRGBAFloats(color);
			GameMath.Clamp((num3 - 550) / 2, 0, 255);
			itemstack.Attributes.HasAttribute("temperature");
			game.guiShaderProg.NormalShaded = (itemStackRenderInfo.NormalShaded ? 1 : 0);
			game.guiShaderProg.RgbaIn = new Vec4f(array[0], array[1], array[2], array[3]);
			game.guiShaderProg.ApplyColor = (itemStackRenderInfo.ApplyColor ? 1 : 0);
			game.guiShaderProg.AlphaTest = itemStackRenderInfo.AlphaTest;
			game.guiShaderProg.ModelMatrix = modelMat.Values;
			game.guiShaderProg.ProjectionMatrix = game.CurrentProjectionMatrix;
			game.guiShaderProg.ModelViewMatrix = modelMat.ReverseMul(game.CurrentModelViewMatrix).Values;
			game.guiShaderProg.ApplyModelMat = 1;
			game.guiShaderProg.DamageEffect = itemStackRenderInfo.DamageEffect;
			game.api.Render.RenderMultiTextureMesh(itemStackRenderInfo.ModelRef, "tex2d", 0);
			game.guiShaderProg.ApplyModelMat = 0;
			game.guiShaderProg.NormalShaded = 0;
			game.guiShaderProg.TempGlowMode = 0;
			game.guiShaderProg.DamageEffect = 0f;
			game.guiShaderProg.AlphaTest = 0f;
			game.guiShaderProg.RgbaGlowIn = new Vec4f(0f, 0f, 0f, 0f);
		}
	}

	public static ItemRenderInfo GetItemStackRenderInfo(ClientMain game, ItemSlot inSlot, EnumItemRenderTarget target, float dt)
	{

		ItemStack itemstack = inSlot.Itemstack;
		if (itemstack == null || ((RegistryObject)itemstack.Collectible).Code == (AssetLocation)null)
		{
			return new ItemRenderInfo();
		}
		ItemRenderInfo val = new ItemRenderInfo();
		val.dt = dt;
		val.Transform = itemstack.Collectible.GuiTransform;
		val.ModelRef = game.TesselatorManager.blockModelRefsInventory[itemstack.Id];
		ItemRenderInfo obj = val;
		CompositeShape shape = itemstack.Block.Shape;
		int num = ((shape != null && !shape.VoxelizeTexture) ? 1 : 0);
		obj.NormalShaded = (byte)num != 0;
		val.TextureSize.Width = (((int)itemstack.Class == 0) ? game.BlockAtlasManager.Size.Width : game.ItemAtlasManager.Size.Width);
		val.TextureSize.Height = (((int)itemstack.Class == 0) ? game.BlockAtlasManager.Size.Height : game.ItemAtlasManager.Size.Height);
		val.HalfTransparent = false;
		val.AlphaTest = itemstack.Collectible.RenderAlphaTest;
		val.CullFaces = false;
		val.ApplyColor = val.NormalShaded;
		val.InSlot = inSlot;
		inSlot.OnBeforeRender(val);
		((CollectibleObject)itemstack.Block).OnBeforeRender((ICoreClientAPI)(object)game.api, itemstack, target, ref val);
		return val;
	}

	public void Dispose()
	{
	}
}




