﻿using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.Client;

namespace ChiselWiz.Gui.Elements;

public class GuiElementCWImage : GuiElement
{
	private LoadedTexture loadedTexture;

	private ElementBounds innerBounds;

	public bool HasBitmap => loadedTexture != null;

	public GuiElementCWImage(ICoreClientAPI capi, ElementBounds bounds)
		: base(capi, bounds)
	{
	}

	public void SetBitmap(SKBitmap bmp)
	{

		LoadedTexture obj = loadedTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
		if (bmp == null)
		{
			loadedTexture = null;
			return;
		}
		BitmapExternal bmp2 = new BitmapExternal(bmp);
		loadedTexture = new LoadedTexture(base.api, ScreenManager.Platform.LoadTexture((IBitmap)(object)bmp2), bmp.Width, bmp.Height);
		innerBounds = GetScaledBounds(base.Bounds, loadedTexture);
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (loadedTexture != null)
		{
			innerBounds.CalcWorldBounds();
			base.api.Render.Render2DTexturePremultipliedAlpha(loadedTexture.TextureId, innerBounds, 50f, (Vec4f)null);
		}
	}

	public override void OnMouseDownOnElement(ICoreClientAPI capi, MouseEvent args)
	{
	}

	public ElementBounds[,] GenerateGridBounds(int cellSize, ElementBounds parentBounds = null)
	{
		if (loadedTexture == null)
		{
			return null;
		}
		cellSize *= 2;
		int num = (loadedTexture.Width + cellSize - 1) / cellSize;
		int num2 = (loadedTexture.Height + cellSize - 1) / cellSize;
		ElementBounds[,] array = new ElementBounds[num, num2];
		double num3 = innerBounds.fixedWidth / (double)num;
		double num4 = innerBounds.fixedHeight / (double)num2;
		for (int i = 0; i < num; i++)
		{
			for (int j = 0; j < num2; j++)
			{
				ElementBounds val = ElementBounds.Fixed(innerBounds.fixedX + (double)i * num3, innerBounds.fixedY + (double)j * num4, num3, num4);
				if (parentBounds != null)
				{
					val.WithParent(parentBounds);
				}
				array[i, j] = val;
			}
		}
		return array;
	}

	public override void Dispose()
	{
		base.Dispose();
		LoadedTexture obj = loadedTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
	}

	private ElementBounds GetScaledBounds(ElementBounds originalBounds, LoadedTexture texture)
	{
		ElementBounds val = originalBounds.FlatCopy();
		double num = (double)texture.Width / (double)texture.Height;
		double num2 = val.fixedWidth / val.fixedHeight;
		if (num > num2)
		{
			val.fixedHeight = val.fixedWidth / num;
			val.fixedY = originalBounds.fixedY + (originalBounds.fixedHeight - val.fixedHeight) / 2.0;
		}
		else
		{
			val.fixedWidth = val.fixedHeight * num;
			val.fixedX = originalBounds.fixedX + (originalBounds.fixedWidth - val.fixedWidth) / 2.0;
		}
		return val;
	}
}




