﻿namespace ChiselWiz.Gui.Elements;

public class CWInsetDrawParams
{
	public int BorderThickness = 4;

	public double[] BorderColorRGBA = new double[4] { 0.0, 0.0, 0.0, 0.15 };

	public double[] HighlightColorRGBA = new double[4] { 0.1, 0.1, 1.0, 0.2 };
}




