﻿using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.Client.NoObf;

namespace ChiselWiz.Gui.Elements;

public class GuiElementCWItemStack : GuiElement
{
	public static int ItemStackSize = (int)GuiElementPassiveItemSlot.unscaledItemSize;

	public int zPos = 50;

	public DummySlot curSlot;

	public bool Shading = true;

	public bool Rotate;

	public bool ShowStackSize;

	private LoadedTexture slotTexture;

	private CWBlockRenderer blockRenderer;

	public bool RenderBackground { get; set; } = true;

	public EnumBlockRenderMode RenderMode
	{
		get
		{
			return blockRenderer.RenderMode;
		}
		set
		{
			blockRenderer.RenderMode = value;
		}
	}

	public GuiElementCWItemStack(ICoreClientAPI capi, ElementBounds bounds)
		: base(capi, bounds)
	{

		slotTexture = new LoadedTexture(capi);
		blockRenderer = new CWBlockRenderer((ClientMain)(object)capi.World);
	}

	public override void ComposeElements(Context unusedCtx, ImageSurface unusedSurface)
	{

		double fixedWidth = base.Bounds.fixedWidth;
		ImageSurface val = new ImageSurface((Format)0, (int)fixedWidth, (int)fixedWidth);
		Context obj = genContext(val);
		obj.SetSourceRGBA(GuiStyle.DialogSlotBackColor);
		GuiElement.RoundRectangle(obj, 0.0, 0.0, fixedWidth, fixedWidth, GuiStyle.ElementBGRadius);
		obj.Fill();
		obj.SetSourceRGBA(GuiStyle.DialogSlotFrontColor);
		GuiElement.RoundRectangle(obj, 0.0, 0.0, fixedWidth, fixedWidth, GuiStyle.ElementBGRadius);
		obj.LineWidth = GuiElement.scaled(4.5);
		obj.Stroke();
		SurfaceTransformBlur.BlurFull(val, GuiElement.scaled(4.0));
		SurfaceTransformBlur.BlurFull(val, GuiElement.scaled(4.0));
		GuiElement.RoundRectangle(obj, 0.0, 0.0, fixedWidth, fixedWidth, 1.0);
		obj.LineWidth = GuiElement.scaled(4.5);
		obj.SetSourceRGBA(0.0, 0.0, 0.0, 0.8);
		obj.Stroke();
		generateTexture(val, ref slotTexture, true);
		obj.Dispose();
		((Surface)val).Dispose();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		double fixedWidth = base.Bounds.fixedWidth;
		double num = GuiElement.scaled(fixedWidth) / 2.0;
		base.api.Render.PushScissor(base.Bounds, true);
		if (curSlot != null)
		{
			blockRenderer.RenderItemstackToGui((ItemSlot)(object)curSlot, base.Bounds.renderX + num, base.Bounds.renderY + num, zPos + 25, (float)GuiElement.scaled(fixedWidth * 0.55), -1, Shading, Rotate);
		}
		if (RenderBackground)
		{
			base.api.Render.Render2DTexture(slotTexture.TextureId, base.Bounds, 50f, (Vec4f)null);
		}
		base.api.Render.PopScissor();
	}

	public void SetSourceItemstack(ItemStack stack)
	{

		if (stack == null)
		{
			curSlot = null;
		}
		else
		{
			curSlot = new DummySlot(stack.Clone());
		}
	}

	public override void Dispose()
	{
		base.Dispose();
		LoadedTexture obj = slotTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
	}
}




