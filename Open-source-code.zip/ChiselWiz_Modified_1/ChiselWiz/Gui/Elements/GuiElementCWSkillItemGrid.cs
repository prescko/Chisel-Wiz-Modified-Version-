﻿using System;
using System.Collections.Generic;
using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

internal class GuiElementCWSkillItemGrid : GuiElementSkillItemGrid
{
	private ICoreClientAPI capi;

	private static LoadedTexture highlightSlotTexture;

	private static LoadedTexture[] textTextures;

	public int MaxNum = 1;

	public int CurrentNum = 1;

	public bool Highlighted;

	public Action<int> OnNumChange;

	public GuiElementCWSkillItemGrid(ICoreClientAPI capi, SkillItem skillItem, ElementBounds bounds)
		: base(capi, new List<SkillItem> { skillItem }, 1, 1, (Action<int>)null, bounds)
	{
		this.capi = capi;
	}

	public override void OnMouseWheel(ICoreClientAPI capi, MouseWheelEventArgs args)
	{
		if (!((GuiElement)this).Bounds.PointInside(capi.Input.MouseX, capi.Input.MouseY))
		{
			return;
		}
		int currentNum = CurrentNum;
		int num = Math.Sign(args.deltaPrecise);
		if (num > 0)
		{
			CurrentNum++;
			if (CurrentNum > MaxNum)
			{
				CurrentNum = MaxNum;
			}
		}
		else if (num < 0)
		{
			CurrentNum--;
			if (CurrentNum < 1)
			{
				CurrentNum = 1;
			}
		}
		if (currentNum != CurrentNum)
		{
			OnNumChange?.Invoke(CurrentNum);
		}
		args.SetHandled(true);
	}

	public override void ComposeElements(Context slotCtx, ImageSurface slotSurface)
	{

		if (textTextures == null)
		{
			CairoFont val = CairoFont.WhiteSmallText().WithWeight((FontWeight)1).WithFontSize(12f)
				.WithStroke(ColorUtil.BlackArgbDouble, GuiElement.scaled(3.0));
			double num = ((GuiElement)this).Bounds.absInnerWidth / (double)(float)GuiElement.scaled(25.6);
			((FontConfig)val).UnscaledFontsize = ((FontConfig)val).UnscaledFontsize * num;
			List<LoadedTexture> list = new List<LoadedTexture>();
			for (int i = 0; i <= 15; i++)
			{
				list.Add(capi.Gui.TextTexture.GenTextTexture($"{i}", val, (TextBackground)null));
			}
			textTextures = list.ToArray();
		}
		if (highlightSlotTexture == null)
		{
			double num2 = GuiElement.scaled(((GuiElement)this).Bounds.absInnerWidth);
			double num3 = GuiElement.scaled(((GuiElement)this).Bounds.absInnerHeight);
			highlightSlotTexture = new LoadedTexture(capi);
			ImageSurface val2 = new ImageSurface((Format)0, (int)num2 + 4, (int)num2 + 4);
			Context obj = genContext(val2);
			obj.SetSourceRGBA(GuiStyle.ActiveSlotColor);
			GuiElement.RoundRectangle(obj, 0.0, 0.0, num2 + 4.0, num3 + 4.0, GuiStyle.ElementBGRadius);
			obj.LineWidth = GuiElement.scaled(9.0);
			obj.StrokePreserve();
			SurfaceTransformBlur.BlurFull(val2, GuiElement.scaled(6.0));
			obj.StrokePreserve();
			SurfaceTransformBlur.BlurFull(val2, GuiElement.scaled(6.0));
			obj.LineWidth = GuiElement.scaled(3.0);
			obj.Stroke();
			obj.LineWidth = GuiElement.scaled(1.0);
			obj.SetSourceRGBA(GuiStyle.ActiveSlotColor);
			obj.Stroke();
			generateTexture(val2, ref highlightSlotTexture, true);
			obj.Dispose();
			((Surface)val2).Dispose();
		}
		base.ComposeElements(slotCtx, slotSurface);
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		base.RenderInteractiveElements(deltaTime);
		if (Highlighted)
		{
			api.Render.Render2DTexturePremultipliedAlpha(highlightSlotTexture.TextureId, ((GuiElement)this).Bounds.renderX, ((GuiElement)this).Bounds.renderY, ((GuiElement)this).Bounds.absInnerWidth, ((GuiElement)this).Bounds.absInnerHeight, 50f, (Vec4f)null);
		}
		if (MaxNum > 1 && CurrentNum < textTextures.Length)
		{
			LoadedTexture val = textTextures[CurrentNum];
			api.Render.Render2DLoadedTexture(val, (float)((GuiElement)this).Bounds.renderX + (float)((GuiElement)this).Bounds.absInnerWidth - (float)val.Width, (float)((GuiElement)this).Bounds.renderY + (float)((GuiElement)this).Bounds.absInnerHeight + (float)GuiElement.scaled(5.0) - (float)val.Height, 50f);
		}
	}
}




