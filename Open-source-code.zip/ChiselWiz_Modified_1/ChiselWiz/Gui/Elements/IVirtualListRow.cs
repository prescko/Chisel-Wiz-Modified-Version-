﻿using System;
using System.Collections.Generic;
using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Elements;

public interface IVirtualListRow<TData>
{
	ElementBounds Bounds { get; set; }

	int RowHeight { get; }

	TData Data { get; }

	void SetData(TData data);

	void Dispose();

	void Hide();

	void CreateComponents(GuiComposer composer, Dictionary<string, Action<IVirtualListRow<TData>>> actions);

	void SetSelected(bool selected);
}





