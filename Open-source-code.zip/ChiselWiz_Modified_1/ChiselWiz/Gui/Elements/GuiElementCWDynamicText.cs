﻿using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Elements;

public class GuiElementCWDynamicText : GuiElementDynamicText
{
	public bool Visible { get; set; }

	public GuiElementCWDynamicText(ICoreClientAPI capi, string text, CairoFont font, ElementBounds bounds)
		: base(capi, text, font, bounds)
	{
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (Visible)
		{
			base.RenderInteractiveElements(deltaTime);
		}
	}
}




