﻿using System;
using Cairo;
using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Elements;

internal class GuiElementCWScrollbar : GuiElementScrollbar
{
	public ElementBounds ScrollableAreaBounds { get; set; }

	public GuiElementCWScrollbar(ICoreClientAPI capi, Action<float> onNewScrollbarValue, ElementBounds bounds, ElementBounds scrollableAreaBounds = null)
		: base(capi, onNewScrollbarValue, bounds)
	{
		ScrollableAreaBounds = scrollableAreaBounds;
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surface)
	{
		ScrollableAreaBounds.CalcWorldBounds();
		base.ComposeElements(ctxStatic, surface);
	}

	public override void OnMouseWheel(ICoreClientAPI api, MouseWheelEventArgs args)
	{
		if (ScrollableAreaBounds == null || ScrollableAreaBounds.PointInside(api.Input.MouseX, api.Input.MouseY))
		{
			base.OnMouseWheel(api, args);
		}
	}
}




