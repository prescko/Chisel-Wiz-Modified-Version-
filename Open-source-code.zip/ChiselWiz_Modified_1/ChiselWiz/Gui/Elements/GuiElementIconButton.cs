﻿using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

internal class GuiElementIconButton : GuiElementControl
{
	private LoadedTexture normalTexture;

	private LoadedTexture activeTexture;

	private LoadedTexture hoverTexture;

	private LoadedTexture disabledTexture;

	private LoadedTexture iconTexture;

	private GuiElementDynamicText textElement;

	private AssetLocation iconLocation;

	private double iconSize;

	private ActionConsumable onClick;

	private bool isOver;

	private ElementBounds iconBounds;

	private EnumButtonStyle buttonStyle;

	private bool active;

	private bool currentlyMouseDownOnElement;

	public bool PlaySound = true;

	public static double Padding = 2.0;

	public bool Visible = true;

	public bool Toggleable;

	public bool Toggled;

	public override bool Focusable => base.enabled;

	public string Text
	{
		get
		{
			return ((GuiElementTextBase)textElement).GetText();
		}
		set
		{
			((GuiElementTextBase)textElement).Text = value;
		}
	}

	public GuiElementIconButton(ICoreClientAPI capi, AssetLocation iconLocation, string text, CairoFont font, ActionConsumable onClick, ElementBounds bounds, EnumButtonStyle style = (EnumButtonStyle)2)
		: base(capi, bounds)
	{

		hoverTexture = new LoadedTexture(capi);
		activeTexture = new LoadedTexture(capi);
		normalTexture = new LoadedTexture(capi);
		disabledTexture = new LoadedTexture(capi);
		iconTexture = new LoadedTexture(capi);
		bounds.CalcWorldBounds();
		if (text != null && font != null && iconLocation != (AssetLocation)null)
		{
			CairoFont val = font.Clone().WithOrientation((EnumTextOrientation)0);
			FontExtents fontExtents = font.GetFontExtents();
			TextExtents textExtents = font.GetTextExtents(text);
			double num = (0.0 - fontExtents.Ascent - textExtents.YBearing + (bounds.InnerHeight + textExtents.YBearing) / 2.0) / (double)RuntimeEnv.GUIScale;
			iconSize = fontExtents.Height * 0.95 / (double)RuntimeEnv.GUIScale;
			ElementBounds val2 = bounds.ForkChild().WithFixedPosition(0.0, num);
			iconBounds = val2.FlatCopy().WithFixedSize(iconSize, iconSize);
			double num2 = fontExtents.Height * 0.15 / (double)RuntimeEnv.GUIScale;
			double num3 = val2.fixedWidth / 2.0;
			double num4 = iconBounds.fixedWidth + num2 + textExtents.Width / (double)RuntimeEnv.GUIScale;
			double num5 = num3 - num4 / 2.0;
			iconBounds.fixedX = num5;
			val2.fixedX = num5 + iconBounds.fixedWidth + num2;
			textElement = new GuiElementDynamicText(capi, text, val, val2);
		}
		else if (text != null && font != null)
		{
			CairoFont val3 = font.Clone().WithOrientation((EnumTextOrientation)2);
			FontExtents fontExtents2 = font.GetFontExtents();
			TextExtents textExtents2 = font.GetTextExtents(text);
			double num6 = (0.0 - fontExtents2.Ascent - textExtents2.YBearing + (bounds.InnerHeight + textExtents2.YBearing) / 2.0) / (double)RuntimeEnv.GUIScale;
			ElementBounds val4 = bounds.ForkChild().WithFixedPosition(0.0, num6);
			textElement = new GuiElementDynamicText(capi, text, val3, val4);
		}
		else
		{
			iconSize = bounds.InnerHeight * 1.5;
			iconBounds = bounds.ForkChild().WithFixedPosition(0.0, 0.0);
			ElementBounds obj = iconBounds;
			obj.fixedWidth *= 0.7;
			ElementBounds obj2 = iconBounds;
			obj2.fixedHeight *= 0.7;
		}
		this.iconLocation = iconLocation;
		buttonStyle = style;
		this.onClick = onClick;
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surfaceStatic)
	{

		((GuiElement)this).Bounds.CalcWorldBounds();
		GuiElementDynamicText obj = textElement;
		if (obj != null)
		{
			((GuiElement)obj).ComposeElements(ctxStatic, surfaceStatic);
		}
		ComposeIconTexture();
		ImageSurface val = new ImageSurface((Format)0, (int)((GuiElement)this).Bounds.OuterWidth, (int)((GuiElement)this).Bounds.OuterHeight);
		Context val2 = genContext(val);
		ComposeButton(val2, val);
		generateTexture(val, ref normalTexture, true);
		ContextUtils.Clear(val2);
		if ((int)buttonStyle != 0)
		{
			val2.SetSourceRGBA(0.0, 0.0, 0.0, 0.4);
			val2.Rectangle(0.0, 0.0, ((GuiElement)this).Bounds.OuterWidth, ((GuiElement)this).Bounds.OuterHeight);
			val2.Fill();
		}
		generateTexture(val, ref activeTexture, true);
		ContextUtils.Clear(val2);
		if ((int)buttonStyle != 0)
		{
			val2.SetSourceRGBA(1.0, 1.0, 1.0, 0.1);
			val2.Rectangle(0.0, 0.0, ((GuiElement)this).Bounds.OuterWidth, ((GuiElement)this).Bounds.OuterHeight);
			val2.Fill();
		}
		generateTexture(val, ref hoverTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
		val = new ImageSurface((Format)0, 2, 2);
		val2 = genContext(val);
		if ((int)buttonStyle != 0)
		{
			val2.SetSourceRGBA(0.0, 0.0, 0.0, 0.4);
			val2.Rectangle(0.0, 0.0, 2.0, 2.0);
			val2.Fill();
		}
		generateTexture(val, ref disabledTexture, true);
		val2.Dispose();
		((Surface)val).Dispose();
	}

	private void ComposeIconTexture()
	{

		if (!(iconLocation == (AssetLocation)null))
		{
			iconBounds.CalcWorldBounds();
			ImageSurface val = new ImageSurface((Format)0, (int)iconSize, (int)iconSize);
			Context val2 = genContext(val);
			api.Gui.Icons.SvgIconSource(iconLocation).Invoke(val2, 0, 0, (float)iconSize, (float)iconSize, ColorUtil.WhiteArgbDouble);
			generateTexture(val, ref iconTexture, true);
			val2.Dispose();
			((Surface)val).Dispose();
		}
	}

	private void ComposeButton(Context ctx, ImageSurface surface)
	{

		double num = GuiElement.scaled(2.5);
		if ((int)buttonStyle == 2 || (int)buttonStyle == 3)
		{
			num = GuiElement.scaled(1.5);
		}
		if ((int)buttonStyle != 0)
		{
			GuiElement.Rectangle(ctx, 0.0, 0.0, ((GuiElement)this).Bounds.OuterWidth, ((GuiElement)this).Bounds.OuterHeight);
			ctx.SetSourceRGBA(23.0 / 85.0, 52.0 / 255.0, 12.0 / 85.0, 0.8);
			ctx.Fill();
		}
		if ((int)buttonStyle == 1)
		{
			GuiElement.Rectangle(ctx, 0.0, 0.0, ((GuiElement)this).Bounds.OuterWidth, num);
			ctx.SetSourceRGBA(1.0, 1.0, 1.0, 0.15);
			ctx.Fill();
		}
		if ((int)buttonStyle == 2 || (int)buttonStyle == 3)
		{
			GuiElement.Rectangle(ctx, 0.0, 0.0, ((GuiElement)this).Bounds.OuterWidth - num, num);
			ctx.SetSourceRGBA(1.0, 1.0, 1.0, 0.15);
			ctx.Fill();
			GuiElement.Rectangle(ctx, 0.0, 0.0 + num, num, ((GuiElement)this).Bounds.OuterHeight - num);
			ctx.SetSourceRGBA(1.0, 1.0, 1.0, 0.15);
			ctx.Fill();
		}
		SurfaceTransformBlur.BlurPartial(surface, 2.0, 5);
		((GuiElement)this).Bounds.CalcWorldBounds();
		if ((int)buttonStyle == 1)
		{
			GuiElement.Rectangle(ctx, 0.0, 0.0 + ((GuiElement)this).Bounds.OuterHeight - num, ((GuiElement)this).Bounds.OuterWidth, num);
			ctx.SetSourceRGBA(0.0, 0.0, 0.0, 0.2);
			ctx.Fill();
		}
		if ((int)buttonStyle == 2 || (int)buttonStyle == 3)
		{
			GuiElement.Rectangle(ctx, 0.0 + num, 0.0 + ((GuiElement)this).Bounds.OuterHeight - num, ((GuiElement)this).Bounds.OuterWidth - 2.0 * num, num);
			ctx.SetSourceRGBA(0.0, 0.0, 0.0, 0.2);
			ctx.Fill();
			GuiElement.Rectangle(ctx, 0.0 + ((GuiElement)this).Bounds.OuterWidth - num, 0.0, num, ((GuiElement)this).Bounds.OuterHeight);
			ctx.SetSourceRGBA(0.0, 0.0, 0.0, 0.2);
			ctx.Fill();
		}
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (Visible)
		{
			api.Render.Render2DTexturePremultipliedAlpha(normalTexture.TextureId, ((GuiElement)this).Bounds, 50f, (Vec4f)null);
			GuiElementDynamicText obj = textElement;
			if (obj != null)
			{
				((GuiElement)obj).RenderInteractiveElements(deltaTime);
			}
			if (iconLocation != (AssetLocation)null)
			{
				api.Render.Render2DTexturePremultipliedAlpha(iconTexture.TextureId, iconBounds, 50f, (Vec4f)null);
			}
			if (!base.enabled)
			{
				api.Render.Render2DTexturePremultipliedAlpha(disabledTexture.TextureId, ((GuiElement)this).Bounds, 50f, (Vec4f)null);
			}
			else if (active || currentlyMouseDownOnElement || (Toggleable && !Toggled))
			{
				api.Render.Render2DTexturePremultipliedAlpha(activeTexture.TextureId, ((GuiElement)this).Bounds, 50f, (Vec4f)null);
			}
			else if (isOver)
			{
				api.Render.Render2DTexturePremultipliedAlpha(hoverTexture.TextureId, ((GuiElement)this).Bounds, 50f, (Vec4f)null);
			}
		}
	}

	public override void OnKeyDown(ICoreClientAPI api, KeyEvent args)
	{
		if (!Visible || !((GuiElement)this).HasFocus || args.KeyCode != 49)
		{
			return;
		}
		args.Handled = true;
		if (base.enabled)
		{
			if (PlaySound)
			{
				api.Gui.PlaySound("menubutton_press", false, 1f);
			}
			Toggled = !Toggled;
			args.Handled = onClick.Invoke();
			if (!args.Handled || !Toggleable)
			{
				Toggled = !Toggled;
			}
		}
	}

	public override void OnMouseMove(ICoreClientAPI api, MouseEvent args)
	{
		bool num = isOver;
		setIsOver();
		if (!num && isOver && PlaySound)
		{
			api.Gui.PlaySound("menubutton", false, 1f);
		}
	}

	protected void setIsOver()
	{
		isOver = Visible && base.enabled && ((GuiElement)this).Bounds.PointInside(api.Input.MouseX, api.Input.MouseY);
	}

	public override void OnMouseDownOnElement(ICoreClientAPI api, MouseEvent args)
	{
		if (Visible && base.enabled)
		{
			base.OnMouseDownOnElement(api, args);
			currentlyMouseDownOnElement = true;
			if (PlaySound)
			{
				api.Gui.PlaySound("menubutton_down", false, 1f);
			}
			setIsOver();
		}
	}

	public override void OnMouseUp(ICoreClientAPI api, MouseEvent args)
	{
		if (Visible)
		{
			if (currentlyMouseDownOnElement && !((GuiElement)this).Bounds.PointInside(args.X, args.Y) && !active && PlaySound)
			{
				api.Gui.PlaySound("menubutton_up", false, 1f);
			}
			base.OnMouseUp(api, args);
			currentlyMouseDownOnElement = false;
		}
	}

	public override void OnMouseUpOnElement(ICoreClientAPI api, MouseEvent args)
	{

		if (base.enabled && currentlyMouseDownOnElement && ((GuiElement)this).Bounds.PointInside(args.X, args.Y) && ((int)args.Button == 0 || (int)args.Button == 2))
		{
			Toggled = !Toggled;
			args.Handled = onClick.Invoke();
			if (!args.Handled || !Toggleable)
			{
				Toggled = !Toggled;
			}
		}
		currentlyMouseDownOnElement = false;
	}

	public void SetActive(bool active)
	{
		this.active = active;
	}

	public override void Dispose()
	{
		base.Dispose();
		LoadedTexture obj = hoverTexture;
		if (obj != null)
		{
			obj.Dispose();
		}
		LoadedTexture obj2 = activeTexture;
		if (obj2 != null)
		{
			obj2.Dispose();
		}
		LoadedTexture obj3 = disabledTexture;
		if (obj3 != null)
		{
			obj3.Dispose();
		}
		LoadedTexture obj4 = normalTexture;
		if (obj4 != null)
		{
			obj4.Dispose();
		}
		LoadedTexture obj5 = iconTexture;
		if (obj5 != null)
		{
			obj5.Dispose();
		}
		GuiElementDynamicText obj6 = textElement;
		if (obj6 != null)
		{
			((GuiElement)obj6).Dispose();
		}
	}
}




