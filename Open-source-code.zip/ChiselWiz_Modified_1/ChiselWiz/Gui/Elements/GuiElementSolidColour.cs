﻿using Cairo;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

public class GuiElementSolidColour : GuiElement
{
	private LoadedTexture texture;

	private Vec4f colour4f;

	public GuiElementSolidColour(ICoreClientAPI capi, ElementBounds bounds)
		: base(capi, bounds)
	{

		texture = new LoadedTexture(capi);
	}

	public void SetColour(int colour)
	{

		float[] array = ColorUtil.ToRGBAFloats(ColorUtil.ReverseColorBytes(colour));
		colour4f = new Vec4f(array[0], array[1], array[2], 1f);
	}

	public void SetColour(SKColor colour)
	{

		colour4f = new Vec4f((float)(int)colour.Red / 255f, (float)(int)colour.Green / 255f, (float)(int)colour.Blue / 255f, (float)(int)colour.Alpha / 255f);
	}

	public override void ComposeElements(Context ctxStatic, ImageSurface surfaceStatic)
	{

		base.Bounds.CalcWorldBounds();
		ImageSurface val = new ImageSurface((Format)0, (int)base.Bounds.OuterWidth, (int)base.Bounds.OuterHeight);
		Context obj = genContext(val);
		obj.SetSourceRGBA(ColorUtil.WhiteArgbDouble);
		GuiElement.Rectangle(obj, 0.0, 0.0, (double)base.Bounds.OuterWidthInt, (double)base.Bounds.OuterHeightInt);
		obj.Fill();
		generateTexture(val, ref texture, true);
		obj.Dispose();
		((Surface)val).Dispose();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (texture != null)
		{
			base.api.Render.Render2DTexturePremultipliedAlpha(texture.TextureId, base.Bounds, 50f, colour4f);
		}
	}

	public override void Dispose()
	{
		LoadedTexture obj = texture;
		if (obj != null)
		{
			obj.Dispose();
		}
	}
}




