﻿using System;
using Vintagestory.API.Client;

namespace ChiselWiz.Gui.Elements;

internal class GuiElementCWDropDown : GuiElementDropDown
{
	public Action OnListOpened;

	public GuiElementCWDropDown(ICoreClientAPI capi, string[] values, string[] names, int selectedIndex, SelectionChangedDelegate onSelectionChanged, ElementBounds bounds, CairoFont font, bool multiSelect)
		: base(capi, values, names, selectedIndex, onSelectionChanged, bounds, font, multiSelect)
	{
	}

	public override void OnMouseDown(ICoreClientAPI api, MouseEvent args)
	{
		base.OnMouseDown(api, args);
		if (args.Handled && base.listMenu.IsOpened)
		{
			OnListOpened?.Invoke();
		}
	}
}




