﻿using System.Linq;
using Cairo;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Gui.Elements;

internal class GuiElementIcon : GuiElement
{
	private LoadedTexture[] textures;

	private AssetLocation[] iconLocations;

	private int iconPadding;

	public bool Visible { get; set; } = true;

	public int IconIdx { get; set; }

	public GuiElementIcon(ICoreClientAPI capi, AssetLocation iconLocation, ElementBounds bounds, int iconPadding = 0)
		: base(capi, bounds)
	{
		iconLocations = (AssetLocation[])(object)new AssetLocation[1] { iconLocation };
		this.iconPadding = iconPadding;
	}

	public GuiElementIcon(ICoreClientAPI capi, AssetLocation[] iconLocations, ElementBounds bounds, int iconPadding = 0)
		: base(capi, bounds)
	{
		this.iconLocations = iconLocations;
		this.iconPadding = iconPadding;
	}

	public override void ComposeElements(Context ctx, ImageSurface surface)
	{
		textures = (from iconLocation in iconLocations.ToList()
			select base.api.Gui.LoadSvgWithPadding(iconLocation, (int)(base.Bounds.fixedWidth - base.Bounds.fixedPaddingX * 2.0), (int)(base.Bounds.fixedHeight - base.Bounds.fixedPaddingY * 2.0), (int)base.Bounds.fixedPaddingX + iconPadding, (int?)(-1))).ToArray();
	}

	public override void RenderInteractiveElements(float deltaTime)
	{
		if (Visible && IconIdx < textures.Length && IconIdx >= 0)
		{
			LoadedTexture val = textures[IconIdx];
			base.api.Render.Render2DTexturePremultipliedAlpha(val.TextureId, base.Bounds, 50f, (Vec4f)null);
		}
	}

	public override void Dispose()
	{
		base.Dispose();
		if (textures == null)
		{
			return;
		}
		LoadedTexture[] array = textures;
		foreach (LoadedTexture obj in array)
		{
			if (obj != null)
			{
				obj.Dispose();
			}
		}
	}
}




