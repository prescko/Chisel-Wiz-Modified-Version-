﻿namespace ChiselWiz.Gui.Elements;

public enum EnumBlockRenderMode
{
	SpinningCube,
	FaceForward
}




