﻿using System;
using System.Collections.Generic;
using System.Linq;
using ChiselWiz.Systems.Images.Colouring;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.Client.NoObf;

namespace ChiselWiz.Systems.Images;

public class PaletteEntryManager
{
	private ICoreClientAPI capi;

	private Dictionary<Block, PaletteEntry> blockPaletteEntries;

	public PaletteEntryManager(ICoreClientAPI capi)
	{
		this.capi = capi;
		blockPaletteEntries = new Dictionary<Block, PaletteEntry>();
	}

	public PaletteEntry CreatePaletteEntryFromBlock(Block block)
	{
		if (blockPaletteEntries.TryGetValue(block, out var value))
		{
			return value.Clone();
		}
		using TextureLoader texLoader = new TextureLoader(capi.World as ClientMain);
		PaletteEntry paletteEntry = new PaletteEntry(block, texLoader);
		blockPaletteEntries[block] = paletteEntry;
		return paletteEntry.Clone();
	}

	public PaletteEntry[] CreatePaletteEntriesFromBlocks(IEnumerable<Block> blocks)
	{
		TextureLoader textureLoader = new TextureLoader(capi.World as ClientMain);
		try
		{
			return blocks.ToList().Select(delegate(Block block)
			{
				if (blockPaletteEntries.TryGetValue(block, out var value))
				{
					return value.Clone();
				}
				PaletteEntry paletteEntry = new PaletteEntry(block, textureLoader);
				blockPaletteEntries[block] = paletteEntry;
				return paletteEntry.Clone();
			}).ToArray();
		}
		finally
		{
			if (textureLoader != null)
			{
				((IDisposable)textureLoader).Dispose();
			}
		}
	}
}




