﻿namespace ChiselWiz.Systems.Images.Designs;

public interface IRemappableDesign : IImageDesign
{
	RemappablePaletteEntry[] IndexedDesignPalette { get; set; }

	int[,] IndexedDesignData { get; set; }
}




