﻿using System;
using System.Collections.Generic;
using System.Threading;
using ChiselWiz.Systems.Images.Colouring;
using SkiaSharp;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Systems.Images.Designs;

public class BasicImageDesign : ImageDesign, IRemappableDesign, IImageDesign
{
	public RemappablePaletteEntry[] IndexedDesignPalette { get; set; }

	public int[,] IndexedDesignData { get; set; }

	public BasicImageDesign(ImageDesignLoader designLoader, SKBitmap sourceBitmap, Palette masterPalette)
		: base(designLoader)
	{
		InitData(sourceBitmap, masterPalette, sourceBitmap.Width / 2, sourceBitmap.Height / 2);
	}

	public override void RebuildVoxelData()
	{
		if (IndexedDesignData == null)
		{
			return;
		}
		int length = base.VoxelData.GetLength(0);
		int length2 = base.VoxelData.GetLength(1);
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length2; j++)
			{
				int num = IndexedDesignData[i, j];
				if (num == -1)
				{
					base.VoxelData[i, j] = null;
					continue;
				}
				RemappablePaletteEntry remappablePaletteEntry = IndexedDesignPalette[num];
				if (remappablePaletteEntry == null || !remappablePaletteEntry.Enabled || remappablePaletteEntry.Block == null)
				{
					base.VoxelData[i, j] = null;
				}
				else
				{
					base.VoxelData[i, j] = designLoader.PaletteEntryManager.CreatePaletteEntryFromBlock(remappablePaletteEntry.Block);
				}
			}
		}
	}

	public override void ComputePaletteColourMapping(IProgress<double> progress, CancellationToken? cancellationToken)
	{

		int length = base.VoxelData.GetLength(0);
		int length2 = base.VoxelData.GetLength(1);
		HashSet<Block> hashSet = new HashSet<Block>();
		List<int> list = new List<int>();
		List<RemappablePaletteEntry> list2 = new List<RemappablePaletteEntry>();
		int[,] array = new int[length, length2];
		int num = length * length2;
		int num2 = 0;
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length2; j++)
			{
				cancellationToken?.ThrowIfCancellationRequested();
				num2++;
				progress?.Report((double)num2 / (double)num);
				SKColor pixel = base.SourceBitmap.GetPixel(i * 2, j * 2);
				if (pixel.Alpha < 128)
				{
					array[i, j] = -1;
					continue;
				}
				PaletteEntry paletteEntry = null;
				paletteEntry = ((base.SubsetPalette == null) ? new PaletteEntry(pixel.WithAlpha(byte.MaxValue)) : base.SubsetPalette.FindBestFitEntry(pixel.WithAlpha(byte.MaxValue)));
				if (paletteEntry == null)
				{
					array[i, j] = -1;
					continue;
				}
				int num3 = list.IndexOf(SkColorFix.ToInt(paletteEntry.AvgBlockColour));
				if (num3 == -1)
				{
					num3 = list.Count;
					list.Add(SkColorFix.ToInt(paletteEntry.AvgBlockColour));
					list2.Add(new RemappablePaletteEntry
					{
						Block = paletteEntry.Block,
						Colour = paletteEntry.AvgBlockColour,
						Enabled = true
					});
				}
				array[i, j] = num3;
				hashSet.Add(paletteEntry.Block);
			}
		}
		IndexedDesignPalette = list2.ToArray();
		IndexedDesignData = array;
	}

	public override ImageDesign Copy()
	{
		BasicImageDesign basicImageDesign = (BasicImageDesign)base.Copy();
		basicImageDesign.IndexedDesignPalette = new RemappablePaletteEntry[IndexedDesignPalette.Length];
		for (int i = 0; i < IndexedDesignPalette.Length; i++)
		{
			basicImageDesign.IndexedDesignPalette[i] = IndexedDesignPalette[i]?.Clone();
		}
		return basicImageDesign;
	}
}




