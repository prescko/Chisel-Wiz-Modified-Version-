﻿using SkiaSharp;
using Vintagestory.API.Common;

namespace ChiselWiz.Systems.Images.Designs;

public class RemappablePaletteEntry
{
	public bool Enabled;

	public SKColor Colour;

	public Block Block;

	public RemappablePaletteEntry Clone()
	{
		return (RemappablePaletteEntry)MemberwiseClone();
	}
}



