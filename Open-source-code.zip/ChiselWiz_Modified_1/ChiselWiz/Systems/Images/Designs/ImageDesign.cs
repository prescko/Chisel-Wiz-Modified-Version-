﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Images.Colouring;
using SkiaSharp;
using Vintagestory.API.Common;

namespace ChiselWiz.Systems.Images.Designs;

public class ImageDesign : IImageDesign, IDisposable
{
	public string Name = "";

	protected ImageDesignLoader designLoader;

	public Palette MasterPalette { get; set; }

	public Palette SubsetPalette { get; set; }

	public PaletteEntry[,] VoxelData { get; set; }

	public SKBitmap SourceBitmap { get; set; }

	public SKBitmap PreviewBitmap { get; set; }

	public int Width => VoxelData?.GetLength(0) ?? 0;

	public int Height => VoxelData?.GetLength(1) ?? 0;

	public ImageDesign(ImageDesignLoader designLoader)
	{
		this.designLoader = designLoader;
	}

	public virtual void InitData(SKBitmap sourceBitmap, Palette masterPalette, int voxelWidth, int voxelHeight)
	{
		MasterPalette = masterPalette;
		SubsetPalette = masterPalette;
		SourceBitmap = sourceBitmap.Copy();
		PreviewBitmap = sourceBitmap.Copy();
		VoxelData = new PaletteEntry[voxelWidth, voxelHeight];
	}

	public void CreateSubsetPaletteFromMaster(IEnumerable<Block> blocks)
	{
		SubsetPalette = MasterPalette?.ReduceToSubset(blocks);
	}

	public BlockBlueprint CreateBlockBlueprint(int tileX, int tileY)
	{
		int length = VoxelData.GetLength(0);
		int length2 = VoxelData.GetLength(1);
		List<Block> list = new List<Block>();
		int[,] array = new int[16, 16];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				int num = tileX * 16 + i;
				int num2 = tileY * 16 + j;
				if (num < 0 || num >= length || num2 < 0 || num2 >= length2)
				{
					array[i, j] = -1;
					continue;
				}
				PaletteEntry[,] voxelData = VoxelData;
				Block val = ((voxelData == null) ? null : voxelData[num, num2]?.Block);
				if (val == null)
				{
					array[i, j] = -1;
					continue;
				}
				int num3 = list.IndexOf(val);
				if (num3 == -1)
				{
					num3 = list.Count;
					list.Add(val);
				}
				array[i, j] = num3;
			}
		}
		if (list.Count == 0)
		{
			return null;
		}
		BlockBlueprint blockBlueprint = new BlockBlueprint();
		blockBlueprint.MaterialCodes.AddRange(list.Select((Block x) => ((object)((RegistryObject)x).Code).ToString()));
		for (int num4 = 0; num4 < 16; num4++)
		{
			for (int num5 = 0; num5 < 16; num5++)
			{
				int num6 = array[num4, num5];
				bool flag = num6 != -1;
				blockBlueprint.Voxels[num4, 15 - num5, 0] = flag;
				blockBlueprint.Materials[num4, 15 - num5, 0] = (byte)(flag ? ((uint)num6) : 0u);
			}
		}
		blockBlueprint.SimplifyMaterials();
		return blockBlueprint;
	}

	public virtual void ComputePaletteColourMapping(IProgress<double> progress, CancellationToken? cancellationToken)
	{
		throw new NotImplementedException();
	}

	public virtual void RebuildVoxelData()
	{
		throw new NotImplementedException();
	}

	public void RedrawPreviewBitmap(bool atopOriginalColours = false)
	{

		RebuildVoxelData();
		if (SubsetPalette == null || atopOriginalColours)
		{
			SKBitmap previewBitmap = PreviewBitmap;
			if (previewBitmap != null)
			{
				((SKNativeObject)previewBitmap).Dispose();
			}
			SKBitmap sourceBitmap = SourceBitmap;
			PreviewBitmap = ((sourceBitmap != null) ? sourceBitmap.Copy() : null);
			return;
		}
		SKColor val = new SKColor(0, 0, 0, 0);
		SKColor[] array = (SKColor[])(object)new SKColor[4] { val, val, val, val };
		int length = VoxelData.GetLength(0);
		int length2 = VoxelData.GetLength(1);
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length2; j++)
			{
				PaletteEntry paletteEntry = VoxelData[i, j];
				if (paletteEntry == null && atopOriginalColours)
				{
					continue;
				}
				SKColor[] array2 = array;
				if (paletteEntry != null)
				{
					SKColor[] array3 = paletteEntry.VoxelTextures[i % 16, j % 16]?.Colours;
					if (array3 != null)
					{
						array2 = array3;
					}
				}
				PreviewBitmap.SetPixel(i * 2, j * 2, array2[0]);
				PreviewBitmap.SetPixel(i * 2 + 1, j * 2, array2[1]);
				PreviewBitmap.SetPixel(i * 2, j * 2 + 1, array2[2]);
				PreviewBitmap.SetPixel(i * 2 + 1, j * 2 + 1, array2[3]);
			}
		}
	}

	public void Dispose()
	{
		SKBitmap sourceBitmap = SourceBitmap;
		if (sourceBitmap != null)
		{
			((SKNativeObject)sourceBitmap).Dispose();
		}
		SKBitmap previewBitmap = PreviewBitmap;
		if (previewBitmap != null)
		{
			((SKNativeObject)previewBitmap).Dispose();
		}
	}

	public virtual ImageDesign Copy()
	{
		ImageDesign imageDesign = (ImageDesign)MemberwiseClone();
		imageDesign.VoxelData = new PaletteEntry[VoxelData.GetLength(0), VoxelData.GetLength(1)];
		for (int i = 0; i < VoxelData.GetLength(0); i++)
		{
			for (int j = 0; j < VoxelData.GetLength(1); j++)
			{
				imageDesign.VoxelData[i, j] = VoxelData[i, j]?.Clone();
			}
		}
		SKBitmap previewBitmap = PreviewBitmap;
		imageDesign.PreviewBitmap = ((previewBitmap != null) ? previewBitmap.Copy() : null);
		SKBitmap sourceBitmap = SourceBitmap;
		imageDesign.SourceBitmap = ((sourceBitmap != null) ? sourceBitmap.Copy() : null);
		imageDesign.Name = Name;
		return imageDesign;
	}
}




