﻿using System;
using System.Threading;
using ChiselWiz.Systems.Blueprints;
using ChiselWiz.Systems.Images.Colouring;
using SkiaSharp;

namespace ChiselWiz.Systems.Images.Designs;

public interface IImageDesign
{
	Palette MasterPalette { get; set; }

	Palette SubsetPalette { get; set; }

	PaletteEntry[,] VoxelData { get; set; }

	SKBitmap SourceBitmap { get; set; }

	SKBitmap PreviewBitmap { get; set; }

	void ComputePaletteColourMapping(IProgress<double> progress, CancellationToken? cancellationToken);

	void RebuildVoxelData();

	void RedrawPreviewBitmap(bool atopOriginalColours = false);

	BlockBlueprint CreateBlockBlueprint(int tileX, int tileY);
}




