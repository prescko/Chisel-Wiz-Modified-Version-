﻿using System;
using System.Threading;
using ChiselWiz.Systems.Images.Colouring;
using SkiaSharp;

namespace ChiselWiz.Systems.Images.Designs;

public class ComplexImageDesign : ImageDesign
{
	public ComplexImageDesign(ImageDesignLoader designLoader, SKBitmap sourceBitmap, Palette masterPalette)
		: base(designLoader)
	{

		int num = sourceBitmap.Width / 2;
		int num2 = sourceBitmap.Height / 2;
		SKBitmap val = new SKBitmap();
		try
		{
			sourceBitmap.ExtractSubset(val, new SKRectI(0, 0, num * 2, num2 * 2));
			InitData(val, masterPalette, num, num2);
		}
		finally
		{
			((IDisposable)val)?.Dispose();
		}
	}

	public override void RebuildVoxelData()
	{
	}

	public override void ComputePaletteColourMapping(IProgress<double> progress, CancellationToken? cancellationToken)
	{

		if (base.SubsetPalette == null)
		{
			return;
		}
		int length = base.VoxelData.GetLength(0);
		int length2 = base.VoxelData.GetLength(1);
		int num = length * length2;
		int num2 = 0;
		for (int i = 0; i < length; i++)
		{
			for (int j = 0; j < length2; j++)
			{
				cancellationToken?.ThrowIfCancellationRequested();
				num2++;
				progress?.Report((double)num2 / (double)num);
				SKColor[] array = (SKColor[])(object)new SKColor[4]
				{
					base.SourceBitmap.GetPixel(i * 2, j * 2),
					base.SourceBitmap.GetPixel(i * 2 + 1, j * 2),
					base.SourceBitmap.GetPixel(i * 2, j * 2 + 1),
					base.SourceBitmap.GetPixel(i * 2 + 1, j * 2 + 1)
				};
				bool flag = false;
				SKColor[] array2 = array;
				for (int k = 0; k < array2.Length; k++)
				{
					SKColor val = array2[k];
					if (val.Alpha < 128)
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					base.VoxelData[i, j] = null;
				}
				else
				{
					base.VoxelData[i, j] = base.SubsetPalette.FindBestFitEntry(array, i % 16, j % 16);
				}
			}
		}
	}
}




