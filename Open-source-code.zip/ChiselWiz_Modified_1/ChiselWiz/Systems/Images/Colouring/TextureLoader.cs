﻿using System;
using System.Collections.Generic;
using SkiaSharp;
using Vintagestory.API.Common;
using Vintagestory.Client.NoObf;

namespace ChiselWiz.Systems.Images.Colouring;

public class TextureLoader : IDisposable
{
	private ClientMain main;

	private Dictionary<AssetLocation, SKBitmap> cache;

	public TextureLoader(ClientMain main)
	{
		this.main = main;
		cache = new Dictionary<AssetLocation, SKBitmap>();
	}

	public void Dispose()
	{
		foreach (var (_, val3) in cache)
		{
			if (val3 != null)
			{
				((SKNativeObject)val3).Dispose();
			}
		}
	}

	public SKBitmap GetBitmap(AssetLocation loc)
	{
		if (cache.TryGetValue(loc, out var value))
		{
			return value.Copy();
		}
		AssetLocation val = loc.CopyWithPathPrefixAndAppendixOnce("textures/", ".png");
		IAsset val2 = main.AssetManager.TryGet(val, true);
		if (val2 == null)
		{
			return null;
		}
		SKBitmap val3 = SKBitmap.Decode(val2.Data);
		cache[loc] = val3;
		return val3.Copy();
	}
}




