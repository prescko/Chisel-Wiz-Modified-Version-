﻿namespace ChiselWiz.Systems.Images.Colouring;

public enum EnumPaletteReductionMethod
{
	None,
	BlackWhite
}




