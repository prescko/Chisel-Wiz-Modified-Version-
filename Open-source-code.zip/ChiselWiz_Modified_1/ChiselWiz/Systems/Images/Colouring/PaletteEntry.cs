﻿using System;
using System.Collections.Generic;
using System.Linq;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Systems.Images.Colouring;

public class PaletteEntry
{
	private static readonly HashSet<string> chiselTextureKeys = new HashSet<string> { "north", "east", "south", "west", "up", "down", "brick" };

	public Block Block { get; private set; }

	public VoxelTexture[,] VoxelTextures { get; private set; }

	public SKColor AvgBlockColour { get; private set; }

	public PaletteEntry(Block block, TextureLoader texLoader)
	{
		Block = block;
		VoxelTextures = new VoxelTexture[16, 16];
		InitVoxelTextures(texLoader);
	}

	public PaletteEntry(SKColor colour)
	{

		AvgBlockColour = colour;
		VoxelTextures = new VoxelTexture[16, 16];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				VoxelTextures[i, j] = new VoxelTexture((SKColor[])(object)new SKColor[4] { colour, colour, colour, colour });
			}
		}
	}

	public PaletteEntry Clone()
	{
		return (PaletteEntry)MemberwiseClone();
	}

	private void InitVoxelTextures(TextureLoader texLoader)
	{

		HashSet<CompositeTexture> hashSet = new HashSet<CompositeTexture>();
		foreach (string chiselTextureKey in chiselTextureKeys)
		{
			string key = chiselTextureKey;
			string text = "inside-" + chiselTextureKey;
			if (Block.Textures.ContainsKey(text))
			{
				key = text;
			}
			if (!Block.Textures.TryGetValue(key, out var value))
			{
				continue;
			}
			hashSet.Add(value);
			if (value.Alternates != null)
			{
				CompositeTexture[] alternates = value.Alternates;
				foreach (CompositeTexture item in alternates)
				{
					hashSet.Add(item);
				}
			}
		}
		if (hashSet.Count == 0 && Block.Textures.Count > 0)
		{
			hashSet.Add(Block.Textures.Values.First());
		}
		List<CompositeTexture> list = hashSet.ToList();
		if (list.Count == 0)
		{
			return;
		}
		LayeredVoxelTextureArray layeredVoxelTextureArray = new LayeredVoxelTextureArray();
		SKColor val3 = default(SKColor);
		for (int j = 0; j < list.Count; j++)
		{
			CompositeTexture val = list[j];
			SKBitmap bitmap = texLoader.GetBitmap(val.Base);
			try
			{
				if (bitmap == null)
				{
					continue;
				}
				if (val.BlendedOverlays != null && val.BlendedOverlays.Length != 0)
				{
					BlendedOverlayTexture[] blendedOverlays = val.BlendedOverlays;
					foreach (BlendedOverlayTexture val2 in blendedOverlays)
					{
						SKBitmap bitmap2 = texLoader.GetBitmap(val2.Base);
						try
						{
							for (int k = 0; k < bitmap.Width; k++)
							{
								for (int l = 0; l < bitmap.Height; l++)
								{
									SKColor pixel = bitmap.GetPixel(k, l);
									int num = ColorUtil.ColorFromRgba((int)pixel.Red, (int)pixel.Green, (int)pixel.Blue, (int)pixel.Alpha);
									SKColor pixel2 = bitmap2.GetPixel(k, l);
									int num2 = ColorUtil.ColorFromRgba((int)pixel2.Red, (int)pixel2.Green, (int)pixel2.Blue, (int)pixel2.Alpha);
									byte[] array = ColorUtil.ToRGBABytes(ColorUtil.ReverseColorBytes(ColorBlend.Blend(val2.BlendMode, num, num2)));
									val3 = new SKColor(array[0], array[1], array[2], byte.MaxValue);
									bitmap.SetPixel(k, l, val3);
								}
							}
						}
						finally
						{
							((IDisposable)bitmap2)?.Dispose();
						}
					}
				}
				if (j == 0)
				{
					SKBitmap val4 = bitmap.Resize(new SKImageInfo(1, 1), SKSamplingOptions.Default);
					try
					{
						SKColor pixel3 = val4.GetPixel(0, 0);
						AvgBlockColour = pixel3.WithAlpha(byte.MaxValue);
					}
					finally
					{
						((IDisposable)val4)?.Dispose();
					}
				}
				VoxelTexture[,] item2 = CreateVoxelTextureArrayFromBitmap(bitmap, val.Rotation);
				layeredVoxelTextureArray.Enqueue(item2);
			}
			finally
			{
				((IDisposable)bitmap)?.Dispose();
			}
		}
		VoxelTextures = layeredVoxelTextureArray.Flatten();
	}

	private VoxelTexture[,] CreateVoxelTextureArrayFromBitmap(SKBitmap bmp, int rotation)
	{

		if (rotation != 0)
		{
			SKBitmap val = new SKBitmap(bmp.Height, bmp.Width, false);
			try
			{
				SKCanvas val2 = new SKCanvas(val);
				try
				{
					val2.RotateDegrees((float)(-rotation), (float)(bmp.Width / 2), (float)(bmp.Height / 2));
					val2.DrawBitmap(bmp, 0f, 0f, (SKPaint)null);
				}
				finally
				{
					((IDisposable)val2)?.Dispose();
				}
				return VoxelTexture.ArrayFromBitmap(val);
			}
			finally
			{
				((IDisposable)val)?.Dispose();
			}
		}
		return VoxelTexture.ArrayFromBitmap(bmp);
	}
}




