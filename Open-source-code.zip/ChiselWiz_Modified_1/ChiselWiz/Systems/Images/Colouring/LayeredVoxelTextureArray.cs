﻿using System;
using System.Collections.Generic;

namespace ChiselWiz.Systems.Images.Colouring;

public class LayeredVoxelTextureArray : Queue<VoxelTexture[,]>
{
	public VoxelTexture[,] Flatten()
	{
		VoxelTexture[,] array = Dequeue();
		if (base.Count == 0)
		{
			return array;
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				double[] array2 = new double[4];
				using (Enumerator enumerator = GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						VoxelTexture[,] current = enumerator.Current;
						double[] array3 = array[i, j].CalcDistance(current[i, j].Colours);
						for (int k = 0; k < 4; k++)
						{
							array2[k] += Math.Abs(array3[k]);
						}
					}
				}
				for (int l = 0; l < 4; l++)
				{
					array[i, j].AltPenalty[l] = array2[l] / (double)base.Count;
				}
			}
		}
		return array;
	}
}




