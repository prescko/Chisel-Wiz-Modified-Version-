﻿using SkiaSharp;

namespace ChiselWiz.Systems.Images.Colouring;

public class VoxelTexture
{
	public SKColor[] Colours { get; private set; }

	public double[] AltPenalty { get; private set; }

	public VoxelTexture(SKColor[] colours)
	{
		Colours = colours;
		AltPenalty = new double[Colours.Length];
	}

	public static VoxelTexture[,] ArrayFromBitmap(SKBitmap bitmap)
	{

		VoxelTexture[,] array = new VoxelTexture[16, 16];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				SKColor[] array2 = new SKColor[4];
				SKColor pixel = bitmap.GetPixel(i * 2, j * 2);
				array2[0] = pixel.WithAlpha(byte.MaxValue);
				pixel = bitmap.GetPixel(i * 2 + 1, j * 2);
				array2[1] = pixel.WithAlpha(byte.MaxValue);
				pixel = bitmap.GetPixel(i * 2, j * 2 + 1);
				array2[2] = pixel.WithAlpha(byte.MaxValue);
				pixel = bitmap.GetPixel(i * 2 + 1, j * 2 + 1);
				array2[3] = pixel.WithAlpha(byte.MaxValue);
				SKColor[] colours = (SKColor[])(object)array2;
				array[i, j] = new VoxelTexture(colours);
			}
		}
		return array;
	}

	public static double CalcColourDistance(SKColor srcColour, SKColor targetColour)
	{
		double num = (double)(int)targetColour.Red - (double)(int)srcColour.Red;
		double num2 = (double)(int)targetColour.Green - (double)(int)srcColour.Green;
		double num3 = (double)(int)targetColour.Blue - (double)(int)srcColour.Blue;
		return num * num * 4.0 + num2 * num2 * 6.0 + num3 * num3 * 3.0;
	}

	public double[] CalcDistance(SKColor[] otherColours)
	{

		double[] array = new double[4];
		for (int i = 0; i < 4; i++)
		{
			array[i] = CalcColourDistance(Colours[i], otherColours[i]) + AltPenalty[i];
		}
		return array;
	}
}




