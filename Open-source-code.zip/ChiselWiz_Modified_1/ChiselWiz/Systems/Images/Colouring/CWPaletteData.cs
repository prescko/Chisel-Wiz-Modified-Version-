﻿namespace ChiselWiz.Systems.Images.Colouring;

public class CWPaletteData
{
	public string key;

	public string name;

	public string[] include;

	public string[] except;

	public bool hideFromMenu;

	public bool requiresCreativeMode;

	public bool validForHighPixelDensity = true;

	public bool validForLowPixelDensity = true;
}




