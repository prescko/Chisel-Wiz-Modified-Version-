﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Vintagestory.API.Client;
using Vintagestory.API.Common;

namespace ChiselWiz.Systems.Images.Colouring;

public class Palettes : List<Palette>
{
	public static Palettes LoadFrom(ICoreClientAPI capi, AssetLocation palettesJsonLocation, PaletteEntryManager paletteEntryManager)
	{
		List<CWPaletteData> list = JsonConvert.DeserializeObject<List<CWPaletteData>>(((ICoreAPI)capi).Assets.Get(palettesJsonLocation).ToText());
		Palettes palettes = new Palettes();
		foreach (CWPaletteData item in list)
		{
			palettes.Add(new Palette(capi, item, paletteEntryManager));
		}
		return palettes;
	}
}




