﻿using System;
using System.Collections.Generic;
using System.Linq;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Datastructures;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems.Images.Colouring;

public class Palette
{
	public string Key { get; private set; }

	public string Name { get; private set; }

	public bool HideFromMenu { get; private set; }

	public bool RequiresCreativeMode { get; private set; }

	public bool ValidForHighPixelDensity { get; private set; }

	public bool ValidForLowPixelDensity { get; private set; }

	public PaletteEntry[] Entries { get; private set; }

	public Palette(ICoreClientAPI capi, CWPaletteData data, PaletteEntryManager paletteEntryManager)
	{
		HashSet<Block> hashSet = new HashSet<Block>();
		string[] include = data.include;
		foreach (string text in include)
		{
			IEnumerable<Block> enumerable = from block in ((IWorldAccessor)capi.World).SearchBlocks(new AssetLocation(text))
				where IsValidChiselingMaterial(capi, block)
				select block;
			HashsetExtensions.AddRange<Block>(hashSet, enumerable);
		}
		include = data.except;
		foreach (string text2 in include)
		{
			hashSet.ExceptWith(((IWorldAccessor)capi.World).SearchBlocks(new AssetLocation(text2)));
		}
		Entries = paletteEntryManager.CreatePaletteEntriesFromBlocks(hashSet);
		Key = data.key;
		Name = data.name;
		HideFromMenu = data.hideFromMenu;
		RequiresCreativeMode = data.requiresCreativeMode;
		ValidForHighPixelDensity = data.validForHighPixelDensity;
		ValidForLowPixelDensity = data.validForLowPixelDensity;
	}

	public Palette ReduceToSubset(IEnumerable<Block> blocks)
	{
		HashSet<Block> blockSet = blocks.ToHashSet();
		Palette obj = (Palette)MemberwiseClone();
		obj.Entries = Entries.Where((PaletteEntry entry) => blockSet.Contains(entry.Block)).ToArray();
		return obj;
	}

	public PaletteEntry FindBestFitEntry(SKColor colour)
	{

		int num = FindBestFitEntryIndex(colour);
		if (num == -1)
		{
			return null;
		}
		return Entries[num];
	}

	public int FindBestFitEntryIndex(SKColor colour)
	{

		int result = -1;
		double num = double.MaxValue;
		for (int i = 0; i < Entries.Length; i++)
		{
			double num2 = VoxelTexture.CalcColourDistance(Entries[i].AvgBlockColour, colour);
			if (num2 < num)
			{
				num = num2;
				result = i;
			}
		}
		return result;
	}

	public PaletteEntry FindBestFitEntry(SKColor[] colours, int x, int y)
	{
		int num = FindBestFitEntryIndex(colours, x, y);
		if (num == -1)
		{
			return null;
		}
		return Entries[num];
	}

	public int FindBestFitEntryIndex(SKColor[] colours, int x, int y)
	{
		int result = -1;
		double num = double.MaxValue;
		for (int i = 0; i < Entries.Length; i++)
		{
			VoxelTexture voxelTexture = Entries[i].VoxelTextures[x, y];
			if (voxelTexture != null)
			{
				double num2 = voxelTexture.CalcDistance(colours).Sum();
				if (num2 < num)
				{
					num = num2;
					result = i;
				}
			}
		}
		return result;
	}

	public static bool IsValidChiselingMaterial(ICoreClientAPI api, Block block)
	{

		if (block is BlockChisel)
		{
			return false;
		}
		string text = ((IWorldAccessor)api.World).Config.GetString("microblockChiseling", (string)null);
		JsonObject attributes = ((CollectibleObject)block).Attributes;
		bool flag = attributes != null && attributes["canChisel"].Exists;
		JsonObject attributes2 = ((CollectibleObject)block).Attributes;
		bool flag2 = attributes2 != null && attributes2["canChisel"].AsBool(false);
		if (flag2)
		{
			return true;
		}
		if (flag && !flag2)
		{
			return false;
		}
		if ((int)block.DrawType != 10)
		{
			CompositeShape shape = block.Shape;
			if (((shape != null) ? shape.Base.Path : null) != "block/basic/cube")
			{
				return false;
			}
		}
		if (((CollectibleObject)block).HasBehavior<BlockBehaviorDecor>(false))
		{
			return false;
		}
		if ((int)((IPlayer)api.World.Player).WorldData.CurrentGameMode == 2)
		{
			return true;
		}
		if (text == "stonewood")
		{
			if (((RegistryObject)block).Code.Path.Contains("mudbrick"))
			{
				return true;
			}
			if ((int)block.BlockMaterial != 4 && (int)block.BlockMaterial != 6 && (int)block.BlockMaterial != 7)
			{
				return (int)block.BlockMaterial == 15;
			}
			return true;
		}
		return true;
	}

	public void OutputAvgBlockColours()
	{

		PaletteEntry[] entries = Entries;
		foreach (PaletteEntry paletteEntry in entries)
		{
			Console.WriteLine($"{((object)paletteEntry.AvgBlockColour/*cast due to .constrained prefix*/).ToString()} {((RegistryObject)paletteEntry.Block).Code}");
		}
	}
}




