﻿using System;
using System.Collections.Generic;
using System.IO;
using ChiselWiz.Systems.Images.Colouring;
using ChiselWiz.Systems.Images.Designs;
using SkiaSharp;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;

namespace ChiselWiz.Systems.Images;

public class ImageDesignLoader
{
	private ICoreClientAPI capi;

	private Palettes loadedPalettes;

	private AssetLocation paletteLocation;

	public PaletteEntryManager PaletteEntryManager { get; private set; }

	public ImageDesignLoader(ICoreClientAPI capi, AssetLocation paletteLocation)
	{
		this.capi = capi;
		this.paletteLocation = paletteLocation;
		PaletteEntryManager = new PaletteEntryManager(capi);
		capi.Event.LevelFinalize += delegate
		{
			LoadPalettes();
		};
	}

	public static SKBitmap LoadBitmap(string filePath)
	{
		return LoadBitmap(File.ReadAllBytes(filePath));
	}

	public static SKBitmap LoadBitmap(byte[] rawImageData)
	{
		return BitmapExternal.Decode((ReadOnlySpan<byte>)rawImageData.AsSpan().Slice(0, rawImageData.Length));
	}

	public Palettes LoadPalettes(bool forceReload = false)
	{
		if (loadedPalettes == null || forceReload)
		{
			loadedPalettes = Palettes.LoadFrom(capi, paletteLocation, PaletteEntryManager);
		}
		return loadedPalettes;
	}

	public Palette LoadPalette(string key)
	{
		return LoadPalettes().Find((Palette x) => x.Key == key);
	}

	public ImageDesign CreateDesign(SKBitmap bitmap, int voxelWidth, int voxelHeight, EnumPaletteReductionMethod paletteReductionMethod = EnumPaletteReductionMethod.None, Palette masterPalette = null, bool highPixelDensityMode = false)
	{

		int num = voxelWidth;
		int num2 = voxelHeight;
		if (highPixelDensityMode)
		{
			num *= 2;
			num2 *= 2;
		}
		SKBitmap val = ((bitmap.Width == num && bitmap.Height == num2) ? bitmap.Copy() : bitmap.Resize(new SKImageInfo(num, num2), new SKSamplingOptions((SKFilterMode)1, (SKMipmapMode)2)));
		try
		{
			ReduceBitmapColours(val, paletteReductionMethod);
			SKBitmap val2 = (highPixelDensityMode ? val.Copy() : val.Resize(new SKImageInfo(voxelWidth * 2, voxelHeight * 2), new SKSamplingOptions((SKFilterMode)0)));
			try
			{
				SKBitmap val3 = AddBitmapMargins(val2, 32);
				try
				{
					if (paletteReductionMethod == EnumPaletteReductionMethod.BlackWhite)
					{
						string key = (((int)((IPlayer)capi.World.Player).WorldData.CurrentGameMode == 2) ? "bw-creative" : "bw-survival");
						masterPalette = LoadPalette(key);
					}
					if (highPixelDensityMode)
					{
						return new ComplexImageDesign(this, val3, masterPalette);
					}
					return new BasicImageDesign(this, val3, masterPalette);
				}
				finally
				{
					((IDisposable)val3)?.Dispose();
				}
			}
			finally
			{
				((IDisposable)val2)?.Dispose();
			}
		}
		finally
		{
			((IDisposable)val)?.Dispose();
		}
	}

	private SKBitmap AddBitmapMargins(SKBitmap bmp, int lengthMultiple)
	{

		int num = RoundUpNextIncrement(bmp.Width, lengthMultiple);
		int num2 = RoundUpNextIncrement(bmp.Height, lengthMultiple);
		int num3 = (num - bmp.Width) / 2;
		int num4 = (num2 - bmp.Height) / 2;
		SKBitmap val = new SKBitmap(num, num2, false);
		SKCanvas val2 = new SKCanvas(val);
		try
		{
			val2.DrawBitmap(bmp, (float)num3, (float)num4, (SKPaint)null);
			return val;
		}
		finally
		{
			((IDisposable)val2)?.Dispose();
		}
	}

	private int RoundUpNextIncrement(int num, int multiple)
	{
		return (int)(Math.Ceiling((double)num / (double)multiple) * (double)multiple);
	}

	private void ReduceBitmapColours(SKBitmap bitmap, EnumPaletteReductionMethod paletteReductionMethod)
	{
		if (paletteReductionMethod != EnumPaletteReductionMethod.None && paletteReductionMethod == EnumPaletteReductionMethod.BlackWhite)
		{
			QuantizeBitmapColours1Bit(ref bitmap);
		}
		else
		{
			QuantizeBitmapTransparency(ref bitmap);
		}
	}

	private void QuantizeBitmapTransparency(ref SKBitmap bitmap)
	{

		for (int i = 0; i < bitmap.Width; i++)
		{
			for (int j = 0; j < bitmap.Height; j++)
			{
				SKColor pixel = bitmap.GetPixel(i, j);
				bool flag = pixel.Alpha < 128;
				bitmap.SetPixel(i, j, new SKColor(pixel.Red, pixel.Green, pixel.Blue, (byte)((!flag) ? 255u : 0u)));
			}
		}
	}

	private void QuantizeBitmapColours1Bit(ref SKBitmap bitmap)
	{

		new List<int>();
		_ = new int[bitmap.Width, bitmap.Height];
		ColorUtil.ColorFromRgba(0, 0, 0, 255);
		ColorUtil.ColorFromRgba(255, 255, 255, 255);
		for (int i = 0; i < bitmap.Width; i++)
		{
			for (int j = 0; j < bitmap.Height; j++)
			{
				SKColor pixel = bitmap.GetPixel(i, j);
				bool flag = pixel.Alpha < 128;
				byte b = (byte)(((int)((double)(int)pixel.Red * 0.299 + (double)(int)pixel.Green * 0.587 + (double)(int)pixel.Blue * 0.114) >= 128) ? 255u : 0u);
				bitmap.SetPixel(i, j, new SKColor(b, b, b, (byte)((!flag) ? 255u : 0u)));
			}
		}
	}
}




