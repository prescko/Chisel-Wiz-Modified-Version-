﻿using System;
using ChiselWiz.Systems.Blueprints;

namespace ChiselWiz.Systems.Catalogues;

internal class ChiselWizCatalogueDesignData
{
	public string name;

	public DateTime dateAdded;

	public BlockBlueprintData blueprintData;

	public CatalogueDesign Unserialize()
	{
		BlockBlueprint blockBlueprint = BlockBlueprint.Unserialize(blueprintData);
		blockBlueprint.SimplifyMaterials();
		return new CatalogueDesign(name, dateAdded, blockBlueprint);
	}

	public static ChiselWizCatalogueDesignData Serialize(CatalogueDesign design)
	{
		return new ChiselWizCatalogueDesignData
		{
			name = design.Name,
			dateAdded = design.DateAdded,
			blueprintData = design.Blueprint.Serialize()
		};
	}
}




