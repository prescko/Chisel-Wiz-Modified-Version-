﻿using System;
using System.Collections.Generic;
using System.Linq;
using Vintagestory.API.Client;

namespace ChiselWiz.Systems.Catalogues;

public class CatalogueCollection : List<ICatalogue>
{
	public GuiTab[] CreateGuiTabs()
	{
		return ((IEnumerable<ICatalogue>)this).Select((Func<ICatalogue, int, GuiTab>)((ICatalogue catalogue, int idx) => new GuiTab
		{
			Name = catalogue.Name,
			DataInt = idx
		})).ToArray();
	}
}




