﻿using System.Collections.Generic;

namespace ChiselWiz.Systems.Catalogues;

internal class ChiselWizCatalogueData
{
	public int version = 1;

	public List<ChiselWizCatalogueDesignData> designs = new List<ChiselWizCatalogueDesignData>();
}




