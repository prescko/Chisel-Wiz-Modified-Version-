﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;
using ChiselWiz.Systems.Blueprints;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;
using Vintagestory.API.Util;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems.Catalogues;

public class ChiselToolsPortfolioCatalogue : ICatalogue
{
	private ICoreClientAPI capi;

	private string portfolioPath;

	private List<CatalogueDesign> designs = new List<CatalogueDesign>();

	private static readonly string[] substituteBlockCodes = new string[10] { "game:creativeblock-79", "game:creativeblock-64", "game:creativeblock-32", "game:creativeblock-35", "game:creativeblock-37", "game:creativeblock-19", "game:creativeblock-9", "game:creativeblock-58", "game:creativeblock-73", "game:creativeblock-70" };

	public string Name => Lang.Get("chiselwiz:Chisel Tools Portfolio", Array.Empty<object>());

	public List<CatalogueDesign> Designs => designs;

	public bool CanRename => false;

	public bool CanDelete => false;

	public ChiselToolsPortfolioCatalogue(ICoreClientAPI capi, string portfolioPath)
	{
		this.capi = capi;
		this.portfolioPath = portfolioPath;
	}

	public static ChiselToolsPortfolioCatalogue TryLoadFrom(ICoreClientAPI capi, string portfolioPath)
	{
		if (!Directory.Exists(Path.Combine(GamePaths.DataPath, portfolioPath)))
		{
			return null;
		}
		ChiselToolsPortfolioCatalogue chiselToolsPortfolioCatalogue = new ChiselToolsPortfolioCatalogue(capi, portfolioPath);
		if (!chiselToolsPortfolioCatalogue.TryLoad())
		{
			return null;
		}
		return chiselToolsPortfolioCatalogue;
	}

	public bool AddDesign(CatalogueDesign design)
	{
		throw new NotImplementedException();
	}

	public bool AddDesign(string name, BlockBlueprint blueprint)
	{
		throw new NotImplementedException();
	}

	public bool AddDesigns(IEnumerable<CatalogueDesign> designs)
	{
		throw new NotImplementedException();
	}

	public bool DeleteDesign(CatalogueDesign design)
	{
		throw new NotImplementedException();
	}

	public bool RenameDesign(CatalogueDesign design, string newName)
	{
		throw new NotImplementedException();
	}

	public bool TryLoad()
	{
		try
		{
			string path = Path.Combine(GamePaths.DataPath, portfolioPath);
			if (!Directory.Exists(path))
			{
				return false;
			}
			foreach (string item2 in Directory.GetFiles(path, "*").ToList())
			{
				try
				{
					BlockBlueprint blockBlueprint = ReadChiselToolsBlueprint(item2);
					Path.GetFileNameWithoutExtension(item2);
					DateTime lastWriteTime = File.GetLastWriteTime(item2);
					if (blockBlueprint != null && !blockBlueprint.IsVoid)
					{
						CatalogueDesign item = new CatalogueDesign(blockBlueprint.Name, lastWriteTime, blockBlueprint);
						designs.Add(item);
					}
				}
				catch (Exception ex)
				{
					((ICoreAPI)capi).Logger.Warning("Unable to read Chisel Tools design from " + item2 + ": " + ex.Message);
				}
			}
			return true;
		}
		catch (Exception ex2)
		{
			((ICoreAPI)capi).Logger.Error(ex2);
			return false;
		}
	}

	public bool TrySave()
	{
		return false;
	}

	private static BlockBlueprint ReadChiselToolsBlueprint(string filename)
	{

		XmlSerializer xmlSerializer = new XmlSerializer(typeof(PantographData));
		PantographData pantographData;
		using (StreamReader textReader = new StreamReader(filename))
		{
			pantographData = (PantographData)xmlSerializer.Deserialize(textReader);
		}
		BlockBlueprint blockBlueprint = new BlockBlueprint();
		blockBlueprint.Name = pantographData.name;
		if (pantographData.blockcodes != null)
		{
			blockBlueprint.MaterialCodes.AddRange(pantographData.blockcodes);
		}
		BoolArray16x16x16 val = default(BoolArray16x16x16);
		byte[,,] array = default(byte[,,]);
		new BlockEntityMicroBlock
		{
			VoxelCuboids = SerializerUtil.Deserialize<List<uint>>(pantographData.voxeldata)
		}.ConvertToVoxels(out val, out array);
		byte b = 0;
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (val[i, j, k])
					{
						b = Math.Max(b, array[i, j, k]);
					}
					else
					{
						array[i, j, k] = 0;
					}
				}
			}
		}
		for (int l = blockBlueprint.MaterialCodes.Count; l <= b; l++)
		{
			string item = substituteBlockCodes[l % substituteBlockCodes.Length];
			blockBlueprint.MaterialCodes.Add(item);
		}
		blockBlueprint.Voxels = val;
		blockBlueprint.Materials = array;
		blockBlueprint.SimplifyMaterials();
		return blockBlueprint;
	}
}




