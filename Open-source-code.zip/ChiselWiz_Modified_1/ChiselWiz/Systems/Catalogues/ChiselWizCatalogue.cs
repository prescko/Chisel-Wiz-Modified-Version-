﻿using System;
using System.Collections.Generic;
using ChiselWiz.Systems.Blueprints;
using Newtonsoft.Json;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Config;

namespace ChiselWiz.Systems.Catalogues;

public class ChiselWizCatalogue : ICatalogue
{
	private ICoreClientAPI capi;

	private string filename;

	private ChiselWizCatalogueData data;

	private List<CatalogueDesign> designs = new List<CatalogueDesign>();

	private Dictionary<CatalogueDesign, ChiselWizCatalogueDesignData> designsDataMap;

	public string Name => Lang.Get("chiselwiz:Chisel Wiz Design Catalogue", Array.Empty<object>());

	public List<CatalogueDesign> Designs => designs;

	public bool CanRename => true;

	public bool CanDelete => true;

	public ChiselWizCatalogue(ICoreClientAPI capi, string filename)
	{
		this.capi = capi;
		this.filename = filename;
		designsDataMap = new Dictionary<CatalogueDesign, ChiselWizCatalogueDesignData>();
	}

	private ChiselWizCatalogueData LoadCatalogueData(AssetLocation loc)
	{
		IAsset val = ((ICoreAPI)capi).Assets.Get(loc);
		if (val != null)
		{
			return JsonConvert.DeserializeObject<ChiselWizCatalogueData>(val.ToText());
		}
		return null;
	}

	public bool TryLoad()
	{

		ChiselWizCatalogueData chiselWizCatalogueData = null;
		try
		{
			chiselWizCatalogueData = ((ICoreAPICommon)capi).LoadModConfig<ChiselWizCatalogueData>(filename);
			if (chiselWizCatalogueData == null)
			{
				chiselWizCatalogueData = LoadCatalogueData(new AssetLocation("chiselwiz", "config/default-catalogue.json"));
				if (chiselWizCatalogueData == null)
				{
					throw new Exception("Catalogue file empty or not found");
				}
			}
			designs.Clear();
			foreach (ChiselWizCatalogueDesignData design in chiselWizCatalogueData.designs)
			{
				CatalogueDesign catalogueDesign = design.Unserialize();
				designs.Add(catalogueDesign);
				designsDataMap[catalogueDesign] = design;
			}
			((ICoreAPI)capi).Logger.Notification($"Loaded {chiselWizCatalogueData.designs.Count} designs from Chisel Wiz catalogue");
		}
		catch (Exception ex)
		{
			chiselWizCatalogueData = new ChiselWizCatalogueData();
			((ICoreAPI)capi).Logger.Error(ex);
			return false;
		}
		data = chiselWizCatalogueData;
		return true;
	}

	public bool TrySave()
	{
		try
		{
			((ICoreAPICommon)capi).StoreModConfig<ChiselWizCatalogueData>(data, filename);
			return true;
		}
		catch (Exception ex)
		{
			((ICoreAPI)capi).Logger.Error(ex);
			return false;
		}
	}

	public bool AddDesign(string name, BlockBlueprint blueprint)
	{
		CatalogueDesign design = new CatalogueDesign(name, DateTime.Now, blueprint.Clone());
		return AddDesign(design);
	}

	public bool AddDesign(CatalogueDesign design)
	{
		return AddDesigns(new CatalogueDesign[1] { design });
	}

	public bool RenameDesign(CatalogueDesign design, string newName)
	{
		designsDataMap.TryGetValue(design, out var value);
		if (value != null)
		{
			design.Name = newName;
			value.name = newName;
		}
		return TrySave();
	}

	public bool AddDesigns(IEnumerable<CatalogueDesign> designs)
	{
		this.designs.AddRange(designs);
		foreach (CatalogueDesign design in designs)
		{
			ChiselWizCatalogueDesignData chiselWizCatalogueDesignData = ChiselWizCatalogueDesignData.Serialize(design);
			data.designs.Add(chiselWizCatalogueDesignData);
			designsDataMap[design] = chiselWizCatalogueDesignData;
		}
		return TrySave();
	}

	public bool DeleteDesign(CatalogueDesign design)
	{
		designsDataMap.TryGetValue(design, out var value);
		if (value != null)
		{
			data.designs.Remove(value);
		}
		designs.Remove(design);
		return TrySave();
	}
}




