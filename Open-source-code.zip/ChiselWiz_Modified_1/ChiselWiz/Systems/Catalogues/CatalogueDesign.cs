﻿using System;
using ChiselWiz.Systems.Blueprints;

namespace ChiselWiz.Systems.Catalogues;

public class CatalogueDesign
{
	private string name;

	private DateTime dateAdded;

	private BlockBlueprint blueprint;

	public string Name
	{
		get
		{
			return name;
		}
		set
		{
			name = value;
		}
	}

	public DateTime DateAdded
	{
		get
		{
			return dateAdded;
		}
		set
		{
			dateAdded = value;
		}
	}

	public BlockBlueprint Blueprint => blueprint;

	public CatalogueDesign(string name, DateTime dateAdded, BlockBlueprint blueprint)
	{
		this.name = name;
		this.dateAdded = dateAdded;
		this.blueprint = blueprint;
	}
}




