﻿using System.Collections.Generic;
using ChiselWiz.Systems.Blueprints;

namespace ChiselWiz.Systems.Catalogues;

public interface ICatalogue
{
	string Name { get; }

	List<CatalogueDesign> Designs { get; }

	bool CanRename { get; }

	bool CanDelete { get; }

	bool TryLoad();

	bool TrySave();

	bool RenameDesign(CatalogueDesign design, string newName);

	bool AddDesign(CatalogueDesign design);

	bool AddDesign(string name, BlockBlueprint blueprint);

	bool AddDesigns(IEnumerable<CatalogueDesign> designs);

	bool DeleteDesign(CatalogueDesign design);
}




