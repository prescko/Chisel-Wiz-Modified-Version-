﻿using System.Xml.Serialization;

namespace ChiselWiz.Systems.Catalogues;

[XmlRoot("PantographData")]
public class PantographData
{
	public string name;

	public byte[] voxeldata;

	public byte[] matdata;

	public string[] blockcodes;

	public bool materialPasteOK;
}




