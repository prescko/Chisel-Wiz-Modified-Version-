﻿using System;
using Vintagestory.API.Client;
using Vintagestory.API.Config;

namespace ChiselWiz.Systems;

public class VSException : Exception
{
	public object[] langArgs;

	private string localeMsg()
	{
		if (langArgs != null)
		{
			return Lang.Get(Message, langArgs);
		}
		return Lang.Get(Message, Array.Empty<object>());
	}

	public VSException(string code)
		: base(code)
	{
	}

	public VSException(string code, object[] args)
		: base(code)
	{
		langArgs = args;
	}

	public void DisplayError(ICoreClientAPI capi)
	{
		capi.TriggerIngameError((object)this, "chiselwiz-error", localeMsg());
	}

	public void DisplayChat(ICoreClientAPI capi)
	{
		capi.ShowChatMessage(localeMsg());
	}
}




