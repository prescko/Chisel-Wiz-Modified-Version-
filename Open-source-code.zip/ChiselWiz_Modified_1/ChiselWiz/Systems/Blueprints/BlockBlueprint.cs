﻿using System;
using System.Collections.Generic;
using System.IO;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems.Blueprints;

public class BlockBlueprint
{
	private class RotationTransform
	{
		public int HRots { get; set; }

		public int VRots { get; set; }

		public int XRots { get; set; }
	}

	private BoolArray16x16x16 voxels = new BoolArray16x16x16();

	private byte[,,] materials = new byte[16, 16, 16];

	public BoolArray16x16x16 Voxels
	{
		get
		{
			return voxels;
		}
		set
		{
			voxels = value;
		}
	}

	public byte[,,] Materials
	{
		get
		{
			return materials;
		}
		set
		{
			materials = value;
		}
	}

	public string Name { get; set; } = "";

	public bool SetNameOnPaste { get; set; } = true;

	public List<string> MaterialCodes { get; } = new List<string>();

	public string Description
	{
		get
		{
			using StringReader stringReader = new StringReader(Name ?? "");
			string text = stringReader.ReadLine() ?? "";
			return ((text.Length > 0) ? ("Name=" + text + ", ") : "") + "Materials=[" + string.Join(", ", MaterialCodes) + "]";
		}
	}

	public bool IsVoid
	{
		get
		{
			for (int i = 0; i < 16; i++)
			{
				for (int j = 0; j < 16; j++)
				{
					for (int k = 0; k < 16; k++)
					{
						if (voxels[i, j, k])
						{
							return false;
						}
					}
				}
			}
			return true;
		}
	}

	public override string ToString()
	{
		return "BlockBlueprint(" + Description + ")";
	}

	public BlockBlueprint()
	{
	}

	public BlockBlueprint(BlockEntityMicroBlock beChisel, bool copyVoxels = true)
	{

		Name = beChisel.BlockName;
		if (copyVoxels)
		{
			beChisel.ConvertToVoxels(out voxels, out materials);
		}
		int[] blockIds = beChisel.BlockIds;
		foreach (int index in blockIds)
		{
			AssetLocation code = ((RegistryObject)((BlockEntity)beChisel).Api.World.Blocks[index]).Code;
			MaterialCodes.Add(code.ToString());
		}
	}

	public static BlockBlueprint FromItemStack(ICoreClientAPI capi, ItemStack stack)
	{
		return new BlockBlueprint((BlockEntityMicroBlock)(object)DummyBlockEntityChisel.FromItemStack(capi, stack));
	}

	public BlockBlueprint(BlockBlueprint toClone, bool copyVoxels = true)
	{

		if (copyVoxels)
		{
			for (int i = 0; i < 16; i++)
			{
				for (int j = 0; j < 16; j++)
				{
					for (int k = 0; k < 16; k++)
					{
						Voxels[i, j, k] = toClone.Voxels[i, j, k];
					}
				}
			}
			Materials = (byte[,,])toClone.Materials.Clone();
		}
		MaterialCodes.AddRange(toClone.MaterialCodes);
		Name = toClone.Name;
		SetNameOnPaste = toClone.SetNameOnPaste;
	}

	public BlockBlueprint Clone()
	{
		return new BlockBlueprint(this);
	}

	public BlockBlueprint CloneEmpty()
	{
		return new BlockBlueprint(this, copyVoxels: false);
	}

	public BlockBlueprintData Serialize()
	{
		return BlockBlueprintData.FromBlockBlueprint(this);
	}

	public static BlockBlueprint Unserialize(BlockBlueprintData bpd)
	{
		return bpd.ToBlockBlueprint();
	}

	public void MatMergeDesign(BlockBlueprint bp)
	{
		foreach (string materialCode in bp.MaterialCodes)
		{
			if (!MaterialCodes.Contains(materialCode))
			{
				MaterialCodes.Add(materialCode);
			}
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					byte index = bp.materials[i, j, k];
					bool flag = bp.voxels[i, j, k];
					if (flag)
					{
						voxels[i, j, k] = flag;
						string item = bp.MaterialCodes[index];
						int num = MaterialCodes.IndexOf(item);
						materials[i, j, k] = (byte)num;
					}
				}
			}
		}
		SimplifyMaterials();
	}

	public void BoolOp(BlockBlueprint bp, BoolOpEnum op, int materialIdx = 0)
	{
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					bool flag = voxels[i, j, k];
					bool flag2 = bp.Voxels[i, j, k];
					switch (op)
					{
					case BoolOpEnum.Add:
						if (!flag && flag2)
						{
							voxels[i, j, k] = true;
							materials[i, j, k] = (byte)materialIdx;
						}
						break;
					case BoolOpEnum.Subtract:
						if (flag && flag2)
						{
							voxels[i, j, k] = false;
						}
						break;
					}
				}
			}
		}
		SimplifyMaterials();
	}

	public void MergeDesign(BlockBlueprint bp, bool addMissingVoxels, bool replaceOverlappingVoxels, bool removeExtraVoxels)
	{
		if (addMissingVoxels || replaceOverlappingVoxels)
		{
			foreach (string materialCode in bp.MaterialCodes)
			{
				if (!MaterialCodes.Contains(materialCode))
				{
					MaterialCodes.Add(materialCode);
				}
			}
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					bool flag = voxels[i, j, k];
					bool flag2 = bp.Voxels[i, j, k];
					byte index = bp.Materials[i, j, k];
					if (addMissingVoxels && !flag && flag2)
					{
						voxels[i, j, k] = flag2;
						string item = bp.MaterialCodes[index];
						int num = MaterialCodes.IndexOf(item);
						materials[i, j, k] = (byte)num;
					}
					if (replaceOverlappingVoxels && flag && flag2)
					{
						string item2 = bp.MaterialCodes[index];
						int num2 = MaterialCodes.IndexOf(item2);
						materials[i, j, k] = (byte)num2;
					}
					if (removeExtraVoxels && flag && !flag2)
					{
						voxels[i, j, k] = flag2;
					}
				}
			}
		}
		SimplifyMaterials();
	}

	public void VFlip()
	{
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					blockBlueprint.Voxels[i, 16 - j - 1, k] = voxels[i, j, k];
					blockBlueprint.Materials[i, 16 - j - 1, k] = materials[i, j, k];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
	}

	public void HFlip()
	{
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					blockBlueprint.Voxels[15 - i, j, k] = voxels[i, j, k];
					blockBlueprint.Materials[15 - i, j, k] = materials[i, j, k];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
	}

	public void MirrorH(Vec3i voxelPos, BlockFacing facing)
	{
		RotationTransform rotationToSouth = GetRotationToSouth(facing);
		ApplyRotation(rotationToSouth);
		if (TransformPos(voxelPos, rotationToSouth).X < 8)
		{
			for (int i = 0; i < 8; i++)
			{
				for (int j = 0; j < 16; j++)
				{
					for (int k = 0; k < 16; k++)
					{
						Voxels[15 - i, j, k] = Voxels[i, j, k];
						Materials[15 - i, j, k] = Materials[i, j, k];
					}
				}
			}
		}
		else
		{
			for (int l = 8; l < 16; l++)
			{
				for (int m = 0; m < 16; m++)
				{
					for (int n = 0; n < 16; n++)
					{
						Voxels[15 - l, m, n] = Voxels[l, m, n];
						Materials[15 - l, m, n] = Materials[l, m, n];
					}
				}
			}
		}
		ApplyRotation(GetInverseRotation(rotationToSouth));
	}

	public void MirrorV(Vec3i voxelPos)
	{
		if (voxelPos.Y < 8)
		{
			for (int i = 0; i < 16; i++)
			{
				for (int j = 0; j < 8; j++)
				{
					for (int k = 0; k < 16; k++)
					{
						Voxels[i, 15 - j, k] = Voxels[i, j, k];
						Materials[i, 15 - j, k] = Materials[i, j, k];
					}
				}
			}
			return;
		}
		for (int l = 0; l < 16; l++)
		{
			for (int m = 8; m < 16; m++)
			{
				for (int n = 0; n < 16; n++)
				{
					Voxels[l, 15 - m, n] = Voxels[l, m, n];
					Materials[l, 15 - m, n] = Materials[l, m, n];
				}
			}
		}
	}

	public void XAxisRot()
	{
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					blockBlueprint.Voxels[i, 15 - k, j] = voxels[i, j, k];
					blockBlueprint.Materials[i, 15 - k, j] = materials[i, j, k];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
	}

	public void ZAxisRot()
	{
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					blockBlueprint.Voxels[j, 15 - i, k] = voxels[i, j, k];
					blockBlueprint.Materials[j, 15 - i, k] = materials[i, j, k];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
	}

	public void YAxisRot()
	{
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					blockBlueprint.Voxels[15 - i, j, k] = voxels[k, j, i];
					blockBlueprint.Materials[15 - i, j, k] = materials[k, j, i];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
	}

	public void VRot(BlockFacing facing)
	{
		RotationTransform rotationToSouth = GetRotationToSouth(facing);
		ApplyRotation(rotationToSouth);
		ZAxisRot();
		ApplyRotation(GetInverseRotation(rotationToSouth));
	}

	public void Invert()
	{
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					voxels[i, j, k] = !voxels[i, j, k];
				}
			}
		}
		SimplifyMaterials();
	}

	public void Reset(byte materialIdx = 0)
	{
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					voxels[i, j, k] = true;
					materials[i, j, k] = materialIdx;
				}
			}
		}
	}

	public void PushVoxels(int distance, BlockFacing facing)
	{

		BlockBlueprint blockBlueprint = CloneEmpty();
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		if (facing.Negative)
		{
			distance = -distance;
		}
		EnumAxis axis = facing.Axis;
		switch ((int)axis)
		{
		case 0:
			num = distance;
			break;
		case 1:
			num2 = distance;
			break;
		case 2:
			num3 = distance;
			break;
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num4 = i + num;
					int num5 = j + num2;
					int num6 = k + num3;
					if (num4 >= 0 && num4 < 16 && num5 >= 0 && num5 < 16 && num6 >= 0 && num6 < 16)
					{
						blockBlueprint.Voxels[num4, num5, num6] = voxels[i, j, k];
						blockBlueprint.Materials[num4, num5, num6] = materials[i, j, k];
					}
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
		SimplifyMaterials();
	}

	public void PushVoxelsWrapping(int distance, BlockFacing facing)
	{
		RotationTransform rotationToSouth = GetRotationToSouth(facing);
		ApplyRotation(rotationToSouth);
		BlockBlueprint blockBlueprint = CloneEmpty();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num = (k + distance) % 16;
					if (num < 0)
					{
						num += 16;
					}
					blockBlueprint.Voxels[i, j, num] = voxels[i, j, k];
					blockBlueprint.Materials[i, j, num] = materials[i, j, k];
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
		ApplyRotation(GetInverseRotation(rotationToSouth));
		SimplifyMaterials();
	}

	public void ShaveVoxels(int distance, BlockFacing facing)
	{
		RotationTransform rotationToSouth = GetRotationToSouth(facing);
		ApplyRotation(rotationToSouth);
		BlockBlueprint blockBlueprint = CloneEmpty();
		if (distance < 0)
		{
			int num = -distance;
			int num2 = -1;
			for (int i = 0; i < 16; i++)
			{
				for (int j = 0; j < 16; j++)
				{
					for (int k = 0; k < 16; k++)
					{
						if (voxels[i, j, k])
						{
							num2 = Math.Max(num2, k);
						}
					}
				}
			}
			if (num2 > -1)
			{
				int num3 = num2 - num;
				for (int l = 0; l < 16; l++)
				{
					for (int m = 0; m < 16; m++)
					{
						for (int n = 0; n < 16; n++)
						{
							if (n <= num3)
							{
								blockBlueprint.Voxels[l, m, n] = voxels[l, m, n];
								blockBlueprint.Materials[l, m, n] = materials[l, m, n];
							}
						}
					}
				}
			}
		}
		else
		{
			int num4 = 16;
			for (int num5 = 0; num5 < 16; num5++)
			{
				for (int num6 = 0; num6 < 16; num6++)
				{
					for (int num7 = 0; num7 < 16; num7++)
					{
						if (voxels[num5, num6, num7])
						{
							num4 = Math.Min(num4, num7);
						}
					}
				}
			}
			if (num4 < 16)
			{
				int num8 = num4 + distance;
				for (int num9 = 0; num9 < 16; num9++)
				{
					for (int num10 = 0; num10 < 16; num10++)
					{
						for (int num11 = 0; num11 < 16; num11++)
						{
							if (num11 >= num8)
							{
								blockBlueprint.Voxels[num9, num10, num11] = voxels[num9, num10, num11];
								blockBlueprint.Materials[num9, num10, num11] = materials[num9, num10, num11];
							}
						}
					}
				}
			}
		}
		voxels = blockBlueprint.Voxels;
		materials = blockBlueprint.Materials;
		ApplyRotation(GetInverseRotation(rotationToSouth));
		SimplifyMaterials();
	}

	public void SwapMaterials(int mat1, int mat2)
	{
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (Voxels[i, j, k])
					{
						int num = materials[i, j, k];
						if (num == mat1)
						{
							num = mat2;
						}
						else if (num == mat2)
						{
							num = mat1;
						}
						materials[i, j, k] = (byte)num;
					}
				}
			}
		}
	}

	public void Paint(Vec3i voxelPos, string newMaterialCode)
	{
		byte b = materials[voxelPos.X, voxelPos.Y, voxelPos.Z];
		int num = MaterialCodes.IndexOf(newMaterialCode);
		if (num == -1)
		{
			MaterialCodes.Add(newMaterialCode);
			num = MaterialCodes.Count - 1;
		}
		if (b == num)
		{
			return;
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (materials[i, j, k] == b)
					{
						materials[i, j, k] = (byte)num;
					}
				}
			}
		}
		SimplifyMaterials();
	}

	public void PaintContiguous(Vec3i startVoxel, string newMaterialCode)
	{

		if (!voxels[startVoxel.X, startVoxel.Y, startVoxel.Z])
		{
			return;
		}
		byte b = materials[startVoxel.X, startVoxel.Y, startVoxel.Z];
		int num = MaterialCodes.IndexOf(newMaterialCode);
		if (num == -1)
		{
			MaterialCodes.Add(newMaterialCode);
			num = MaterialCodes.Count - 1;
		}
		if (b == num)
		{
			return;
		}
		Queue<Vec3i> queue = new Queue<Vec3i>();
		queue.Enqueue(startVoxel);
		bool[,,] array = new bool[16, 16, 16];
		while (queue.Count > 0)
		{
			Vec3i val = queue.Dequeue();
			if (val.X < 0 || val.X >= 16 || val.Y < 0 || val.Y >= 16 || val.Z < 0 || val.Z >= 16 || array[val.X, val.Y, val.Z])
			{
				continue;
			}
			array[val.X, val.Y, val.Z] = true;
			if (!voxels[val.X, val.Y, val.Z] || materials[val.X, val.Y, val.Z] != b)
			{
				continue;
			}
			materials[val.X, val.Y, val.Z] = (byte)num;
			for (int i = -1; i <= 1; i++)
			{
				for (int j = -1; j <= 1; j++)
				{
					for (int k = -1; k <= 1; k++)
					{
						if (i != 0 || j != 0 || k != 0)
						{
							queue.Enqueue(new Vec3i(val.X + i, val.Y + j, val.Z + k));
						}
					}
				}
			}
		}
		SimplifyMaterials();
	}

	public int CountOccupiedLayersBackToFront(BlockFacing facing)
	{
		RotationTransform rotationToSouth = GetRotationToSouth(facing);
		ApplyRotation(rotationToSouth);
		int num = -1;
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (voxels[i, j, k])
					{
						num = Math.Max(num, k);
					}
				}
			}
		}
		ApplyRotation(GetInverseRotation(rotationToSouth));
		return num;
	}

	public void CopyLayer(int sourceZ, int destinationZ)
	{
		if (sourceZ < 0 || sourceZ > 15 || destinationZ < 0 || destinationZ > 15 || sourceZ == destinationZ)
		{
			return;
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				voxels[i, j, destinationZ] = voxels[i, j, sourceZ];
				materials[i, j, destinationZ] = materials[i, j, sourceZ];
			}
		}
		SimplifyMaterials();
	}

	public void SimplifyMaterials()
	{
		RemoveDuplicateMaterials();
		RemoveUnusedMaterials();
	}

	public void RemoveUnusedMaterials()
	{
		HashSet<string> hashSet = new HashSet<string>();
		foreach (string materialCode in MaterialCodes)
		{
			if (!IsMaterialUsed(materialCode))
			{
				hashSet.Add(materialCode);
			}
		}
		foreach (string item in hashSet)
		{
			RemoveMaterial(item);
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (!voxels[i, j, k])
					{
						materials[i, j, k] = 0;
					}
				}
			}
		}
	}

	public void RemoveDuplicateMaterials()
	{
		List<string> list = new List<string>();
		Dictionary<byte, byte> dictionary = new Dictionary<byte, byte>();
		for (int i = 0; i < MaterialCodes.Count; i++)
		{
			string item = MaterialCodes[i];
			if (!list.Contains(item))
			{
				byte value = (byte)list.Count;
				list.Add(item);
				dictionary[(byte)i] = value;
			}
			else
			{
				dictionary[(byte)i] = (byte)list.IndexOf(item);
			}
		}
		for (int j = 0; j < 16; j++)
		{
			for (int k = 0; k < 16; k++)
			{
				for (int l = 0; l < 16; l++)
				{
					materials[j, k, l] = dictionary[materials[j, k, l]];
				}
			}
		}
		MaterialCodes.Clear();
		MaterialCodes.AddRange(list);
	}

	private static RotationTransform GetRotationToSouth(BlockFacing facing)
	{

		int hRots = 0;
		int vRots = 0;
		int xRots = 0;
		EnumAxis axis = facing.Axis;
		switch ((int)axis)
		{
		case 0:
			hRots = ((!facing.Negative) ? 1 : 3);
			break;
		case 1:
			xRots = ((!facing.Negative) ? 1 : 3);
			break;
		case 2:
			hRots = (facing.Negative ? 2 : 0);
			break;
		}
		return new RotationTransform
		{
			HRots = hRots,
			VRots = vRots,
			XRots = xRots
		};
	}

	private static RotationTransform GetInverseRotation(RotationTransform transform)
	{
		return new RotationTransform
		{
			HRots = (4 - transform.HRots) % 4,
			VRots = (4 - transform.VRots) % 4,
			XRots = (4 - transform.XRots) % 4
		};
	}

	private void ApplyRotation(RotationTransform transform)
	{
		for (int i = 0; i < transform.HRots; i++)
		{
			YAxisRot();
		}
		for (int j = 0; j < transform.VRots; j++)
		{
			ZAxisRot();
		}
		for (int k = 0; k < transform.XRots; k++)
		{
			XAxisRot();
		}
	}

	private static Vec3i TransformPos(Vec3i pos, RotationTransform transform)
	{

		Vec3f val = new Vec3f((float)pos.X, (float)pos.Y, (float)pos.Z);
		for (int i = 0; i < transform.HRots; i++)
		{
			val = new Vec3f(15f - val.Z, val.Y, val.X);
		}
		for (int j = 0; j < transform.VRots; j++)
		{
			val = new Vec3f(15f - val.Y, val.X, val.Z);
		}
		for (int k = 0; k < transform.XRots; k++)
		{
			val = new Vec3f(val.X, 15f - val.Z, val.Y);
		}
		return new Vec3i((int)val.X, (int)val.Y, (int)val.Z);
	}

	public void RemoveMaterial(string code)
	{
		int num = MaterialCodes.IndexOf(code);
		if (num == -1)
		{
			return;
		}
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num2 = materials[i, j, k];
					if (num2 >= num)
					{
						materials[i, j, k] = (byte)(num2 - 1);
					}
				}
			}
		}
		MaterialCodes.RemoveAt(num);
	}

	public bool IsMaterialUsed(string blockCode)
	{
		int num = MaterialCodes.IndexOf(blockCode);
		if (num == -1)
		{
			return false;
		}
		bool result = false;
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (voxels[i, j, k] && materials[i, j, k] == num)
					{
						result = true;
						break;
					}
				}
			}
		}
		return result;
	}

	public BlockBlueprint RemapToPalette(BlockBlueprint targetPaletteProvider)
	{
		BlockBlueprint blockBlueprint = Clone();
		blockBlueprint.MaterialCodes.Clear();
		blockBlueprint.MaterialCodes.AddRange(targetPaletteProvider.MaterialCodes);
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		for (int i = 0; i < MaterialCodes.Count; i++)
		{
			dictionary[i] = targetPaletteProvider.MaterialCodes.IndexOf(MaterialCodes[i]);
		}
		byte[,,] array = new byte[16, 16, 16];
		for (int j = 0; j < 16; j++)
		{
			for (int k = 0; k < 16; k++)
			{
				for (int l = 0; l < 16; l++)
				{
					if (blockBlueprint.Voxels[j, k, l])
					{
						byte key = Materials[j, k, l];
						int num = dictionary[key];
						if (num >= 0)
						{
							array[j, k, l] = (byte)num;
						}
					}
				}
			}
		}
		blockBlueprint.Materials = array;
		return blockBlueprint;
	}

	public DummyBlockEntityChisel ToDummyBlockEntityChisel(ICoreClientAPI capi)
	{
		return DummyBlockEntityChisel.FromBlockBlueprint(capi, this);
	}

	public ItemStack ToDummyItemStack(ICoreClientAPI capi)
	{
		return ToDummyBlockEntityChisel(capi).ToItemStack();
	}
}




