﻿namespace ChiselWiz.Systems.Blueprints;

public enum BoolOpEnum
{
	Add = 1,
	Subtract
}




