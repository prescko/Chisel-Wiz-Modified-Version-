﻿using System;
using System.IO;
using System.IO.Compression;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems.Blueprints;

public class BlockBlueprintData
{
	public string name = "";

	public string voxels = "";

	public string materials = "";

	public string[] materialCodes = Array.Empty<string>();

	public override string ToString()
	{
		return $"BlockBlueprintData: \"{name}\", MaterialCount={materialCodes.Length}";
	}

	private static int FlattenIndex(int x, int y, int z)
	{
		return x + y * 16 + z * 256;
	}

	private static byte[] PackMaterialArray(byte[,,] materials)
	{
		byte[] array = new byte[4096];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num = FlattenIndex(i, j, k);
					array[num] = materials[i, j, k];
				}
			}
		}
		return array;
	}

	private static byte[] PackVoxelArray(BoolArray16x16x16 voxels)
	{
		byte[] array = new byte[512];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num = FlattenIndex(i, j, k);
					if (voxels[i, j, k])
					{
						int num2 = num / 8;
						int num3 = num % 8;
						array[num2] |= (byte)(1 << num3);
					}
				}
			}
		}
		return array;
	}

	private static byte[,,] UnpackMaterialArray(byte[] arr)
	{
		byte[,,] array = new byte[16, 16, 16];
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num = FlattenIndex(i, j, k);
					array[i, j, k] = arr[num];
				}
			}
		}
		return array;
	}

	private static BoolArray16x16x16 UnpackVoxelArray(byte[] bytes)
	{

		BoolArray16x16x16 val = new BoolArray16x16x16();
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					int num = FlattenIndex(i, j, k);
					int num2 = num / 8;
					int num3 = num % 8;
					val[i, j, k] = (bytes[num2] & (1 << num3)) != 0;
				}
			}
		}
		return val;
	}

	private static byte[] Compress(byte[] data)
	{
		using MemoryStream memoryStream = new MemoryStream();
		using GZipStream gZipStream = new GZipStream(memoryStream, CompressionMode.Compress);
		gZipStream.Write(data, 0, data.Length);
		gZipStream.Close();
		return memoryStream.ToArray();
	}

	private static byte[] Decompress(byte[] data)
	{
		using MemoryStream stream = new MemoryStream(data);
		using GZipStream gZipStream = new GZipStream(stream, CompressionMode.Decompress);
		using MemoryStream memoryStream = new MemoryStream();
		gZipStream.CopyTo(memoryStream);
		return memoryStream.ToArray();
	}

	public static BlockBlueprintData FromBlockBlueprint(BlockBlueprint bp)
	{
		return new BlockBlueprintData
		{
			name = bp.Name,
			voxels = Convert.ToBase64String(Compress(PackVoxelArray(bp.Voxels))),
			materials = Convert.ToBase64String(Compress(PackMaterialArray(bp.Materials))),
			materialCodes = bp.MaterialCodes.ToArray()
		};
	}

	public BlockBlueprint ToBlockBlueprint()
	{
		BlockBlueprint blockBlueprint = new BlockBlueprint();
		blockBlueprint.Name = name;
		blockBlueprint.Voxels = UnpackVoxelArray(Decompress(Convert.FromBase64String(voxels)));
		blockBlueprint.Materials = UnpackMaterialArray(Decompress(Convert.FromBase64String(materials)));
		blockBlueprint.MaterialCodes.AddRange(materialCodes);
		return blockBlueprint;
	}
}




