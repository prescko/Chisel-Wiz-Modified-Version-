﻿namespace ChiselWiz.Systems.Chiselling;

public enum ChiselOperationType
{
	Add,
	Remove
}




