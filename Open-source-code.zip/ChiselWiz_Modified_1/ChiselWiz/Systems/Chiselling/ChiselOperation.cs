﻿namespace ChiselWiz.Systems.Chiselling;

public class ChiselOperation
{
	public ChiselOperationType Action;

	public int X;

	public int Y;

	public int Z;

	public int Size;

	public int Material;

	public override string ToString()
	{
		return $"{Action} Brush(size={Size}, mat={Material}) at ({X},{Y},{Z})";
	}
}




