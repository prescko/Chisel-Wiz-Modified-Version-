﻿using System;
using ChiselWiz.ChiselToolModes;
using ChiselWiz.Patches;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;
using VSSurvivalMod.Systems.ChiselModes;

namespace ChiselWiz.Systems.Chiselling;

public class ChiselToolModeManager
{
	private ICoreClientAPI capi;

	private ChiselOperator chiseller;

	public Cuboidf[] selectionBoxesVoxels;

	public bool IsCWSkillModeActive { get; private set; }

	public ChiselMode ActiveSkillMode { get; private set; }

	public CWChiselMode ActiveCWSkillMode { get; private set; }

	public ChiselToolModeManager(ICoreClientAPI capi, ChiselOperator chiseller)
	{
		ChiselToolModeManager chiselToolModeManager = this;
		this.capi = capi;
		this.chiseller = chiseller;
		BlockEntityChiselPatch.OnGetChiselMode += delegate(GetChiselModeEventArgs args)
		{
			if (chiselToolModeManager.IsCWSkillModeActive)
			{
				args.Handled = true;
				args.Result = (ChiselMode)(object)chiselToolModeManager.ActiveCWSkillMode;
			}
		};
		BlockEntityChiselPatch.OnGetSelectionBoxes += delegate(GetSelectionBoxesEventArgs args)
		{
			if (chiselToolModeManager.selectionBoxesVoxels == null && chiselToolModeManager.IsCWSkillModeActive && chiselToolModeManager.ActiveCWSkillMode != null)
			{
				chiselToolModeManager.selectionBoxesVoxels = chiselToolModeManager.ActiveCWSkillMode.GenerateSelectionBoxes(args.beChisel);
			}
			if (chiselToolModeManager.selectionBoxesVoxels != null && args.beChisel != null && args.beChisel.DetailingMode)
			{
				args.Result = chiselToolModeManager.selectionBoxesVoxels;
				args.Handled = true;
			}
		};
		BlockEntityChiselPatch.OnBlockInteract += delegate(OnBlockInteractEventArgs args)
		{
			if (!chiselToolModeManager.IsCWSkillModeActive && chiseller.IsWorking)
			{
				args.Handled = true;
			}
			else if (chiselToolModeManager.IsCWSkillModeActive && chiselToolModeManager.ActiveCWSkillMode != null)
			{
				args.Handled = true;
				((ChiselMode)chiselToolModeManager.ActiveCWSkillMode).Apply(args.beChisel, (IPlayer)(object)capi.World.Player, args.voxelPos, args.face, args.isBreak, args.nowmaterialIndex);
			}
		};
	}

	public void SetCWToolMode(int num, SkillItem skill)
	{
		IsCWSkillModeActive = true;
		selectionBoxesVoxels = null;
		ActiveCWSkillMode = (CWChiselMode)skill.Data;
		ActiveSkillMode = null;
	}

	public void TrySetToolMode(int num, SkillItem skill, BlockEntityChisel beChisel)
	{

		try
		{
			chiseller.SetChiselToolMode(beChisel, num, forceSet: true);
			IsCWSkillModeActive = false;
			selectionBoxesVoxels = null;
			ActiveSkillMode = (ChiselMode)skill.Data;
			ActiveCWSkillMode = null;
		}
		catch (VSException ex)
		{
			ex.DisplayError(capi);
		}
		catch (Exception ex2)
		{
			((ICoreAPI)capi).Logger.Error(ex2);
		}
	}
}




