﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ChiselWiz.Gui.Dialogs;
using ChiselWiz.Gui.Elements;
using ChiselWiz.Systems.Blueprints;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Config;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.API.Util;
using Vintagestory.Client.NoObf;
using Vintagestory.Common;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems.Chiselling;

public class ChiselOperator
{
	public class ChiselOptions
	{
		public bool addMissingMaterials;

		public bool useMaterialsInNearbyInventories;

		public bool saveUndo = true;

		public bool forceAggressiveClear;
	}

	public class ChiselJob
	{
		public int PrevChiselMode;

		public BlockEntityChisel TargetBlock;

		public System.Func<BlockBlueprint, BlockBlueprint> Transformation;

		public bool AddMissingMaterials;

		public bool RequireAllMaterials;

		public bool UseMaterialsInNearbyInventories;

		public bool AllowAnyOrientation;

		public bool SaveUndo;

		public bool ForceAggressiveClear;

		public int OperationCount { get; set; }

		public Action OnComplete { get; set; }
	}

	public bool OptionRequireMatchingMaterials = true;

	public bool OptionAutoAddMissingMaterials = true;

	public bool OptionMaterialsMustMatchExactOrientation = true;

	/// <summary>How many chiselling operations to execute per game tick (1 = default speed, 100 = max speed).</summary>
	public int ChiselSpeed = 1;

	private readonly ICoreClientAPI capi;

	private readonly HudProgressBar guiProgress;

	private readonly GuiClipboardDialog guiClipboard;

	public BlockBlueprint UndoBlueprint;

	public BlockEntityChisel UndoBEChisel;

	private int pendingOperationsCount = 1;

	private int currentOperationNum;

	private readonly Queue<ChiselJob> jobQueue = new Queue<ChiselJob>();

	private long operationTickerId = -1L;

	private ChiselJob currentJob;

	private IEnumerator<ChiselOperation> currentOperations;

	private BlockBlueprint currentStartingBlueprint;

	private BlockBlueprint lastGoalBlueprint;

	private BlockPos lastTargetBlockPos;

	private const string HotbarInventoryID = "hotbar-";

	private const string BackpackInventoryID = "backpack-";

	private const string CreativeInventoryID = "creative-";

	private bool creativeInventoryReady;

	public BlockBlueprint ClipboardBlueprint { get; private set; }

	public BlockEntityChisel FocusedBEChisel => GetBEChisel(((IPlayer)capi.World.Player).CurrentBlockSelection);

	public BlockEntityMicroBlock FocusedBEMicroblock => GetBEMicroblock(((IPlayer)capi.World.Player).CurrentBlockSelection);

	public int RemainingJobs => jobQueue.Count + ((currentJob != null) ? 1 : 0);

	public bool IsWorking => RemainingJobs > 0;

	public ChiselOperator(ICoreClientAPI capi)
	{
		this.capi = capi;
		guiProgress = new HudProgressBar(capi);
		guiClipboard = new GuiClipboardDialog(capi);
		((GuiDialog)guiClipboard).OnClosed += delegate
		{
			ClipboardBlueprint = null;
		};
	}

	public void SetClipboardBlueprint(BlockBlueprint blueprint, EnumBlockRenderMode previewRenderMode = EnumBlockRenderMode.SpinningCube, bool playSfx = true)
	{

		if (ClipboardBlueprint == blueprint)
		{
			return;
		}
		if (blueprint == null)
		{
			((GuiDialog)guiClipboard).TryClose();
			guiClipboard.SetBlueprint(null);
			return;
		}
		blueprint.SimplifyMaterials();
		ClipboardBlueprint = blueprint;
		((GuiDialog)guiClipboard).TryOpen();
		guiClipboard.SetBlueprint(ClipboardBlueprint, previewRenderMode);
		if (playSfx)
		{
			EntityPos pos = ((Entity)((IPlayer)capi.World.Player).Entity).Pos;
			((IWorldAccessor)capi.World).PlaySoundAt(new AssetLocation("chiselwiz", "sounds/copy"), pos.X, pos.InternalY, pos.Z, (IPlayer)(object)capi.World.Player, true, 12f, 1f);
		}
	}

	public void Paste()
	{
		if (ClipboardBlueprint == null)
		{
			throw new VSException("chiselwiz:There's no block design on your clipboard");
		}
		BlockBlueprint bp = ClipboardBlueprint.Clone();
		BlockEntityChisel beChisel = FocusedBEChisel;
		_ = ((BlockEntity)beChisel).Pos;
		ChiselOptions options = new ChiselOptions
		{
			addMissingMaterials = true
		};
		ChiselJob job = Apply((BlockBlueprint _) => bp, beChisel, options);
		job.OnComplete = delegate
		{
			if (job.OperationCount > 0)
			{
				TadaaFx(((BlockEntity)beChisel).Pos);
			}
		};
	}

	public void Undo()
	{
		if (UndoBEChisel == null)
		{
			throw new VSException("chiselwiz:Nothing to undo");
		}
		BlockBlueprint bp = UndoBlueprint.Clone();
		BlockEntityChisel beChisel = UndoBEChisel;
		_ = ((BlockEntity)beChisel).Pos;
		ChiselOptions options = new ChiselOptions
		{
			addMissingMaterials = true,
			saveUndo = false
		};
		ChiselJob job = Apply((BlockBlueprint _) => bp, beChisel, options);
		job.OnComplete = delegate
		{
			if (job.OperationCount > 0)
			{
				TadaaFx(((BlockEntity)beChisel).Pos);
			}
		};
	}

	public BlockEntityChisel GetBEChisel(BlockSelection blockSelection)
	{
		if (blockSelection?.Position == (BlockPos)null)
		{
			throw new VSException("chiselwiz:You must focus on a chiselled block");
		}
		return ((IWorldAccessor)capi.World).BlockAccessor.GetBlockEntity<BlockEntityChisel>(blockSelection.Position) ?? throw new VSException("chiselwiz:This is not a chiselled block");
	}

	public BlockEntityMicroBlock GetBEMicroblock(BlockSelection blockSelection)
	{
		if (blockSelection?.Position == (BlockPos)null)
		{
			throw new VSException("chiselwiz:You must focus on a chiselled block");
		}
		return ((IWorldAccessor)capi.World).BlockAccessor.GetBlockEntity<BlockEntityMicroBlock>(blockSelection.Position) ?? throw new VSException("chiselwiz:This is not a chiselled block");
	}

	public bool CanChiselHere(BlockPos pos)
	{
		return ((IWorldAccessor)capi.World).Claims.TryAccess((IPlayer)(object)capi.World.Player, pos, (EnumBlockAccessFlags)1);
	}

	public void AssertCanChiselHere(BlockPos pos)
	{
		if (!CanChiselHere(pos))
		{
			throw new VSException("chiselwiz:Claim forbids chiselling");
		}
	}

	public ChiselJob Apply(System.Func<BlockBlueprint, BlockBlueprint> transformation, BlockEntityChisel destBlock, ChiselOptions options)
	{
		AssertCanChiselHere(((BlockEntity)destBlock).Pos);
		int chiselToolMode = GetChiselToolMode(destBlock);
		ChiselJob chiselJob = new ChiselJob
		{
			PrevChiselMode = chiselToolMode,
			TargetBlock = destBlock,
			Transformation = transformation,
			AddMissingMaterials = (options.addMissingMaterials && OptionAutoAddMissingMaterials),
			RequireAllMaterials = OptionRequireMatchingMaterials,
			UseMaterialsInNearbyInventories = options.useMaterialsInNearbyInventories,
			AllowAnyOrientation = !OptionMaterialsMustMatchExactOrientation,
			SaveUndo = options.saveUndo,
			ForceAggressiveClear = options.forceAggressiveClear
		};
		jobQueue.Enqueue(chiselJob);
		if (operationTickerId == -1)
		{
			bool runningIteration = false;
			operationTickerId = ((IWorldAccessor)capi.World).RegisterGameTickListener((Action<float>)delegate(float ms)
			{
				if (!runningIteration)
				{
					runningIteration = true;
					ProcessQueue(ms).ContinueWith(delegate
					{
						runningIteration = false;
					});
				}
			}, 25, 0);
		}
		return chiselJob;
	}

	public void CancelAll()
	{
		jobQueue.Clear();
		if (currentJob != null)
		{
			ItemSlot activeHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.ActiveHotbarSlot;
			object obj;
			if (activeHotbarSlot == null)
			{
				obj = null;
			}
			else
			{
				ItemStack itemstack = activeHotbarSlot.Itemstack;
				obj = ((itemstack != null) ? itemstack.Collectible : null);
			}
			if (obj is ItemChisel)
			{
				SetChiselToolMode(currentJob.TargetBlock, currentJob.PrevChiselMode);
			}
		}
		currentJob = null;
		currentOperations = null;
		currentStartingBlueprint = null;
		lastGoalBlueprint = null;
		lastTargetBlockPos = null;
		if (operationTickerId != -1)
		{
			((IWorldAccessor)capi.World).UnregisterGameTickListener(operationTickerId);
			operationTickerId = -1L;
		}
		((GuiDialog)guiProgress).TryClose();
	}

	private void AssertChiselingPreconditions()
	{

		ItemSlot activeHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.ActiveHotbarSlot;
		object obj;
		if (activeHotbarSlot == null)
		{
			obj = null;
		}
		else
		{
			ItemStack itemstack = activeHotbarSlot.Itemstack;
			obj = ((itemstack != null) ? itemstack.Collectible : null);
		}
		if (!(obj is ItemChisel))
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		if ((int)((IPlayer)capi.World.Player).WorldData.CurrentGameMode == 2)
		{
			return;
		}
		ItemSlot offhandHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.OffhandHotbarSlot;
		if (offhandHotbarSlot != null)
		{
			ItemStack itemstack2 = offhandHotbarSlot.Itemstack;
			if ((int)((itemstack2 == null) ? ((EnumTool?)null) : itemstack2.Collectible?.Tool).GetValueOrDefault() == 5)
			{
				return;
			}
		}
		throw new VSException("chiselwiz:A hammer must be in your left hand");
	}

	private async Task ProcessQueue(float dt)
	{
		try
		{
			AssertChiselingPreconditions();
			if (currentJob == null)
			{
				if (jobQueue.Count <= 0)
				{
					((IWorldAccessor)capi.World).UnregisterGameTickListener(operationTickerId);
					operationTickerId = -1L;
					((IEventAPI)capi.Event).EnqueueMainThreadTask((Action)delegate
					{
						((GuiDialog)guiProgress).TryClose();
					}, "closechisellingprogressbar");
					lastGoalBlueprint = null;
					lastTargetBlockPos = null;
					return;
				}
				currentJob = jobQueue.Dequeue();
				if (currentJob.SaveUndo)
				{
					UndoBlueprint = new BlockBlueprint((BlockEntityMicroBlock)(object)currentJob.TargetBlock);
					UndoBEChisel = currentJob.TargetBlock;
				}
				if (!currentJob.AddMissingMaterials && lastGoalBlueprint != null && lastTargetBlockPos == ((BlockEntity)currentJob.TargetBlock).Pos)
				{
					currentStartingBlueprint = lastGoalBlueprint;
				}
				else
				{
					currentStartingBlueprint = new BlockBlueprint((BlockEntityMicroBlock)(object)currentJob.TargetBlock);
				}
				BlockBlueprint goalBlueprint = currentJob.Transformation(currentStartingBlueprint.Clone());
				if (goalBlueprint.IsVoid)
				{
					throw new VSException("chiselwiz:Cannot perform this operation as it would delete the whole block.");
				}
				if (currentJob.AddMissingMaterials)
				{
					await AddMissingMaterials(goalBlueprint, currentJob.TargetBlock, OptionMaterialsMustMatchExactOrientation, currentJob.UseMaterialsInNearbyInventories);
					currentStartingBlueprint = new BlockBlueprint((BlockEntityMicroBlock)(object)currentJob.TargetBlock);
				}
				if (currentJob.RequireAllMaterials)
				{
					AssertHaveAllMaterials(goalBlueprint, currentJob.TargetBlock, OptionMaterialsMustMatchExactOrientation);
				}
				else
				{
					goalBlueprint = goalBlueprint.RemapToPalette(currentStartingBlueprint);
				}
				List<ChiselOperation> list = new ChiselOperationCalculator(capi)
				{
					RequireAllMaterials = currentJob.RequireAllMaterials,
					AllowAnyOrientation = currentJob.AllowAnyOrientation,
					ForceAggressiveClear = currentJob.ForceAggressiveClear
				}.ComputeOperations(currentStartingBlueprint, goalBlueprint);
				currentOperations = list.GetEnumerator();
				pendingOperationsCount = list.Count;
				currentJob.OperationCount = list.Count;
				currentOperationNum = 0;
				if (pendingOperationsCount > 0)
				{
					((IEventAPI)capi.Event).EnqueueMainThreadTask((Action)delegate
					{
						((GuiDialog)guiProgress).TryOpen();
					}, "openchisellingprogressbar");
				}
				lastGoalBlueprint = goalBlueprint;
				lastTargetBlockPos = ((BlockEntity)currentJob.TargetBlock).Pos;
			}
			ClientMain obj = capi.World as ClientMain;
			long elapsedMilliseconds = obj.ElapsedMilliseconds;
			long lastReceivedMilliseconds = obj.LastReceivedMilliseconds;
			if (elapsedMilliseconds - lastReceivedMilliseconds > 500)
			{
				return;
			}
			if (pendingOperationsCount > 0)
			{
				guiProgress.Progress = (float)currentOperationNum / (float)pendingOperationsCount;
				guiProgress.QueuedJobs = jobQueue.Count;
			}
			// Execute ChiselSpeed operations per tick (1 = default, up to 100 = max)
		int opsThisTick = Math.Max(1, ChiselSpeed);
		for (int _speedIdx = 0; _speedIdx < opsThisTick; _speedIdx++)
		{
			if (!currentOperations.MoveNext())
			{
				if (lastGoalBlueprint.SetNameOnPaste)
				{
					SetBlockText(currentJob.TargetBlock, lastGoalBlueprint.Name);
				}
				SetChiselToolMode(currentJob.TargetBlock, currentJob.PrevChiselMode);
				if (currentJob.OnComplete != null)
				{
					currentJob.OnComplete();
				}
				currentJob = null;
				currentOperations = null;
				currentStartingBlueprint = null;
				return;
			}
			currentOperationNum++;
			ChiselOperation current = currentOperations.Current;
			Block materialBlock = null;
			if (current.Action == ChiselOperationType.Remove)
			{
				byte b = currentStartingBlueprint.Materials[current.X, current.Y, current.Z];
				if (currentStartingBlueprint.MaterialCodes.Count > b)
				{
					string text = currentStartingBlueprint.MaterialCodes[b];
					materialBlock = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation(text));
				}
			}
			else
			{
				byte b2 = lastGoalBlueprint.Materials[current.X, current.Y, current.Z];
				if (lastGoalBlueprint.MaterialCodes.Count > b2)
				{
					string text2 = lastGoalBlueprint.MaterialCodes[b2];
					materialBlock = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation(text2));
				}
			}
			SingleChiselOperation(currentJob.TargetBlock, current.X, current.Y, current.Z, current.Action == ChiselOperationType.Remove, (byte)current.Material, current.Size, materialBlock);
		}
		}
		catch (Exception ex)
		{
			if (ex is VSException ex2)
			{
				ex2.DisplayError(capi);
			}
			else
			{
				capi.ShowChatMessage("[Error] " + ex.Message);
				((ICoreAPI)capi).Logger.Error(ex);
			}
			CancelAll();
		}
	}

	public void TadaaFx(BlockPos blockPos)
	{

		IClientPlayer player = capi.World.Player;
		_ = ((Entity)((IPlayer)player).Entity).Pos;
		((IWorldAccessor)capi.World).PlaySoundAt(new AssetLocation("chiselwiz", "sounds/pasted"), (double)((float)blockPos.X + 0.5f), (double)((float)blockPos.InternalY + 0.5f), (double)((float)blockPos.Z + 0.5f), (IPlayer)(object)player, (EnumSoundType)0, 1f, 12f, 0.5f);
		float num = 0.5f;
		blockPos.ToVec3d();
		float num2 = 0.1f;
		SimpleParticleProperties val = new SimpleParticleProperties();
		val.Color = ColorUtil.Hex2Int("#aa8888ff");
		val.MinPos = blockPos.ToVec3d().AddCopy(0f - num2, 0f - num2, 0f - num2);
		val.AddPos = new Vec3d((double)(1f + num2 * 2f), (double)(1f + num2 * 2f), (double)(1f + num2 * 2f));
		val.MinSize = 0.4f;
		val.MaxSize = 1f;
		val.MinVelocity = new Vec3f(0f - num, 0f, 0f - num);
		val.AddVelocity = new Vec3f(num * 2f, num * 2f, num * 2f);
		val.MinQuantity = 5f;
		val.AddQuantity = 3f;
		val.LifeLength = 0.3f;
		val.VertexFlags = 255;
		val.Bounciness = 0.95f;
		val.SizeEvolve = EvolvingNatFloat.create((EnumTransformFunction)3, 0.1f);
		val.OpacityEvolve = EvolvingNatFloat.create((EnumTransformFunction)5, -24f);
		val.ParticleModel = (EnumParticleModel)1;
		((IWorldAccessor)capi.World).SpawnParticles((IParticlePropertiesProvider)(object)val, (IPlayer)null);
		val.LifeLength *= 2f;
		val.MinQuantity = 5f;
		val.AddQuantity = 3f;
		val.ParticleModel = (EnumParticleModel)0;
		val.MinSize *= 0.4f;
		val.MaxSize *= 0.4f;
		((IWorldAccessor)capi.World).SpawnParticles((IParticlePropertiesProvider)(object)val, (IPlayer)null);
		val.LifeLength = 3f;
		val.MinQuantity = 10f;
		val.AddQuantity = 5f;
		val.ParticleModel = (EnumParticleModel)1;
		((IWorldAccessor)capi.World).SpawnParticles((IParticlePropertiesProvider)(object)val, (IPlayer)null);
	}

	private async Task AddMissingMaterials(BlockBlueprint blueprint, BlockEntityChisel destBlock, bool mustMatchOrientation, bool includeNearbyInventories)
	{
		BlockBlueprint blockBlueprint = new BlockBlueprint((BlockEntityMicroBlock)(object)destBlock);
		HashSet<string> missingBlockCodes = new HashSet<string>(blueprint.MaterialCodes);
		missingBlockCodes.ExceptWith(blockBlueprint.MaterialCodes);
		if (!mustMatchOrientation)
		{
			HashSet<string> alternateOrientationMaterialCodes = GetAlternateOrientationMaterialCodes(blockBlueprint.MaterialCodes);
			missingBlockCodes.ExceptWith(alternateOrientationMaterialCodes);
		}
		List<BlockEntityOpenableContainer> peekContainers = null;
		OpenableContainerManager mgr = new OpenableContainerManager(capi);
		try
		{
			if (includeNearbyInventories)
			{
				try
				{
					int range = 5;
					BlockPos asBlockPos = ((Entity)((IPlayer)capi.World.Player).Entity).Pos.AsBlockPos;
					List<BlockEntityOpenableContainer> source = mgr.FindAllNear(asBlockPos, range);
					peekContainers = source.Where((BlockEntityOpenableContainer c) => !((BlockEntityContainer)c).Inventory.HasOpened((IPlayer)(object)capi.World.Player)).ToList();
					await mgr.ToggleOpen((IEnumerable<BlockEntityOpenableContainer>)peekContainers);
				}
				catch (Exception ex)
				{
					((ICoreAPI)capi).Logger.Error(ex);
				}
			}
			foreach (string missingBlockCode in missingBlockCodes)
			{
				ItemSlot val = FindItemSlot(delegate(ItemSlot itemSlot)
				{
					ItemStack itemstack = itemSlot.Itemstack;
					if (itemstack == null)
					{
						return false;
					}
					return ((RegistryObject)itemstack.Block).Code.ToString() == missingBlockCode && itemstack.StackSize > 0;
				});
				if (val == null && !mustMatchOrientation)
				{
					HashSet<string> altMaterialCodes = GetAlternateOrientationMaterialCodes(missingBlockCode);
					val = FindItemSlot(delegate(ItemSlot itemSlot)
					{
						ItemStack itemstack = itemSlot.Itemstack;
						if (((itemstack != null) ? itemstack.Block : null) == null)
						{
							return false;
						}
						return altMaterialCodes.Contains(((RegistryObject)itemstack.Block).Code.ToString()) && itemstack.StackSize > 0;
					});
				}
				if (val == null)
				{
					throw new VSException("chiselwiz:Missing block material '{0}'", new object[1] { missingBlockCode });
				}
				AddMaterialToBEChisel(destBlock, val);
			}
		}
		finally
		{
			if (peekContainers != null)
			{
				await mgr.ToggleOpen((IEnumerable<BlockEntityOpenableContainer>)peekContainers);
			}
		}
	}

	private HashSet<string> GetAlternateOrientationMaterialCodes(IEnumerable<string> materialCodes)
	{
		HashSet<string> hashSet = new HashSet<string>();
		foreach (string materialCode in materialCodes)
		{
			HashsetExtensions.AddRange<string>(hashSet, GetAlternateOrientationMaterialCodes(materialCode));
		}
		return hashSet;
	}

	private HashSet<string> GetAlternateOrientationMaterialCodes(string materialCode)
	{
		Block block = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation(materialCode));
		string[] array = new string[3] { "rotation", "orientation", "side" };
		string[] array2 = new string[9]
		{
			"ns",
			"ew",
			"ud",
			BlockFacing.NORTH.Code,
			BlockFacing.EAST.Code,
			BlockFacing.SOUTH.Code,
			BlockFacing.WEST.Code,
			BlockFacing.UP.Code,
			BlockFacing.DOWN.Code
		};
		HashSet<string> hashSet = new HashSet<string>();
		string[] array3 = array;
		foreach (string text in array3)
		{
			string[] array4 = array2;
			foreach (string text2 in array4)
			{
				hashSet.Add(((RegistryObject)block).CodeWithVariant(text, text2).ToString());
			}
		}
		return hashSet;
	}

	private void AssertHaveAllMaterials(BlockBlueprint blueprint, BlockEntityChisel destBlock, bool mustMatchOrientation)
	{
		HashSet<string> hashSet = new HashSet<string>(new BlockBlueprint((BlockEntityMicroBlock)(object)destBlock).MaterialCodes);
		if (!mustMatchOrientation)
		{
			hashSet = GetAlternateOrientationMaterialCodes(hashSet);
		}
		HashSet<string> hashSet2 = new HashSet<string>(blueprint.MaterialCodes);
		hashSet2.ExceptWith(hashSet);
		using HashSet<string>.Enumerator enumerator = hashSet2.GetEnumerator();
		if (enumerator.MoveNext())
		{
			string current = enumerator.Current;
			throw new VSException("chiselwiz:Missing block material '{0}'", new object[1] { current });
		}
	}

	public bool AddMaterialToBEChisel(BlockEntityChisel beChisel, ItemSlot materialItemSlot)
	{
		ItemSlot mouseItemSlot = ((IPlayer)capi.World.Player).InventoryManager.MouseItemSlot;
		if (mouseItemSlot.Itemstack != null)
		{
			throw new VSException("chiselwiz:Can't add material while there is something in your mouse slot");
		}
		if (!PickupItem(materialItemSlot, materialItemSlot.Itemstack.StackSize))
		{
			throw new VSException("chiselwiz:Failed to pick up material from inventory");
		}
		if (!SelectChisel())
		{
			throw new VSException("chiselwiz:Failed to select chisel");
		}
		if (!SetChiselToolMode(beChisel, -1, forceSet: true))
		{
			throw new VSException("chiselwiz:Failed to add material to block");
		}
		if (mouseItemSlot.Itemstack != null)
		{
			if (materialItemSlot is ItemSlotCreative)
			{
				EnsureCreativeInventoryReady();
				BlackholeCreativeItemSlot(mouseItemSlot);
			}
			else if (!MoveItem(mouseItemSlot, materialItemSlot))
			{
				throw new VSException("chiselwiz:Can't put down remaining items in mouse slot");
			}
		}
		return true;
	}

	private void EnsureCreativeInventoryReady()
	{

		if ((int)((IPlayer)capi.World.Player).WorldData.CurrentGameMode != 2 || creativeInventoryReady)
		{
			return;
		}
		foreach (GuiDialog loadedGui in capi.Gui.LoadedGuis)
		{
			if (loadedGui is GuiDialogInventory)
			{
				loadedGui.Toggle();
				loadedGui.Toggle();
				creativeInventoryReady = true;
				break;
			}
		}
	}

	private void BlackholeCreativeItemSlot(ItemSlot itemSlot)
	{

		IClientPlayer player = capi.World.Player;
		IInventory val = ((IPlayer)player).InventoryManager.Inventories["creative-" + ((IPlayer)player).PlayerUID];
		ItemStackMoveOperation val2 = new ItemStackMoveOperation((IWorldAccessor)(object)capi.World, (EnumMouseButton)0, (EnumModifierKey)0, (EnumMergePriority)0, 0);
		val2.ActingPlayer = (IPlayer)(object)capi.World.Player;
		val2.CurrentPriority = (EnumMergePriority)1;
		int num = (itemSlot.Itemstack.Equals((IWorldAccessor)(object)capi.World, val[0].Itemstack, GlobalConstants.IgnoredStackAttributes) ? 1 : 0);
		object obj = val.ActivateSlot(num, itemSlot, ref val2);
		if (obj != null)
		{
			capi.Network.SendPacketClient(obj);
		}
	}

	public bool DropItem(ItemSlot slot, bool fullStack = true)
	{
		return ((IPlayer)capi.World.Player).InventoryManager.DropItem(slot, fullStack);
	}

	public bool ClearSlot(ItemSlot slot)
	{
		if (slot.Empty)
		{
			return true;
		}
		ItemSlot val = FindEmptyItemSlot();
		if (val == null)
		{
			return false;
		}
		return MoveItem(slot, val, slot.StackSize);
	}

	public bool PickupItem(ItemSlot itemSlot, int count = 1)
	{
		ItemSlot mouseItemSlot = ((IPlayer)capi.World.Player).InventoryManager.MouseItemSlot;
		return MoveItem(itemSlot, mouseItemSlot, count);
	}

	private IEnumerable<ItemSlot> GetSearchableSlots()
	{

		Dictionary<string, IInventory> inventories = ((IPlayer)capi.World.Player).InventoryManager.Inventories;
		List<ItemSlot> list = new List<ItemSlot>();
		foreach (var (_, val2) in inventories)
		{
			if (!(val2 is InventoryPlayerCreative) || (int)((IPlayer)capi.World.Player).WorldData.CurrentGameMode == 2)
			{
				list.AddRange((IEnumerable<ItemSlot>)val2);
			}
		}
		return list;
	}

	public ItemSlot FindEmptyItemSlot()
	{
		return GetSearchableSlots().FirstOrDefault(delegate(ItemSlot slot)
		{
			bool flag = slot is ItemSlotBagContent || slot is ItemSlotSurvival;
			return slot.Empty && flag;
		});
	}

	public bool SelectChisel()
	{
		IClientPlayer player = capi.World.Player;
		Dictionary<string, IInventory> inventories = ((IPlayer)player).InventoryManager.Inventories;
		IInventory val = inventories["hotbar-" + ((IPlayer)player).PlayerUID];
		int num = -1;
		for (int i = 0; i < ((IReadOnlyCollection<ItemSlot>)val).Count; i++)
		{
			ItemSlot obj = val[i];
			object obj2;
			if (obj == null)
			{
				obj2 = null;
			}
			else
			{
				ItemStack itemstack = obj.Itemstack;
				obj2 = ((itemstack != null) ? itemstack.Collectible : null);
			}
			if (obj2 is ItemChisel)
			{
				num = i;
				break;
			}
		}
		if (num != -1)
		{
			((IPlayer)player).InventoryManager.ActiveHotbarSlotNumber = num;
			return true;
		}
		ItemSlot val2 = ((IEnumerable<ItemSlot>)inventories["backpack-" + ((IPlayer)player).PlayerUID]).FirstOrDefault(delegate(ItemSlot slot)
		{
			object obj3;
			if (slot == null)
			{
				obj3 = null;
			}
			else
			{
				ItemStack itemstack2 = slot.Itemstack;
				obj3 = ((itemstack2 != null) ? itemstack2.Collectible : null);
			}
			return obj3 is ItemChisel;
		});
		if (val2 != null)
		{
			ClearSlot(((IPlayer)player).InventoryManager.ActiveHotbarSlot);
			MoveItem(val2, ((IPlayer)player).InventoryManager.ActiveHotbarSlot);
			return true;
		}
		return false;
	}

	public bool MoveItem(ItemSlot srcSlot, ItemSlot destSlot, int stackSize = -1)
	{

		if (srcSlot == null || destSlot == null)
		{
			return false;
		}
		if (stackSize == -1)
		{
			stackSize = ((srcSlot == null) ? 1 : srcSlot.StackSize);
		}
		ItemStackMoveOperation val = new ItemStackMoveOperation((IWorldAccessor)(object)capi.World, (EnumMouseButton)0, (EnumModifierKey)0, (EnumMergePriority)0, stackSize);
		object obj = ((IPlayer)capi.World.Player).InventoryManager.TryTransferTo(srcSlot, destSlot, ref val);
		if (obj == null)
		{
			return false;
		}
		capi.Network.SendPacketClient(obj);
		return true;
	}

	public ItemSlot FindItemSlot(System.Func<ItemSlot, bool> filter)
	{
		return GetSearchableSlots().FirstOrDefault(filter);
	}

	public int GetChiselToolMode(BlockEntityChisel beChisel)
	{

		ItemSlot activeHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.ActiveHotbarSlot;
		object obj;
		if (activeHotbarSlot == null)
		{
			obj = null;
		}
		else
		{
			ItemStack itemstack = activeHotbarSlot.Itemstack;
			obj = ((itemstack != null) ? itemstack.Collectible : null);
		}
		if (obj == null)
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		if (!(obj is ItemChisel))
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		BlockSelection val = new BlockSelection(((BlockEntity)beChisel).Pos, BlockFacing.UP, ((BlockEntity)beChisel).Block);
		return activeHotbarSlot.Itemstack.Collectible.GetToolMode(activeHotbarSlot, (IPlayer)(object)capi.World.Player, val);
	}

	public string GetBlockText(BlockEntityChisel beChisel)
	{
		return ((BlockEntityMicroBlock)beChisel).BlockName;
	}

	public void SetBlockText(BlockEntityChisel beChisel, string text)
	{

		byte[] array = SerializerUtil.Serialize<EditSignPacket>(new EditSignPacket
		{
			Text = text,
			FontSize = 20f
		});
		capi.Network.SendBlockEntityPacket(((BlockEntity)beChisel).Pos, 1002, array);
	}

	private void LocalAddMaterialFromMouseSlot(BlockEntityChisel beChisel)
	{

		IClientPlayer player = capi.World.Player;
		ItemSlot mouseItemSlot = ((IPlayer)player).InventoryManager.MouseItemSlot;
		if (mouseItemSlot.Empty || mouseItemSlot.Itemstack.Block == null)
		{
			throw new VSException("chiselwiz:Not holding a valid material in mouse slot");
		}
		if (!ItemChisel.IsValidChiselingMaterial((ICoreAPI)(object)capi, ((BlockEntity)beChisel).Pos, mouseItemSlot.Itemstack.Block, (IPlayer)(object)player))
		{
			throw new VSException("chiselwiz:Not holding a valid material in mouse slot");
		}
		ItemStack itemstack = mouseItemSlot.Itemstack;
		Block block = itemstack.Block;
		if (block is BlockChisel)
		{
			ITreeAttribute attributes = itemstack.Attributes;
			IAttribute obj = ((attributes != null) ? attributes["availMaterialQuantities"] : null);
			int[] array = ((ArrayAttribute<int>)(object)((obj is IntArrayAttribute) ? obj : null))?.value;
			ITreeAttribute attributes2 = itemstack.Attributes;
			IAttribute obj2 = ((attributes2 != null) ? attributes2["materials"] : null);
			int[] array2 = ((ArrayAttribute<int>)(object)((obj2 is IntArrayAttribute) ? obj2 : null))?.value;
			if (array2 == null)
			{
				return;
			}
			bool flag = default(bool);
			for (int i = 0; i < array2.Length; i++)
			{
				if (array2[i] != 0 && array[i] > 0)
				{
					Block block2 = ((IWorldAccessor)capi.World).GetBlock(array2[i]);
					beChisel.AddMaterial(block2, out flag, false, (ushort)array[i]);
				}
			}
			if ((int)((IPlayer)player).WorldData.CurrentGameMode != 2)
			{
				mouseItemSlot.TakeOut(1);
			}
		}
		else
		{
			bool flag2 = default(bool);
			beChisel.AddMaterial(block, out flag2, true);
			if (!flag2 && (int)((IPlayer)player).WorldData.CurrentGameMode != 2)
			{
				mouseItemSlot.TakeOut(1);
			}
		}
	}

	public bool SetChiselMaterialIdx(BlockEntityChisel beChisel, int materialIdx = 0)
	{
		ItemSlot activeHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.ActiveHotbarSlot;
		object obj;
		if (activeHotbarSlot == null)
		{
			obj = null;
		}
		else
		{
			ItemStack itemstack = activeHotbarSlot.Itemstack;
			obj = ((itemstack != null) ? itemstack.Collectible : null);
		}
		if (obj == null)
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		ItemChisel val = (ItemChisel)((obj is ItemChisel) ? obj : null);
		if (val == null)
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		return SetChiselToolMode(beChisel, materialIdx + val.ToolModes.Length, forceSet: true);
	}

	public ItemChisel GetActiveItemChisel(out ItemSlot slot)
	{
		ItemSlot activeHotbarSlot = ((IPlayer)capi.World.Player).InventoryManager.ActiveHotbarSlot;
		object obj;
		if (activeHotbarSlot == null)
		{
			obj = null;
		}
		else
		{
			ItemStack itemstack = activeHotbarSlot.Itemstack;
			obj = ((itemstack != null) ? itemstack.Collectible : null);
		}
		if (obj == null)
		{
			throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		}
		object result = ((obj is ItemChisel) ? obj : null) ?? throw new VSException("chiselwiz:A chisel must be in your active hotbar slot");
		slot = activeHotbarSlot;
		return (ItemChisel)result;
	}

	public bool SetChiselToolMode(BlockEntityChisel beChisel, int toolMode = 0, bool forceSet = false)
	{
		forceSet = true;
		ItemSlot slot;
		ItemChisel activeItemChisel = GetActiveItemChisel(out slot);
		if (!forceSet && toolMode != -1 && GetChiselToolMode(beChisel) == toolMode)
		{
			return true;
		}
		ItemSlot mouseItemSlot = ((IPlayer)capi.World.Player).InventoryManager.MouseItemSlot;
		if (toolMode != -1 && !mouseItemSlot.Empty)
		{
			DropItem(mouseItemSlot);
		}
		if (toolMode == -1)
		{
			try
			{
				LocalAddMaterialFromMouseSlot(beChisel);
			}
			catch (VSException ex)
			{
				ex.DisplayError(capi);
				return false;
			}
			catch (Exception ex2)
			{
				((ICoreAPI)capi).Logger.Error(ex2);
				return false;
			}
			toolMode = 0;
		}
		else if (toolMode < activeItemChisel.ToolModes.Length)
		{
			slot.Itemstack.Attributes.SetInt("toolMode", toolMode);
		}
		Packet_ToolMode packet_ToolMode = new Packet_ToolMode();
		packet_ToolMode.SetMode(toolMode);
		if (beChisel != null)
		{
			packet_ToolMode.SetX(((BlockEntity)beChisel).Pos.X);
			packet_ToolMode.SetY(((BlockEntity)beChisel).Pos.Y);
			packet_ToolMode.SetZ(((BlockEntity)beChisel).Pos.Z);
		}
		Packet_Client packet_Client = new Packet_Client();
		packet_Client.SetId(27);
		packet_Client.SetToolMode(packet_ToolMode);
		capi.Network.SendPacketClient((object)packet_Client);
		return true;
	}

	public void SingleChiselOperation(BlockEntityChisel targetBE, int x, int y, int z, bool isBreak, byte materialIdx = 0, int brushSize = 1, Block materialBlock = null)
	{

		GetActiveItemChisel(out var _);
		int toolMode = (int)Math.Log2(brushSize);
		SetChiselToolMode(targetBE, toolMode);
		byte[] data;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			if (!isBreak)
			{
				x -= brushSize;
			}
			binaryWriter.Write(x);
			binaryWriter.Write(y);
			binaryWriter.Write(z);
			binaryWriter.Write(isBreak);
			binaryWriter.Write((ushort)1);
			binaryWriter.Write(materialIdx);
			data = memoryStream.ToArray();
		}
		(capi.World as ClientMain).SendBlockEntityPacket(((BlockEntity)targetBE).Pos.X, ((BlockEntity)targetBE).Pos.Y, ((BlockEntity)targetBE).Pos.Z, 1010, data);
		if (materialBlock == null)
		{
			materialBlock = ((BlockEntity)targetBE).Block;
		}
		Vec3i val = new Vec3i(x, y, z);
		CreateChiselParticles(brushSize, val, materialBlock, ((BlockEntity)targetBE).Pos, isBreak);
		PlayChiselSfx(((BlockEntity)targetBE).Pos, val);
	}

	private void CreateChiselParticles(int size, Vec3i voxelPos, Block block, BlockPos pos, bool isBreak)
	{

		float num = size;
		if (!isBreak)
		{
			num /= 2f;
		}
		if (!(num <= 0f))
		{
			Vec3d val = pos.ToVec3d().Add((double)voxelPos.X / 16.0, (double)voxelPos.Y / 16.0, (double)voxelPos.Z / 16.0).Add((double)((float)size / 4f) / 16.0, (double)((float)size / 4f) / 16.0, (double)((float)size / 4f) / 16.0);
			int num2 = (int)(num * 5f - 2f + (float)((IWorldAccessor)capi.World).Rand.Next(5));
			while (num2-- > 0)
			{
				((IWorldAccessor)capi.World).SpawnParticles(1f, block.GetRandomColor(capi, pos, BlockFacing.UP, -1) | -16777216, val, val.Clone().Add((double)((float)size / 4f) / 16.0, (double)((float)size / 4f) / 16.0, (double)((float)size / 4f) / 16.0), new Vec3f(-1f, -0.5f, -1f), new Vec3f(1f, 1f + (float)size / 3f, 1f), 1f, 1f, (float)size / 30f + 0.1f + (float)((IWorldAccessor)capi.World).Rand.NextDouble() * 0.25f, (EnumParticleModel)1, (IPlayer)null);
			}
		}
	}

	private void PlayChiselSfx(BlockPos pos, Vec3i voxPos)
	{

		((IWorldAccessor)capi.World).PlaySoundAt(new AssetLocation("sounds/player/knap" + ((((IWorldAccessor)capi.World).Rand.Next(2) > 0) ? 1 : 2)), (double)((float)pos.X + (float)voxPos.X / 16f), (double)((float)pos.InternalY + (float)voxPos.Y / 16f), (double)((float)pos.Z + (float)voxPos.Z / 16f), (IPlayer)(object)capi.World.Player, true, 12f, 0.3f);
	}
}





