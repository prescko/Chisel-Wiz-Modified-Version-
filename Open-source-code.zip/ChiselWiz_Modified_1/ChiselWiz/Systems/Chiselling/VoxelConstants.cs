﻿namespace ChiselWiz.Systems.Chiselling;

public static class VoxelConstants
{
	public const int BlockSize = 16;

	public static readonly int[] BrushSizes = new int[4] { 8, 4, 2, 1 };
}




