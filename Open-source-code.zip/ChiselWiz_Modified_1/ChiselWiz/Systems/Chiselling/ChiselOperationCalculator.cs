﻿using System;
using System.Collections.Generic;
using System.Linq;
using ChiselWiz.Systems.Blueprints;
using Vintagestory.API.Client;
using Vintagestory.API.Common;

namespace ChiselWiz.Systems.Chiselling;

public class ChiselOperationCalculator
{
	private ICoreClientAPI capi;

	public bool ForceAggressiveClear { get; set; }

	public bool RequireAllMaterials { get; set; } = true;

	public bool AllowAnyOrientation { get; set; } = true;

	public ChiselOperationCalculator(ICoreClientAPI capi)
	{
		this.capi = capi;
	}

	public List<ChiselOperation> ComputeOperations(BlockBlueprint startingBlueprint, BlockBlueprint goalDesign)
	{
		List<ChiselOperation> list = new List<ChiselOperation>();
		List<ChiselOperation> list2 = new List<ChiselOperation>();
		BlockBlueprint current = startingBlueprint.Clone();
		BlockBlueprint goalDesign2 = goalDesign.Clone();
		int[] brushSizes = VoxelConstants.BrushSizes;
		foreach (int num in brushSizes)
		{
			for (int j = 0; j < 16; j += num)
			{
				for (int k = 0; k < 16; k += num)
				{
					for (int l = 0; l < 16; l += num)
					{
						ProcessSubBlock(current, goalDesign2, num, j, k, l, list, list2);
					}
				}
			}
		}
		list.AddRange(list2);
		return list;
	}

	private void ProcessSubBlock(BlockBlueprint current, BlockBlueprint goalDesign, int brush, int x, int y, int z, List<ChiselOperation> ops, List<ChiselOperation> deferredOps)
	{
		if (IsBlockIdentical(current, goalDesign, x, y, z, brush))
		{
			return;
		}
		bool isSolid;
		byte dominantMat;
		int num = AnalyzeBlock(goalDesign, x, y, z, brush, out isSolid, out dominantMat);
		bool currentIsSolid;
		byte dominantMat2;
		int currentSolidCount = AnalyzeBlock(current, x, y, z, brush, out currentIsSolid, out dominantMat2);
		Func<bool> func = delegate
		{
			if (currentSolidCount == 0)
			{
				return true;
			}
			BlockBlueprint bp = current.Clone();
			Clear(bp, x, y, z, brush);
			if (!HasAny(bp))
			{
				if (brush == 1)
				{
					deferredOps.Add(new ChiselOperation
					{
						Action = ChiselOperationType.Remove,
						X = x,
						Y = y,
						Z = z,
						Size = brush,
						Material = -1
					});
					return false;
				}
				return false;
			}
			ops.Add(new ChiselOperation
			{
				Action = ChiselOperationType.Remove,
				X = x,
				Y = y,
				Z = z,
				Size = brush,
				Material = -1
			});
			Clear(current, x, y, z, brush);
			currentSolidCount = 0;
			currentIsSolid = false;
			return true;
		};
		if (isSolid)
		{
			bool flag = false;
			if (ForceAggressiveClear)
			{
				flag = true;
			}
			else
			{
				bool flag2 = false;
				if (currentIsSolid)
				{
					string code = current.MaterialCodes[dominantMat2];
					string code2 = goalDesign.MaterialCodes[dominantMat];
					flag2 = IsMatchingMaterial(code, code2);
				}
				if (!currentIsSolid || !flag2)
				{
					flag = true;
				}
			}
			if (flag && (currentSolidCount <= 0 || func()))
			{
				string materialCode = goalDesign.MaterialCodes[dominantMat];
				int bestMatchingMaterialIndex = GetBestMatchingMaterialIndex(current, materialCode);
				ops.Add(new ChiselOperation
				{
					Action = ChiselOperationType.Add,
					X = x,
					Y = y,
					Z = z,
					Size = brush,
					Material = bestMatchingMaterialIndex
				});
				Fill(current, x, y, z, brush, (byte)bestMatchingMaterialIndex);
			}
		}
		else if (brush == 1)
		{
			if (func())
			{
				IsRegionEmpty(goalDesign, x, y, z, brush);
			}
		}
		else
		{
			int num2 = (ForceAggressiveClear ? 1 : (brush switch
			{
				8 => 10, 
				4 => 5, 
				_ => 2, 
			}));
			if (num < brush * brush * brush / 2 && currentSolidCount > num * num2 && func())
			{
				IsRegionEmpty(goalDesign, x, y, z, brush);
			}
		}
	}

	private bool IsRegionEmpty(BlockBlueprint bp, int ox, int oy, int oz, int brush)
	{
		for (int i = ox; i < ox + brush; i++)
		{
			for (int j = oy; j < oy + brush; j++)
			{
				for (int k = oz; k < oz + brush; k++)
				{
					if (bp.Voxels[i, j, k])
					{
						return false;
					}
				}
			}
		}
		return true;
	}

	private int GetBestMatchingMaterialIndex(BlockBlueprint bp, string materialCode)
	{
		int num = bp.MaterialCodes.IndexOf(materialCode);
		if (num != -1)
		{
			return num;
		}
		if (AllowAnyOrientation)
		{
			string uCode1 = GetUnorientedCode(materialCode);
			num = bp.MaterialCodes.FindIndex(delegate(string bpCode)
			{
				string unorientedCode = GetUnorientedCode(bpCode);
				return uCode1 == unorientedCode;
			});
			if (num != -1)
			{
				return num;
			}
		}
		return 0;
	}

	private string GetUnorientedCode(string materialCode)
	{
		Block block = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation(materialCode));
		string[] array = new string[3] { "rotation", "orientation", "side" };
		string[] array2 = array.Select((string _) => "*").ToArray();
		return ((RegistryObject)block).CodeWithVariants(array, array2).ToString();
	}

	private bool IsMatchingMaterial(string code1, string code2)
	{
		if (code1 == code2)
		{
			return true;
		}
		string unorientedCode = GetUnorientedCode(code1);
		string unorientedCode2 = GetUnorientedCode(code2);
		if (AllowAnyOrientation && unorientedCode == unorientedCode2)
		{
			return true;
		}
		return false;
	}

	private bool IsBlockIdentical(BlockBlueprint bpA, BlockBlueprint bpB, int ox, int oy, int oz, int brush)
	{
		for (int i = ox; i < ox + brush; i++)
		{
			for (int j = oy; j < oy + brush; j++)
			{
				for (int k = oz; k < oz + brush; k++)
				{
					bool flag = bpA.Voxels[i, j, k];
					bool flag2 = bpB.Voxels[i, j, k];
					if (flag != flag2)
					{
						return false;
					}
					if (flag)
					{
						string code = bpA.MaterialCodes[bpA.Materials[i, j, k]];
						string code2 = bpB.MaterialCodes[bpB.Materials[i, j, k]];
						return IsMatchingMaterial(code, code2);
					}
				}
			}
		}
		return true;
	}

	private bool HasAny(BlockBlueprint bp)
	{
		for (int i = 0; i < 16; i++)
		{
			for (int j = 0; j < 16; j++)
			{
				for (int k = 0; k < 16; k++)
				{
					if (bp.Voxels[i, j, k])
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	private int AnalyzeBlock(BlockBlueprint bp, int ox, int oy, int oz, int brush, out bool isSolid, out byte dominantMat)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		int num = 0;
		for (int i = ox; i < ox + brush; i++)
		{
			for (int j = oy; j < oy + brush; j++)
			{
				for (int k = oz; k < oz + brush; k++)
				{
					if (bp.Voxels[i, j, k])
					{
						num++;
						int key = bp.Materials[i, j, k];
						dictionary.TryGetValue(key, out var value);
						dictionary[key] = value + 1;
					}
				}
			}
		}
		isSolid = num > brush * brush * brush / 2;
		dominantMat = 0;
		if (dictionary.Count > 0)
		{
			dominantMat = (byte)dictionary.Aggregate((KeyValuePair<int, int> l, KeyValuePair<int, int> r) => (l.Value <= r.Value) ? r : l).Key;
		}
		return num;
	}

	private void Fill(BlockBlueprint bp, int ox, int oy, int oz, int brush, byte material)
	{
		for (int i = ox; i < ox + brush; i++)
		{
			for (int j = oy; j < oy + brush; j++)
			{
				for (int k = oz; k < oz + brush; k++)
				{
					bp.Voxels[i, j, k] = true;
					bp.Materials[i, j, k] = material;
				}
			}
		}
	}

	private void Clear(BlockBlueprint bp, int ox, int oy, int oz, int size)
	{
		for (int i = ox; i < ox + size; i++)
		{
			for (int j = oy; j < oy + size; j++)
			{
				for (int k = oz; k < oz + size; k++)
				{
					bp.Voxels[i, j, k] = false;
				}
			}
		}
	}
}




