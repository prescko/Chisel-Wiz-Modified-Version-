﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ChiselWiz.Patches;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Common.Entities;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.Client.NoObf;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems;

public class OpenableContainerManager
{
	private ICoreClientAPI capi;

	public OpenableContainerManager(ICoreClientAPI capi)
	{
		this.capi = capi;
	}

	public List<BlockEntityOpenableContainer> FindAllNear(BlockPos pos, int range)
	{
		BlockPos asBlockPos = ((Entity)((IPlayer)capi.World.Player).Entity).Pos.AsBlockPos;
		List<BlockEntityOpenableContainer> containers = new List<BlockEntityOpenableContainer>();
		((IWorldAccessor)capi.World).BlockAccessor.WalkBlocks(asBlockPos.AddCopy(range, range, range), asBlockPos.AddCopy(-range, -range, -range), (Action<Block, int, int, int>)delegate(Block block, int x, int y, int z)
		{

			BlockPos val = new BlockPos(x, y, z);
			if (((IWorldAccessor)capi.World).Claims.TryAccess((IPlayer)(object)capi.World.Player, val, (EnumBlockAccessFlags)2))
			{
				BlockEntityOpenableContainer blockEntity = ((IWorldAccessor)capi.World).BlockAccessor.GetBlockEntity<BlockEntityOpenableContainer>(val);
				if (blockEntity != null)
				{
					containers.Add(blockEntity);
				}
			}
		}, false);
		return containers;
	}

	public Task ToggleOpen(BlockEntityOpenableContainer container)
	{

		TaskCompletionSource tcs = new TaskCompletionSource();
		IPlayerInventoryManager inventoryManager = ((IPlayer)capi.World.Player).InventoryManager;
		if (inventoryManager.OpenedInventories.Contains((IInventory)(object)((BlockEntityContainer)container).Inventory))
		{
			capi.Network.SendBlockEntityPacket(((BlockEntity)container).Pos, 1001, (byte[])null);
			capi.Network.SendPacketClient(inventoryManager.CloseInventory((IInventory)(object)((BlockEntityContainer)container).Inventory));
			tcs.SetResult();
			return tcs.Task;
		}
		_ = new int[2] { 5000, 1001 };
		OnReceivedServerPacketPrefixHandler prefixHandler = null;
		prefixHandler = delegate(OnReceivedServerPacketPrefixEventArgs args)
		{
			if (args.container == container && args.packetid == 5000)
			{
				BlockEntityContainerOpen val = BlockEntityContainerOpen.FromBytes(args.data);
				((BlockEntityContainer)args.container).Inventory.FromTreeAttributes((ITreeAttribute)(object)val.Tree);
				((BlockEntityContainer)args.container).Inventory.ResolveBlocksOrItems();
				((IPlayer)capi.World.Player).InventoryManager.OpenInventory((IInventory)(object)((BlockEntityContainer)args.container).Inventory);
				args.Handled = true;
				tcs.SetResult();
				InventoryPatch.OnReceivedServerPacketPrefix -= prefixHandler;
			}
		};
		InventoryPatch.OnReceivedServerPacketPrefix += prefixHandler;
		(capi.World as ClientMain).SendHandInteraction(2, new BlockSelection
		{
			Block = ((BlockEntity)container).Block,
			Face = BlockFacing.UP,
			Position = ((BlockEntity)container).Pos,
			HitPosition = new Vec3d(0.5, 0.5, 0.5),
			SelectionBoxIndex = 0
		}, null, (EnumHandInteract)3, (EnumHandInteractNw)4, firstEvent: true, (EnumItemUseCancelReason)0);
		return tcs.Task;
	}

	public async Task ToggleOpen(IEnumerable<BlockEntityOpenableContainer> containers)
	{
		await Task.WhenAll(containers.Select((BlockEntityOpenableContainer c) => ToggleOpen(c)));
	}
}




