﻿using System.Linq;
using ChiselWiz.Systems.Blueprints;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.API.Datastructures;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Systems;

public class DummyBlockEntityChisel : BlockEntityChisel
{
	public static DummyBlockEntityChisel FromItemStack(ICoreClientAPI capi, ItemStack stack)
	{

		DummyBlockEntityChisel obj = new DummyBlockEntityChisel
		{
			Api = (ICoreAPI)(object)capi
		};
		((BlockEntity)obj).Block = stack.Block;
		((BlockEntity)obj).Pos = new BlockPos(0, 0, 0);
		((BlockEntity)obj).FromTreeAttributes(stack.Attributes, (IWorldAccessor)(object)capi.World);
		return obj;
	}

	public static DummyBlockEntityChisel FromBlockBlueprint(ICoreClientAPI capi, BlockBlueprint bp)
	{

		DummyBlockEntityChisel obj = new DummyBlockEntityChisel
		{
			Api = (ICoreAPI)(object)capi
		};
		((BlockEntity)obj).Block = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation("game:chiseledblock"));
		((BlockEntity)obj).Pos = new BlockPos(0, 0, 0);
		((BlockEntityMicroBlock)obj).BlockName = bp.Name;
		((BlockEntityMicroBlock)obj).BlockIds = bp.MaterialCodes.Select(delegate(string code)
		{
			Block block = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation(code));
			if (block == null)
			{
				block = ((IWorldAccessor)capi.World).GetBlock(new AssetLocation("game:air"));
			}
			return ((CollectibleObject)block).Id;
		}).ToArray();
		obj.Rebuild(bp.Voxels, bp.Materials);
		return obj;
	}

	public ItemStack ToItemStack(int stackSize = 1)
	{

		TreeAttribute val = new TreeAttribute();
		((BlockEntity)this).ToTreeAttributes((ITreeAttribute)(object)val);
		val.RemoveAttribute("posx");
		val.RemoveAttribute("posy");
		val.RemoveAttribute("posz");
		val.RemoveAttribute("snowcuboids");
		return new ItemStack(((CollectibleObject)((BlockEntity)this).Block).Id, (EnumItemClass)0, stackSize, val, ((BlockEntity)this).Api.World);
	}

	public void Rebuild(BoolArray16x16x16 voxels, byte[,,] materials)
	{
		base.RebuildCuboidList(voxels, materials);
	}

	public BlockBlueprint ToBlockBlueprint()
	{
		return new BlockBlueprint((BlockEntityMicroBlock)(object)this);
	}
}




