﻿using System.Reflection;
using HarmonyLib;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(BlockEntityChisel))]
[HarmonyPatch("OnBlockInteract")]
public static class BlockEntityChisel_OnBlockInteract_Patch
{
	private static bool Prefix(BlockEntityChisel __instance, IPlayer byPlayer, BlockSelection blockSel, bool isBreak)
	{

		ICoreAPI api = ((BlockEntity)__instance).Api;
		if (api == null || (int)api.Side != 2)
		{
			return true;
		}
		_ = ((BlockEntity)__instance).Api;
		Cuboidf[] array = (Cuboidf[])typeof(BlockEntityChisel).GetMethod("GetOrCreateVoxelSelectionBoxes", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(__instance, new object[1] { byPlayer });
		if (blockSel.SelectionBoxIndex >= array.Length)
		{
			return false;
		}
		Cuboidf val = array[blockSel.SelectionBoxIndex];
		Vec3i voxelPos = new Vec3i((int)(16f * val.X1), (int)(16f * val.Y1), (int)(16f * val.Z1));
		byte nowmaterialIndex = (byte)typeof(BlockEntityChisel).GetField("nowmaterialIndex", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.FlattenHierarchy).GetValue(__instance);
		OnBlockInteractEventArgs obj = new OnBlockInteractEventArgs
		{
			beChisel = __instance,
			face = blockSel.Face,
			isBreak = isBreak,
			voxelPos = voxelPos,
			nowmaterialIndex = nowmaterialIndex
		};
		BlockEntityChiselPatch.InvokeOnBlockInteract(obj);
		if (obj.Handled)
		{
			return false;
		}
		return true;
	}
}




