﻿using HarmonyLib;
using Vintagestory.API.Common;
using Vintagestory.GameContent;
using VSSurvivalMod.Systems.ChiselModes;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(BlockEntityChisel))]
[HarmonyPatch("GetChiselModeData")]
public static class Patch_BlockEntityChisel_GetChiselModeData
{
	public static bool Prefix(BlockEntityChisel __instance, IPlayer player, ref ChiselMode __result)
	{

		ICoreAPI api = ((BlockEntity)__instance).Api;
		if (api == null || (int)api.Side != 2)
		{
			return true;
		}
		GetChiselModeEventArgs e = new GetChiselModeEventArgs();
		BlockEntityChiselPatch.InvokeGetChiselMode(e);
		if (e.Handled)
		{
			__result = e.Result;
			return false;
		}
		return true;
	}
}




