﻿namespace ChiselWiz.Patches;

public delegate void GetSelectionBoxesHandler(GetSelectionBoxesEventArgs args);




