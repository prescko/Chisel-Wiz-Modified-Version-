﻿namespace ChiselWiz.Patches;

public static class BlockEntityChiselPatch
{
	public static event GetChiselModeHandler OnGetChiselMode;

	public static event GetSelectionBoxesHandler OnGetSelectionBoxes;

	public static event OnBlockInteractHandler OnBlockInteract;

	public static void InvokeGetChiselMode(GetChiselModeEventArgs args)
	{
		BlockEntityChiselPatch.OnGetChiselMode?.Invoke(args);
	}

	public static void InvokeGetSelectionBoxes(GetSelectionBoxesEventArgs args)
	{
		BlockEntityChiselPatch.OnGetSelectionBoxes?.Invoke(args);
	}

	public static void InvokeOnBlockInteract(OnBlockInteractEventArgs args)
	{
		BlockEntityChiselPatch.OnBlockInteract?.Invoke(args);
	}

	public static void Dispose()
	{
		BlockEntityChiselPatch.OnGetChiselMode = null;
		BlockEntityChiselPatch.OnGetSelectionBoxes = null;
		BlockEntityChiselPatch.OnBlockInteract = null;
	}
}




