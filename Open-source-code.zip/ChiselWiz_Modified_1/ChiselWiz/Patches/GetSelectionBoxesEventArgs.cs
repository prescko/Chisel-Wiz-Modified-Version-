﻿using System.Collections.Generic;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

public class GetSelectionBoxesEventArgs
{
	public BlockEntityChisel beChisel;

	public bool DetailingMode;

	public List<uint> VoxelCuboids;

	public BlockPos pos;

	public Cuboidf[] Result;

	public bool Handled;
}




