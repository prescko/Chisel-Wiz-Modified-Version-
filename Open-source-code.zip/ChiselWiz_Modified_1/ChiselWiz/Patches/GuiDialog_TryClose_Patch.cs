﻿using HarmonyLib;
using Vintagestory.API.Client;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(GuiDialog), "TryClose")]
public static class GuiDialog_TryClose_Patch
{
	public static bool Prefix(GuiDialog __instance, bool __result)
	{
		if (!GuiReplacementPatches.IsGuiTypeOverridden(__instance))
		{
			return true;
		}
		AltGuiDialog openedAltGuiDialog = GuiReplacementPatches.GetOpenedAltGuiDialog(__instance);
		if (openedAltGuiDialog != null)
		{
			__result = openedAltGuiDialog.gui.TryClose();
			return false;
		}
		return true;
	}
}




