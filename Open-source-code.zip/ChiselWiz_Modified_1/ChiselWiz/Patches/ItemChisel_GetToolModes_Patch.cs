﻿using System.Reflection;
using HarmonyLib;
using Vintagestory.API.Client;
using Vintagestory.API.Common;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(ItemChisel))]
[HarmonyPatch("GetToolModes")]
public static class ItemChisel_GetToolModes_Patch
{
	private static bool Prefix(ItemChisel __instance, ItemSlot slot, IClientPlayer forPlayer, BlockSelection blockSel, ref SkillItem[] __result)
	{

		ICoreAPI val = (ICoreAPI)typeof(ItemChisel).GetField("api", BindingFlags.Instance | BindingFlags.NonPublic).GetValue(__instance);
		if (val == null || val.Side != EnumAppSide.Client)
		{
			return true;
		}
		__result = (SkillItem[])(object)new SkillItem[0];
		return false;
	}
}




