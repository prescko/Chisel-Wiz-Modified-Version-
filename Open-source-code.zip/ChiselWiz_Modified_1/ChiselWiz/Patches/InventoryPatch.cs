﻿namespace ChiselWiz.Patches;

public static class InventoryPatch
{
	public static event OnReceivedServerPacketPrefixHandler OnReceivedServerPacketPrefix;

	public static void InvokeOnReceivedServerPacketPrefix(OnReceivedServerPacketPrefixEventArgs args)
	{
		InventoryPatch.OnReceivedServerPacketPrefix?.Invoke(args);
	}

	public static void Dispose()
	{
		InventoryPatch.OnReceivedServerPacketPrefix = null;
	}
}




