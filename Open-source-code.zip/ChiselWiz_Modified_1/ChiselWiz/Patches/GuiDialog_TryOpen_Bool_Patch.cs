﻿using System;
using HarmonyLib;
using Vintagestory.API.Client;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(GuiDialog), "TryOpen", new Type[] { typeof(bool) })]
public static class GuiDialog_TryOpen_Bool_Patch
{
	public static bool Prefix(GuiDialog __instance, bool __result)
	{
		if (!GuiReplacementPatches.IsGuiTypeOverridden(__instance))
		{
			return true;
		}
		AltGuiDialog altGuiDialog = GuiReplacementPatches.GetAltGuiDialog(__instance);
		if (altGuiDialog != null && altGuiDialog.conditionCallback(__instance))
		{
			if (altGuiDialog.beforeOpen != null && !altGuiDialog.beforeOpen(altGuiDialog.gui))
			{
				__result = false;
				return false;
			}
			bool num = altGuiDialog.gui.TryOpen();
			if (num && altGuiDialog.afterOpen != null)
			{
				altGuiDialog.afterOpen(altGuiDialog.gui);
			}
			__result = num;
			return false;
		}
		return true;
	}
}




