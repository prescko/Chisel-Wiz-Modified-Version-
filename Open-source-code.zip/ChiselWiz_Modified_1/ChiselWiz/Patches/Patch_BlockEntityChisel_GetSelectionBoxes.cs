﻿using HarmonyLib;
using Vintagestory.API.Common;
using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(BlockEntityChisel))]
[HarmonyPatch("GetSelectionBoxes")]
public static class Patch_BlockEntityChisel_GetSelectionBoxes
{
	public static bool Prefix(BlockEntityChisel __instance, ref Cuboidf[] __result, IBlockAccessor world, BlockPos pos, IPlayer forPlayer = null)
	{

		ICoreAPI api = ((BlockEntity)__instance).Api;
		if (api == null || (int)api.Side != 2)
		{
			return true;
		}
		GetSelectionBoxesEventArgs e = new GetSelectionBoxesEventArgs
		{
			beChisel = __instance,
			DetailingMode = __instance.DetailingMode,
			VoxelCuboids = ((BlockEntityMicroBlock)__instance).VoxelCuboids,
			pos = pos
		};
		BlockEntityChiselPatch.InvokeGetSelectionBoxes(e);
		if (e.Handled)
		{
			__result = e.Result;
			return false;
		}
		return true;
	}
}




