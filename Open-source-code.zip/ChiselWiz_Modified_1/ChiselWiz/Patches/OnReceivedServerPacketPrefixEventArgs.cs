﻿using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

public class OnReceivedServerPacketPrefixEventArgs
{
	public bool Handled;

	public BlockEntityOpenableContainer container;

	public int packetid;

	public byte[] data;
}




