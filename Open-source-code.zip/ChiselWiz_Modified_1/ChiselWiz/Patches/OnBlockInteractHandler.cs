﻿namespace ChiselWiz.Patches;

public delegate void OnBlockInteractHandler(OnBlockInteractEventArgs args);




