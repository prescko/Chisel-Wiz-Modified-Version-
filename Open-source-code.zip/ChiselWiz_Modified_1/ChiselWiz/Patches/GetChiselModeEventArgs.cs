﻿using VSSurvivalMod.Systems.ChiselModes;

namespace ChiselWiz.Patches;

public class GetChiselModeEventArgs
{
	public ChiselMode Result;

	public bool Handled;
}




