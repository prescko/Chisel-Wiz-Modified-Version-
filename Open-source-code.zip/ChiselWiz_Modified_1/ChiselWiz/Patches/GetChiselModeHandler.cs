﻿namespace ChiselWiz.Patches;

public delegate void GetChiselModeHandler(GetChiselModeEventArgs args);




