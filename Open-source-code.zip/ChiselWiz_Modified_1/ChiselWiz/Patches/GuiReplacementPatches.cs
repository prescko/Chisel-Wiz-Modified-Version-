﻿using System;
using System.Collections.Generic;
using Vintagestory.API.Client;

namespace ChiselWiz.Patches;

public static class GuiReplacementPatches
{
	public static Dictionary<Type, AltGuiDialog> AltDialogs = new Dictionary<Type, AltGuiDialog>();

	private static HashSet<Type> OverriddenGuiDialogTypes = new HashSet<Type>();

	public static AltGuiDialog GetAltGuiDialog(GuiDialog originalGui)
	{
		AltDialogs.TryGetValue(((object)originalGui).GetType(), out var value);
		return value;
	}

	public static AltGuiDialog GetOpenedAltGuiDialog(GuiDialog originalGui)
	{
		AltGuiDialog altGuiDialog = GetAltGuiDialog(originalGui);
		if (altGuiDialog == null)
		{
			return null;
		}
		if (!altGuiDialog.gui.IsOpened())
		{
			return null;
		}
		return altGuiDialog;
	}

	public static void SetAlternativeGui(Type originalDialogType, GuiDialog altGui, Func<GuiDialog, bool> conditionCallback, Func<GuiDialog, bool> beforeOpen, Action<GuiDialog> afterOpen)
	{
		AltDialogs[originalDialogType] = new AltGuiDialog
		{
			gui = altGui,
			conditionCallback = conditionCallback,
			beforeOpen = beforeOpen,
			afterOpen = afterOpen
		};
		OverriddenGuiDialogTypes.Add(originalDialogType);
	}

	public static bool IsGuiTypeOverridden(GuiDialog gui)
	{
		return OverriddenGuiDialogTypes.Contains(((object)gui).GetType());
	}
}




