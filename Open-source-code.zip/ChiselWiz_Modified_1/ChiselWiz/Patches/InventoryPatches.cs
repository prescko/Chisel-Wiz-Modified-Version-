﻿using HarmonyLib;
using Vintagestory.API.Common;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(BlockEntityOpenableContainer), "OnReceivedServerPacket")]
public static class InventoryPatches
{
	[HarmonyPrefix]
	public static bool Prefix(BlockEntityOpenableContainer __instance, int packetid, byte[] data)
	{

		ICoreAPI api = ((BlockEntity)__instance).Api;
		if (api == null || (int)api.Side != 2)
		{
			return true;
		}
		OnReceivedServerPacketPrefixEventArgs obj = new OnReceivedServerPacketPrefixEventArgs
		{
			container = __instance,
			packetid = packetid,
			data = data
		};
		InventoryPatch.InvokeOnReceivedServerPacketPrefix(obj);
		return !obj.Handled;
	}
}




