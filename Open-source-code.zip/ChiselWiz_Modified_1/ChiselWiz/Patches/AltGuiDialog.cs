﻿using System;
using Vintagestory.API.Client;

namespace ChiselWiz.Patches;

public class AltGuiDialog
{
	public GuiDialog gui;

	public Func<GuiDialog, bool> conditionCallback;

	public Func<GuiDialog, bool> beforeOpen;

	public Action<GuiDialog> afterOpen;
}




