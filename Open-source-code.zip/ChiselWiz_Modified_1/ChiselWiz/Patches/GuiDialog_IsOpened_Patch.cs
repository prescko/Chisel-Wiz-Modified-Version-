﻿using System;
using HarmonyLib;
using Vintagestory.API.Client;

namespace ChiselWiz.Patches;

[HarmonyPatch(typeof(GuiDialog), "IsOpened", new Type[] { })]
public static class GuiDialog_IsOpened_Patch
{
	public static bool Prefix(GuiDialog __instance, ref bool __result)
	{
		if (!GuiReplacementPatches.IsGuiTypeOverridden(__instance))
		{
			return true;
		}
		if (GuiReplacementPatches.GetOpenedAltGuiDialog(__instance) != null)
		{
			__result = true;
			return false;
		}
		return true;
	}
}




