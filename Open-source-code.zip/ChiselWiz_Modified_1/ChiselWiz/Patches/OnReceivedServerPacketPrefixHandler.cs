﻿namespace ChiselWiz.Patches;

public delegate void OnReceivedServerPacketPrefixHandler(OnReceivedServerPacketPrefixEventArgs args);




