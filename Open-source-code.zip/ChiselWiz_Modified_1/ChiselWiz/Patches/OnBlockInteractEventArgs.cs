﻿using Vintagestory.API.MathTools;
using Vintagestory.GameContent;

namespace ChiselWiz.Patches;

public class OnBlockInteractEventArgs
{
	public bool Handled;

	public BlockEntityChisel beChisel;

	public Vec3i voxelPos;

	public BlockFacing face;

	public bool isBreak;

	public byte nowmaterialIndex;
}




